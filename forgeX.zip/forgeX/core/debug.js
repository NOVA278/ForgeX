'use strict';
// ── Debug flags ─────────────────────────────────────────────────────────────
// FORGEX_DEBUG.enabled = false in production.
// Build-time strip: replace `FORGEX_DEBUG.enabled = true` → `= false` in the
// release bundle, or use a terser dead-code pass on `if (!FORGEX_DEBUG.enabled)`.
const FORGEX_DEBUG = {
  enabled:         false,  // Master switch — set true in local dev only
  shadows:         false,  // Log shadow map updates and light castShadow state
  objectCreation:  false,  // Log primitive creation and import/restore events
  selection:       false,  // Log SelectionSystem pick and multi-select events
  hierarchyUpdate: false,  // Log HierarchySystem refresh and parent/child changes
};

// Centralised debug logger — only emits when the master switch AND channel flag are set.
// Usage: FDEBUG.log('shadows', 'shadow map update', light);

const FDEBUG = {
  log(channel, ...args) {
    if (!FORGEX_DEBUG.enabled) return;
    if (FORGEX_DEBUG[channel]) console.log(`[ForgeX:${channel}]`, ...args);
  },
  warn(channel, ...args) {
    if (!FORGEX_DEBUG.enabled) return;
    if (FORGEX_DEBUG[channel]) console.warn(`[ForgeX:${channel}]`, ...args);
  },
};

// ══════════════════════════════════════════════════════
//  EventBus
// ══════════════════════════════════════════════════════
