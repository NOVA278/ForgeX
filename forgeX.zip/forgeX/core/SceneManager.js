'use strict';
const SceneManager = (() => {
  let _scene = null;

  // ── Scene-object registries (cameras & lights as scene nodes) ─────────────
  const _sceneObjects = [];   // { node:Object3D, role:'light' }

  function init() {
    _scene = new THREE.Scene();
    _scene.background = new THREE.Color(0x1c1c20);
    _scene.fog = new THREE.FogExp2(0x1a1a1e, 0.018);
    _setupGrid();
    _setupDefaultScene();
  }

  // ── Default scene: Cube + Floor ───────────────────────────────────────────
  function _setupDefaultScene() {
    // Default cube at origin
    const geo = new THREE.BoxGeometry(1, 1, 1, 2, 2, 2);
    if (geo.attributes.uv) geo.setAttribute('uv2', geo.attributes.uv.clone());
    const mat = new THREE.MeshStandardMaterial({
      color:             0xc8c8c8,
      roughness:         0.58,
      metalness:         0.02,
      emissive:          new THREE.Color(0x000000),
      emissiveIntensity: 0,
    });
    const cube = new THREE.Mesh(geo, mat);
    cube.castShadow = true;
    cube.receiveShadow = true;
    cube.name = 'Cube';
    cube.position.set(0, 0.5, 0);
    cube.userData.primitiveType = 'box';
    cube.userData.typeName = 'Cube';
    _scene.add(cube);

    // Floor plane — large flat surface sitting at y=0
    const floorGeo = new THREE.PlaneGeometry(10, 10, 10, 10);
    if (floorGeo.attributes.uv) floorGeo.setAttribute('uv2', floorGeo.attributes.uv.clone());
    const floorMat = new THREE.MeshStandardMaterial({
      color:             0xb0b0b8,
      roughness:         0.80,
      metalness:         0.00,
      emissive:          new THREE.Color(0x000000),
      emissiveIntensity: 0,
      side:              THREE.FrontSide,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;   // lay flat (XZ plane)
    floor.position.set(0, 0, 0);
    floor.castShadow = false;
    floor.receiveShadow = true;
    floor.name = 'Floor';
    floor.userData.primitiveType = 'plane';
    floor.userData.typeName = 'Floor';
    _scene.add(floor);
  }

  // ── Factory helpers ───────────────────────────────────────────────────────

  function _makeLightNode(name, pos, lightProps) {
    const node = new THREE.Object3D();
    node.name = name;
    node.position.set(pos.x || 0, pos.y || 0, pos.z || 0);
    node.userData.sceneObjectType = 'light';
    node.userData.typeName        = 'Light';
    node.userData.lightType       = lightProps.lightType || 'directional';
    node.userData.lightColor      = lightProps.color     || '#ffffff';
    node.userData.lightIntensity  = isFinite(lightProps.intensity) ? lightProps.intensity : 1.0;
    node.userData.castShadow      = lightProps.castShadow || false;
    node.userData.shadowEnabled   = lightProps.castShadow || false;
    // Visible gizmo: a small icosahedron + emissive material so it's always visible
    const geoIcon = new THREE.OctahedronGeometry(0.18, 0);
    const matIcon = new THREE.MeshBasicMaterial({ color: 0xffe080, depthTest: false });
    const icon = new THREE.Mesh(geoIcon, matIcon);
    icon.renderOrder = 10;
    icon.userData.nonSelectable = true;
    icon.userData.gizmoIcon    = true;
    icon.userData.helperObject = true;
    icon.castShadow    = false;
    icon.receiveShadow = false;
    node.add(icon);
    return node;
  }

  // ── Public scene-object CRUD ──────────────────────────────────────────────

  // addObject(obj)        — add a plain mesh/object to the scene (no registry entry)
  // addObject(obj, role)  — add a named-role scene object (light/camera) and track it
  // addSceneObject is a deprecated alias kept for back-compat; prefer addObject.
  function addObject(obj, role) {
    if (!_scene) return;
    _scene.add(obj);
    if (role) _sceneObjects.push({ node: obj, role });
    EventBus.emit('scene:objectAdded', obj);
  }

  /** @deprecated Use addObject(node, role) instead */
  function addSceneObject(node, role) { return addObject(node, role); }

  function removeSceneObject(node) {
    const idx = _sceneObjects.findIndex(e => e.node === node);
    if (idx !== -1) _sceneObjects.splice(idx, 1);
    if (_scene) _scene.remove(node);
    EventBus.emit('scene:objectRemoved', node);
  }

  function getLightObjects()  { return _sceneObjects.filter(e => e.role === 'light').map(e => e.node); }

  // ── Lighting control ──────────────────────────────────────────────────────
  // (Legacy getters removed — new lighting system to be built)
  function makeLightNode(name, pos, props) { return _makeLightNode(name, pos, props); }

  // ── Grid ──────────────────────────────────────────────────────────────────
  function _setupGrid() {
    // Sub-grid: fine 1-unit lines, very faint
    const subGrid = new THREE.GridHelper(40, 40, 0x252528, 0x252528);
    const _setGridMat = (g, opacity) => {
      const mats = Array.isArray(g.material) ? g.material : [g.material];
      mats.forEach(m => { m.transparent = true; m.opacity = opacity; m.depthWrite = false; });
    };
    _setGridMat(subGrid, 0.38);
    subGrid.name = '__subgrid__'; subGrid.userData.nonSelectable = true;
    subGrid.userData.helperObject = true;
    subGrid.castShadow = false; subGrid.receiveShadow = false;
    _scene.add(subGrid);

    // Main grid: 5-unit divisions, cleaner
    const mainGrid = new THREE.GridHelper(40, 8, 0x38383e, 0x38383e);
    _setGridMat(mainGrid, 0.65);
    mainGrid.position.y = 0.0005; // tiny offset to avoid z-fight with subgrid
    mainGrid.name = '__grid__'; mainGrid.userData.nonSelectable = true;
    mainGrid.userData.helperObject = true;
    mainGrid.castShadow = false; mainGrid.receiveShadow = false;
    _scene.add(mainGrid);

    // Center axis lines — strong, full-length, anti-z-fight
    function _makeAxisLine(color, from, to) {
      const pts = [new THREE.Vector3(...from), new THREE.Vector3(...to)];
      const geo = new THREE.BufferGeometry().setFromPoints(pts);
      const mat = new THREE.LineBasicMaterial({ color, depthTest: true, depthWrite: false, transparent: true, opacity: 0.85 });
      const line = new THREE.Line(geo, mat);
      line.userData.nonSelectable = true;
      line.userData.helperObject = true;
      line.userData.isAxisLine = true;
      line.castShadow = false; line.receiveShadow = false;
      line.renderOrder = 2;
      return line;
    }
    _scene.add(_makeAxisLine(0xcc3030, [-20, 0.001, 0], [20, 0.001, 0]));
    _scene.add(_makeAxisLine(0x2255dd, [0, 0.001, -20], [0, 0.001, 20]));
    _scene.add(_makeAxisLine(0x22aa44, [0, 0, 0], [0, 3, 0]));

    // Short origin gizmo arrows (visible object-mode helpers, 2-unit, bright)
    [[0xcc2222, [2, 0, 0]], [0x1a9933, [0, 2, 0]], [0x1a44cc, [0, 0, 2]]].forEach(([c, e]) => {
      const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0,0,0), new THREE.Vector3(...e)]);
      const mat = new THREE.LineBasicMaterial({ color: c, depthTest: true });
      const ax = new THREE.Line(geo, mat);
      ax.userData.nonSelectable = true;
      ax.userData.helperObject  = true;
      ax.userData.isAxisLine    = true;
      ax.castShadow = false; ax.receiveShadow = false;
      _scene.add(ax);
    });
  }

  // ── Adaptive grid distance fade (updates each frame via tick) ──────────
  function _setGridOpacity(obj, opacity) {
    if (!obj) return;
    if (Array.isArray(obj.material)) {
      obj.material.forEach(m => { m.opacity = opacity; });
    } else if (obj.material) {
      obj.material.opacity = opacity;
    }
  }
  function tickGridFade(camera) {
    if (!_scene || !camera) return;
    const camDist = camera.position.length();
    const sub = _scene.getObjectByName('__subgrid__');
    if (sub) {
      const t = Math.max(0, Math.min(1, (camDist - 3) / 15));
      _setGridOpacity(sub, Math.max(0, 0.38 * (1.0 - t * 0.85)));
    }
    const main = _scene.getObjectByName('__grid__');
    if (main) {
      const t2 = Math.max(0, Math.min(1, (camDist - 1.5) / 5));
      _setGridOpacity(main, 0.30 + 0.35 * t2);
    }
  }

  function getScene() { return _scene; }

  function getMeshObjects() {
    return _scene
      ? _scene.children.filter(c =>
          c.isMesh &&
          !c.userData.nonSelectable &&
          !c.userData.editOverlay &&
          !c.userData.sceneObjectType)
      : [];
  }

  function removeObject(obj) {
    if (_scene && obj) {
      _scene.remove(obj);
      if (obj.geometry) obj.geometry.dispose();
      if (obj.material) {
        const texSlots = ['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap'];
        texSlots.forEach(slot => { if (obj.material[slot]) { obj.material[slot].dispose(); obj.material[slot] = null; } });
        obj.material.dispose();
      }
      if (typeof MaterialSystem !== 'undefined') MaterialSystem.removeMatData(obj.uuid);
      EventBus.emit('scene:objectRemoved', obj);
    }
  }

  function getCameraObjects() { return _sceneObjects.filter(e => e.role === 'camera').map(e => e.node); }

  return {
    init, getScene, tickGridFade,
    getMeshObjects, addObject, removeObject,
    getLightObjects, getCameraObjects,
    addSceneObject, removeSceneObject,
    makeLightNode,
  };
})();

// ══════════════════════════════════════════════════════
//  CameraManager — editor orbit/pan/zoom camera
// ══════════════════════════════════════════════════════
