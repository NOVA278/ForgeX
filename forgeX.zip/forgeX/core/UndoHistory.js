'use strict';
const UndoHistory = (() => {
  const MAX = 64;
  let _undoStack = [];  // [{meshData, elemType, selected}]
  let _redoStack = [];

  function _cloneSelected(set) {
    return new Set(set);
  }

  function _cloneMeshData(md) {
    if(!md) return null;
    return {
      verts: md.verts.map(v => ({x:v.x, y:v.y, z:v.z})),
      faces: md.faces.map(f => ({
        verts: f.verts.slice(),
        edges: f.edges.slice(),
        normal: {x:f.normal.x, y:f.normal.y, z:f.normal.z},
        center: {x:f.center.x, y:f.center.y, z:f.center.z}
      })),
      edges: md.edges.map(e => ({a:e.a, b:e.b, faces:e.faces.slice()}))
    };
  }

  // Call this BEFORE the operation that will mutate meshData.
  function push(meshData, elemType, selected) {
    if(!meshData) return;
    _undoStack.push({
      meshData: _cloneMeshData(meshData),
      elemType: elemType,
      selected: _cloneSelected(selected)
    });
    if(_undoStack.length > MAX) _undoStack.shift();
    _redoStack = []; // a new action clears the redo stack
  }

  function canUndo() { return _undoStack.length > 0; }
  function canRedo() { return _redoStack.length > 0; }

  // Returns the state to restore, saves current state on redo stack.
  function undo(currentMeshData, currentElemType, currentSelected) {
    if(!canUndo()) return null;
    _redoStack.push({
      meshData: _cloneMeshData(currentMeshData),
      elemType: currentElemType,
      selected: _cloneSelected(currentSelected)
    });
    return _undoStack.pop();
  }

  function redo(currentMeshData, currentElemType, currentSelected) {
    if(!canRedo()) return null;
    _undoStack.push({
      meshData: _cloneMeshData(currentMeshData),
      elemType: currentElemType,
      selected: _cloneSelected(currentSelected)
    });
    return _redoStack.pop();
  }

  function clear() {
    _undoStack = [];
    _redoStack = [];
  }

  return { push, undo, redo, canUndo, canRedo, clear };
})();

// ══════════════════════════════════════════════════════
//  ObjectUndoHistory
//  Stores object transform snapshots for Object Mode.
//  push()  — call BEFORE a transform drag starts
//  undo()  — revert object to previous transform
//  redo()  — reapply a reverted transform
//  clear() — wipe stacks
// ══════════════════════════════════════════════════════

const ObjectUndoHistory = (() => {
  const MAX = 64;
  let _undoStack = [];
  let _redoStack = [];

  function _snap(obj) {
    return {
      uuid: obj.uuid,
      pos:   { x: obj.position.x, y: obj.position.y, z: obj.position.z },
      rot:   { x: obj.rotation.x, y: obj.rotation.y, z: obj.rotation.z },
      scale: { x: obj.scale.x,    y: obj.scale.y,    z: obj.scale.z }
    };
  }

  function push(obj) {
    if (!obj) return;
    _undoStack.push(_snap(obj));
    if (_undoStack.length > MAX) _undoStack.shift();
    _redoStack = [];
    _refreshButtons();
  }

  function canUndo() { return _undoStack.length > 0; }
  function canRedo() { return _redoStack.length > 0; }

  function undo(obj) {
    if (!canUndo() || !obj) return;
    _redoStack.push(_snap(obj));
    const state = _undoStack.pop();
    _apply(obj, state);
    _refreshButtons();
  }

  function redo(obj) {
    if (!canRedo() || !obj) return;
    _undoStack.push(_snap(obj));
    const state = _redoStack.pop();
    _apply(obj, state);
    _refreshButtons();
  }

  function _apply(obj, state) {
    obj.position.set(state.pos.x, state.pos.y, state.pos.z);
    obj.rotation.set(state.rot.x, state.rot.y, state.rot.z);
    obj.scale.set(state.scale.x, state.scale.y, state.scale.z);
    obj.updateMatrixWorld(true);
    TransformControlsModule.syncToObject(obj);
    EventBus.emit('transform:changed', obj);
    // Keep scene-object UI panels in sync
    const role = obj.userData.sceneObjectType;
    if (role === 'camera') EventBus.emit('cameramanager:changed');
    if (role === 'light')  EventBus.emit('lightmanager:changed');
  }

  function clear() {
    _undoStack = [];
    _redoStack = [];
    _refreshButtons();
  }

  function _refreshButtons() {
    const undoBtn = document.getElementById('btn-undo');
    const redoBtn = document.getElementById('btn-redo');
    if (undoBtn) {
      undoBtn.disabled = !canUndo();
      undoBtn.style.opacity = canUndo() ? '1' : '0.35';
      undoBtn.style.cursor  = canUndo() ? 'pointer' : 'not-allowed';
    }
    if (redoBtn) {
      redoBtn.disabled = !canRedo();
      redoBtn.style.opacity = canRedo() ? '1' : '0.35';
      redoBtn.style.cursor  = canRedo() ? 'pointer' : 'not-allowed';
    }
  }

  return { push, undo, redo, canUndo, canRedo, clear, _refreshButtons };
})();

// ══════════════════════════════════════════════════════
//  RendererManager
// ══════════════════════════════════════════════════════
