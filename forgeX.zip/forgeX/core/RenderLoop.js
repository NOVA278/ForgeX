'use strict';
const RenderLoop = (() => {
  let _running=false, _lastTime=0, _frameCount=0, _fpsTimer=0, _warmupFrames=0;

  function start(){ if(_running) return; _running=true; _warmupFrames=0; _tick(0); }

  // Called externally whenever a new object is added to the scene
  function resetShadowWarmup() { _warmupFrames = 0; }

  function _tick(now){
    if(!_running) return;
    requestAnimationFrame(_tick);
    const dt=now-_lastTime; _lastTime=now; _frameCount++; _fpsTimer+=dt;
    if(_fpsTimer>=1000){ UISystem.updateFPS(_frameCount); _frameCount=0; _fpsTimer-=1000; }
    RendererManager.resize();
    // Force shadow maps to regenerate for startup and whenever new objects are added
    if (_warmupFrames < 6) {
      _warmupFrames++;
      const r = RendererManager.getRenderer();
      if (r) r.shadowMap.needsUpdate = true;
    }
    const camera=CameraManager.getCamera(), scene=SceneManager.getScene(), selected=SelectionSystem.getSelected();
    const renderCamera = CameraManager.getActiveCamera ? CameraManager.getActiveCamera() : camera;
    if(selected&&!EditModeSystem.isActive()) TransformControlsModule.syncToObject(selected);
    if(TransformControlsModule.isDragging()&&selected) UISystem.schedulePropUpdate(selected);
    EditModeSystem.tickGizmo();
    // Sync world-space directional lights: direction from node rotation, never from position
    if (typeof LightManager !== 'undefined') LightManager.syncDirectionalLights();
    // Update selection outline wireframes (polygon-offset, no shadow artifacts)
    SelectionOutline.tick(SelectionSystem.getMultiSelected(), EditModeSystem.isActive());
    SceneManager.tickGridFade(camera);
    HoverOutline.tick();
    RendererManager.render(scene, renderCamera);
    OrientationWidget.render();
  }

  return { start, resetShadowWarmup };
})();

// SelectionOutline: multi-layer polygon-offset wireframe selection - NO shadow artifacts
