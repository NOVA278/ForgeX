'use strict';
const EventBus = (() => {
  const _h = {};
  const _emitting = new Set(); // re-entrancy guard: tracks events currently being dispatched
  return {
    on(e,fn)  { (_h[e]=_h[e]||[]).push(fn); return ()=>this.off(e,fn); },
    off(e,fn) { if(_h[e]) _h[e]=_h[e].filter(h=>h!==fn); },
    emit(e,d) {
      if(_emitting.has(e)) return; // drop re-entrant emit of the same event
      _emitting.add(e);
      try { (_h[e]||[]).slice().forEach(fn=>fn(d)); } // .slice() snapshots handlers so mid-emit on/off is safe
      finally { _emitting.delete(e); }
    }
  };
})();

// ══════════════════════════════════════════════════════
//  UndoHistory
//  Stores snapshots of EditModeSystem mesh state.
//  push()  — call BEFORE a destructive operation
//  undo()  — revert to previous snapshot
//  redo()  — reapply a reverted snapshot
//  clear() — wipe stacks (e.g. on mode exit or object change)
// ══════════════════════════════════════════════════════
