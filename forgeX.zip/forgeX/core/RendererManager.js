'use strict';
const RendererManager = (() => {
  let _renderer=null, _canvas=null, _lastW=0, _lastH=0;

  function init(canvasEl) {
    _canvas=canvasEl;
    _renderer=new THREE.WebGLRenderer({ canvas:_canvas, antialias:true, powerPreference:'high-performance', alpha:false });
    _renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
    // NOTE: shadow, tone-mapping, and encoding config is owned by LightManager._configureRenderer().
    // RendererManager only sets the clear colour and fires the initial resize here.
    _renderer.setClearColor(0x1c1c20,1);
    resize();
  }

  function resize() {
    const wrap=document.getElementById('viewport-wrap');
    if(!wrap||!_renderer) return;
    const w=wrap.clientWidth, h=wrap.clientHeight;
    if(w===_lastW&&h===_lastH) return;
    _lastW=w; _lastH=h;
    _renderer.setSize(w,h,false);
    EventBus.emit('renderer:resize',{width:w,height:h});
  }

  function render(scene,camera) { if(_renderer&&scene&&camera) _renderer.render(scene,camera); }
  function getRenderer() { return _renderer; }
  function getSize() { return {width:_lastW,height:_lastH}; }

  return { init, resize, render, getRenderer, getSize };
})();

// ══════════════════════════════════════════════════════
//  SceneManager
// ══════════════════════════════════════════════════════
