'use strict';
const AppInit = (() => {
  function _progress(pct,label){
    const bar=document.getElementById('load-bar'), status=document.getElementById('load-status');
    if(bar) bar.style.width=pct+'%'; if(status) status.textContent=label;
  }
  const _delay=ms=>new Promise(r=>setTimeout(r,ms));

  async function run(){
    try {
      _progress(10,'Initializing renderer...'); await _delay(80);
      const canvas=document.getElementById('viewport-canvas');
      RendererManager.init(canvas);

      _progress(25,'Building scene...'); await _delay(60);
      SceneManager.init();
      LightManager.init(SceneManager.getScene(), RendererManager.getRenderer());

      _progress(40,'Setting up camera...'); await _delay(50);
      CameraManager.init(canvas);

      _progress(55,'Building gizmo system...'); await _delay(50);
      // Init selection outline system (polygon-offset wireframe, no shadow artifacts)
      SelectionOutline.init(SceneManager.getScene());
      HoverOutline.init(SceneManager.getScene(), canvas, CameraManager.getCamera());
      TransformControlsModule.init(SceneManager.getScene(),CameraManager.getCamera(),canvas);

      _progress(63,'Initializing edit system...'); await _delay(40);
      EditModeSystem.init(canvas,CameraManager.getCamera(),SceneManager.getScene());

      _progress(70,'Initializing selection...'); await _delay(40);
      SelectionSystem.init(canvas,CameraManager.getCamera());
      ObjectModeSelectSystem.init(canvas, CameraManager.getCamera());

      _progress(80,'Binding input controls...'); await _delay(40);
      InputControls.init();
      UISystem.bindPropInputs();

      _progress(83,'Initializing Loop Cut...'); await _delay(20);
      LoopCutSystem.init(SceneManager.getScene());

      _progress(88,'Orientation widget...'); await _delay(30);
      OrientationWidget.init(document.getElementById('orient-canvas'),CameraManager.getCamera());

      _progress(93,'Wiring events...'); await _delay(30);
      _wireEvents();
      PanelCollapseSystem.init();
      SceneIO.init();
      MaterialSystem.initUI();
      LightSystem.init();
      // Add default sun light — direction is controlled by node rotation, not position.
      // The gizmo node is placed at (4,8,3) for visibility; the light itself
      // sits at SUN_DISTANCE away in the direction defined by the rotation below.
      // Rotation angles chosen to match a classic Blender upper-left key light angle.
      LightManager.addLight('directional', {
        color: '#fff5e8', intensity: 2.0,
        position: { x: 4, y: 8, z: 3 },
        rotation: { x: -Math.PI / 4, y: Math.PI / 6, z: 0 },
        castShadow: true,
      });
      // NOTE: no manual _refreshMeshShadows() here — LightManager.addLight() handles it.
      SceneCameraSystem.init();
      SceneCameraSystem.addCamera({ name: 'Camera.001', pos: { x: 0, y: 1.5, z: 5 } });
      SelectionSystem.selectObject(null, false);
      HierarchySystem.init();
      ViewportSettings.init();

      _progress(98,'Starting render loop...'); await _delay(50);
      RenderLoop.start();

      _progress(99,'Initializing Phase 4 features...'); await _delay(30);
      _wirePhase4Events();

      _progress(100,'Ready.'); await _delay(200);
      _finish();

    } catch(err){
      console.error('[ForgeX] Init error:',err);
      const s=document.getElementById('load-status'); if(s)s.textContent='Error: '+err.message;
    }
  }

  function _wireEvents(){
    let _lastSelected = null;
    // Single handler for selection changes — merges UI refresh + camera button toggle
    EventBus.on('selection:changed', obj => {
      UISystem.refreshOutliner(); UISystem.refreshProps(obj); UISystem.updateStatus(obj);
      const ctxEdit = document.getElementById('ctx-edit-toggle');
      if (ctxEdit) ctxEdit.textContent = EditModeSystem.isActive() ? 'Exit Edit Mode' : 'Enter Edit Mode';
      if (obj && obj !== _lastSelected && !EditModeSystem.isActive()) ObjectUndoHistory.clear();
      _lastSelected = obj;
      const camBtn = document.getElementById('btn-enter-camera');
      if (camBtn) camBtn.classList.toggle('visible', !!(obj && obj.userData.sceneObjectType === 'camera'));
    });
    EventBus.on('editmode:changed', active => {
      UISystem.updateStatus(SelectionSystem.getSelected());
      UISystem.refreshOutliner();
      document.querySelectorAll('.add-btn[data-prim], .add-btn-v2[data-prim]').forEach(b => b.disabled = active);
    });
    // scene:objectAdded / scene:objectRemoved — UI refresh only.
    // Shadow config is owned by LightManager/ObjectManager.
    // NOTE: HierarchySystem.init() self-subscribes to these same events — do NOT
    // call HierarchySystem.refresh() here or it fires twice per event.
    EventBus.on('scene:objectAdded', () => {
      UISystem.refreshOutliner();
      UISystem.updateStatus(SelectionSystem.getSelected());
    });
    EventBus.on('scene:objectRemoved', () => {
      UISystem.refreshOutliner();
      UISystem.updateStatus(SelectionSystem.getSelected());
    });
    EventBus.on('transform:changed',obj=>UISystem.schedulePropUpdate(obj));
    // cameramanager:changed fires on both addCamera and removeCamera.
    // Refresh the outliner and status bar so the camera count and selection
    // state stay current — mirrors the lightmanager:changed → LightSystem.refreshList() pattern.
    EventBus.on('cameramanager:changed', () => {
      UISystem.refreshOutliner();
      UISystem.updateStatus(SelectionSystem.getSelected());
    });
    window.addEventListener('resize',()=>RendererManager.resize());
  }

  // ── Phase 4 feature wiring ────────────────────────────────────────────────
  function _wirePhase4Events() {
    const _on = (id, fn) => { const el=document.getElementById(id); if(el) el.addEventListener('click', fn); };

    // glTF import / export
    _on('fm-export-gltf', () => { if(typeof GLTFSystem!=='undefined') GLTFSystem.exportGLTF(); });
    _on('fm-import-gltf', () => { if(typeof GLTFSystem!=='undefined') GLTFSystem.importGLTF(); });

    // Render output
    _on('btn-render-output', () => { if(typeof RenderOutputSystem!=='undefined') RenderOutputSystem.open(); });

    // UV Editor
    _on('btn-open-uv-editor', () => {
      const sel = SelectionSystem.getSelected();
      if (!sel) return;
      if(typeof UVEditorSystem!=='undefined') UVEditorSystem.open(sel);
    });

    // Subdivision controls
    _on('subdiv-inc', () => _adjustSubdiv(1));
    _on('subdiv-dec', () => _adjustSubdiv(-1));
    document.querySelectorAll('.subdiv-pip').forEach(pip => {
      pip.addEventListener('click', () => {
        const level = parseInt(pip.dataset.level);
        const sel = SelectionSystem.getSelected();
        if (!sel || sel.userData.sceneObjectType) return;
        SubdivisionSystem.applySubdivision(sel, level);
        _refreshSubdivUI(sel);
      });
    });

    // Boolean operations
    _on('bool-set-b', () => {
      const sel = SelectionSystem.getSelected();
      if (!sel || sel.userData.sceneObjectType) {
        alert('Select a mesh to set as Boolean B target'); return;
      }
      BooleanSystem.setTargetB(sel);
      _refreshBoolUI();
    });
    _on('bool-union',     () => { BooleanSystem.applyUnion();     _refreshBoolUI(); });
    _on('bool-subtract',  () => { BooleanSystem.applySubtract();  _refreshBoolUI(); });
    _on('bool-intersect', () => { BooleanSystem.applyIntersect(); _refreshBoolUI(); });

    // Refresh subdiv + bool UI on selection change
    EventBus.on('selection:changed', obj => {
      _refreshSubdivUI(obj);
      _refreshBoolUI();
    });
  }

  function _adjustSubdiv(delta) {
    const sel = SelectionSystem.getSelected();
    if (!sel || sel.userData.sceneObjectType) return;
    const cur = SubdivisionSystem.getLevel(sel);
    const next = Math.max(0, Math.min(3, cur + delta));
    SubdivisionSystem.applySubdivision(sel, next);
    _refreshSubdivUI(sel);
  }

  function _refreshSubdivUI(mesh) {
    const badge = document.getElementById('subdiv-level-badge');
    const pips  = document.querySelectorAll('.subdiv-pip');
    if (!badge) return;
    const level = (mesh && !mesh.userData.sceneObjectType) ? SubdivisionSystem.getLevel(mesh) : 0;
    badge.textContent = level === 0 ? 'OFF' : `L${level}`;
    badge.style.color = level > 0 ? 'var(--accent)' : 'var(--text-dim)';
    pips.forEach((pip, i) => {
      pip.classList.toggle('active',   i < level);
      pip.classList.toggle('current',  i === level - 1 && level > 0);
    });
  }

  function _refreshBoolUI() {
    const label = document.getElementById('bool-b-label');
    if (!label) return;
    const b = (typeof BooleanSystem !== 'undefined') ? BooleanSystem.getTargetB() : null;
    label.textContent = b ? `B: "${b.name}"` : 'B: none set';
    label.style.color = b ? 'var(--accent)' : 'var(--text-dim)';
  }

  function _finish(){
    const loading=document.getElementById('loading'), app=document.getElementById('app');
    if(loading){ loading.classList.add('fade-out'); setTimeout(()=>loading.style.display='none',600); }
    if(app) app.style.visibility='visible';
  }

  return { run };
})();

// ══════════════════════════════════════════════════════
//  LeftSidebarTabs — tab switching for the left panel
// ══════════════════════════════════════════════════════
