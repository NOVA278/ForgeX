// ── Bootstrap ─────────────────────────────────────────────────────────────
// Single DOMContentLoaded entry point.
// Load order (enforced by <script> order in index.html):
//   core/* → systems/* → ui/* → AppInit.js → bootstrap.js
'use strict';
window.addEventListener('DOMContentLoaded', () => {
  LeftSidebarTabs.init();
  AppInit.run();
  RightSidebarTabs.init();
});
