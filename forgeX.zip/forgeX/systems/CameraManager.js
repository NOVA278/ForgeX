'use strict';
const CameraManager = (() => {
  // ── Viewport (editor) camera ──────────────────────────────────────────────
  let _viewportCamera = null;
  const _target = new THREE.Vector3();
  const _state = {
    isOrbiting: false, isPanning: false,
    lastX: 0, lastY: 0,
    spherical: { theta: Math.PI / 4, phi: Math.PI / 3.5, radius: 8 }
  };
  let _gizmoCaptured = false;

  function setGizmoCaptured(v) { _gizmoCaptured = v; }
  function isGizmoCaptured()   { return _gizmoCaptured; }

  // ── Init ──────────────────────────────────────────────────────────────────

  function init(canvas) {
    const { width, height } = RendererManager.getSize();

    _viewportCamera = new THREE.PerspectiveCamera(55, width / height, 0.1, 200);
    _updateViewportPosition();

    EventBus.on('renderer:resize', ({ width, height }) => {
      _viewportCamera.aspect = width / height;
      _viewportCamera.updateProjectionMatrix();
    });

    _bindPointerEvents(canvas);
    _bindWheelEvent(canvas);
    _bindTouchEvents(canvas);
  }

  // ── Viewport camera orbit math ────────────────────────────────────────────

  function _updateViewportPosition() {
    const { theta, phi, radius } = _state.spherical;
    const sinPhi = Math.sin(phi);
    _viewportCamera.position.set(
      _target.x + radius * sinPhi * Math.sin(theta),
      _target.y + radius * Math.cos(phi),
      _target.z + radius * sinPhi * Math.cos(theta)
    );
    _viewportCamera.lookAt(_target);
  }

  // ── Active camera pipeline ────────────────────────────────────────────────

  function getActiveCamera() {
    return (_activeSceneCamera || _viewportCamera);
  }

  // ── Scene-camera override ─────────────────────────────────────────────────
  let _activeSceneCamera = null;
  let _orbitEnabled      = true;

  function _setActiveSceneCamera(cam) {
    _activeSceneCamera = cam;
  }
  function setOrbitEnabled(v) {
    _orbitEnabled = !!v;
  }

  // ── Pointer controls ──────────────────────────────────────────────────────

  function _bindPointerEvents(canvas) {
    canvas.addEventListener('mousedown', e => {
      if (_gizmoCaptured) return;
      if (!_orbitEnabled) return;
      // Middle mouse button = orbit
      if (e.button === 1) {
        if (e.shiftKey) {
          _state.isPanning = true;
        } else {
          _state.isOrbiting = true;
        }
        _state.lastX = e.clientX; _state.lastY = e.clientY; e.preventDefault();
      }
      // Alt + left drag = orbit (Blender alt-rotate shortcut)
      else if (e.button === 0 && e.altKey) {
        if (e.shiftKey) {
          _state.isPanning = true;
        } else {
          _state.isOrbiting = true;
        }
        _state.lastX = e.clientX; _state.lastY = e.clientY; e.preventDefault();
      }
    });

    window.addEventListener('mousemove', e => {
      if (_gizmoCaptured) return;
      const dx = e.clientX - _state.lastX, dy = e.clientY - _state.lastY;
      _state.lastX = e.clientX; _state.lastY = e.clientY;
      if (!_orbitEnabled) return;
      if (_state.isOrbiting) {
        _state.spherical.theta -= dx * 0.005;
        _state.spherical.phi = Math.max(0.05, Math.min(Math.PI - 0.05, _state.spherical.phi - dy * 0.005));
        _updateViewportPosition();
      } else if (_state.isPanning) {
        const s = _state.spherical.radius * 0.0015;
        const r = new THREE.Vector3().crossVectors(_viewportCamera.getWorldDirection(new THREE.Vector3()), _viewportCamera.up).normalize();
        _target.addScaledVector(r, -dx * s);
        _target.addScaledVector(_viewportCamera.up, -dy * s);
        _updateViewportPosition();
      }
    });

    window.addEventListener('mouseup', e => {
      if (e.button === 1) { _state.isOrbiting = false; _state.isPanning = false; }
      if (e.button === 0) { _state.isOrbiting = false; _state.isPanning = false; }
    });

    canvas.addEventListener('contextmenu', e => e.preventDefault());
  }

  function _bindWheelEvent(canvas) {
    canvas.addEventListener('wheel', e => {
      e.preventDefault();
      if (!_orbitEnabled) return;
      _state.spherical.radius = Math.max(1, Math.min(60, _state.spherical.radius * (1 + e.deltaY * 0.001)));
      _updateViewportPosition();
    }, { passive: false });
  }

  function _bindTouchEvents(canvas) {
    let lastDist = 0, lastMidX = 0, lastMidY = 0;

    function _applyCameraTouchMove(dx, dy) {
      const root = (typeof SceneCameraSystem !== 'undefined' && SceneCameraSystem.isPreviewActive())
        ? SceneCameraSystem.getPreviewRoot() : null;
      if (!root) return false;
      root.rotation.order = 'YXZ';
      root.rotation.y -= dx * 0.006;
      root.rotation.x  = Math.max(-Math.PI / 2 + 0.01,
                          Math.min( Math.PI / 2 - 0.01, root.rotation.x - dy * 0.006));
      return true;
    }
    function _applyCameraPanMove(dx, dy) {
      const root = (typeof SceneCameraSystem !== 'undefined' && SceneCameraSystem.isPreviewActive())
        ? SceneCameraSystem.getPreviewRoot() : null;
      if (!root) return false;
      const right = new THREE.Vector3(1, 0, 0).applyQuaternion(root.quaternion);
      const up    = new THREE.Vector3(0, 1, 0).applyQuaternion(root.quaternion);
      root.position.addScaledVector(right, -dx * 0.01);
      root.position.addScaledVector(up,     dy * 0.01);
      return true;
    }
    function _applyCameraDolly(delta) {
      const root = (typeof SceneCameraSystem !== 'undefined' && SceneCameraSystem.isPreviewActive())
        ? SceneCameraSystem.getPreviewRoot() : null;
      if (!root) return false;
      const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(root.quaternion);
      root.position.addScaledVector(fwd, delta * 0.04);
      return true;
    }

    canvas.addEventListener('touchstart', e => {
      if (_gizmoCaptured) return;
      if (!_orbitEnabled) {
        if (e.touches.length === 2) {
          const [a, b] = e.touches;
          lastDist = Math.hypot(b.clientX - a.clientX, b.clientY - a.clientY);
          lastMidX = (a.clientX + b.clientX) / 2; lastMidY = (a.clientY + b.clientY) / 2;
        } else if (e.touches.length === 1) {
          _state.lastX = e.touches[0].clientX; _state.lastY = e.touches[0].clientY;
        }
        return;
      }
      if (e.touches.length === 2) {
        const [a, b] = e.touches;
        lastDist = Math.hypot(b.clientX - a.clientX, b.clientY - a.clientY);
        lastMidX = (a.clientX + b.clientX) / 2; lastMidY = (a.clientY + b.clientY) / 2;
      } else if (e.touches.length === 1) {
        _state.lastX = e.touches[0].clientX; _state.lastY = e.touches[0].clientY;
      }
    }, { passive: true });

    canvas.addEventListener('touchmove', e => {
      e.preventDefault();
      if (_gizmoCaptured) return;
      if (!_orbitEnabled) {
        if (e.touches.length === 1) {
          const dx = e.touches[0].clientX - _state.lastX, dy = e.touches[0].clientY - _state.lastY;
          _state.lastX = e.touches[0].clientX; _state.lastY = e.touches[0].clientY;
          _applyCameraTouchMove(dx, dy);
        } else if (e.touches.length === 2) {
          const [a, b] = e.touches;
          const dist = Math.hypot(b.clientX - a.clientX, b.clientY - a.clientY);
          const midX = (a.clientX + b.clientX) / 2, midY = (a.clientY + b.clientY) / 2;
          _applyCameraDolly(dist - lastDist);
          _applyCameraPanMove(midX - lastMidX, midY - lastMidY);
          lastDist = dist; lastMidX = midX; lastMidY = midY;
        }
        return;
      }
      if (e.touches.length === 1) {
        const dx = e.touches[0].clientX - _state.lastX, dy = e.touches[0].clientY - _state.lastY;
        _state.lastX = e.touches[0].clientX; _state.lastY = e.touches[0].clientY;
        _state.spherical.theta -= dx * 0.006;
        _state.spherical.phi = Math.max(0.05, Math.min(Math.PI - 0.05, _state.spherical.phi - dy * 0.006));
        _updateViewportPosition();
      } else if (e.touches.length === 2) {
        const [a, b] = e.touches;
        const dist = Math.hypot(b.clientX - a.clientX, b.clientY - a.clientY);
        const midX = (a.clientX + b.clientX) / 2, midY = (a.clientY + b.clientY) / 2;
        _state.spherical.radius = Math.max(1, Math.min(60, _state.spherical.radius - (dist - lastDist) * 0.02));
        const dx = midX - lastMidX, dy = midY - lastMidY;
        const panSpeed = _state.spherical.radius * 0.002;
        const right = new THREE.Vector3().crossVectors(_viewportCamera.getWorldDirection(new THREE.Vector3()), _viewportCamera.up).normalize();
        _target.addScaledVector(right, -dx * panSpeed);
        _target.addScaledVector(_viewportCamera.up, dy * panSpeed);
        lastDist = dist; lastMidX = midX; lastMidY = midY;
        _updateViewportPosition();
      }
    }, { passive: false });

    canvas.addEventListener('touchend', e => {
      if (e.touches.length === 1) { _state.lastX = e.touches[0].clientX; _state.lastY = e.touches[0].clientY; }
    }, { passive: true });
  }

  // ── View presets (viewport only) ──────────────────────────────────────────

  function setViewPreset(preset) {
    switch (preset) {
      case 'top':    _state.spherical.phi = 0.01;         _state.spherical.theta = 0;           break;
      case 'bottom': _state.spherical.phi = Math.PI-0.01; _state.spherical.theta = 0;           break;
      case 'front':  _state.spherical.phi = Math.PI/2;    _state.spherical.theta = 0;           break;
      case 'back':   _state.spherical.phi = Math.PI/2;    _state.spherical.theta = Math.PI;     break;
      case 'right':  _state.spherical.phi = Math.PI/2;    _state.spherical.theta = -Math.PI/2;  break;
      case 'left':   _state.spherical.phi = Math.PI/2;    _state.spherical.theta =  Math.PI/2;  break;
      case 'persp':  _state.spherical.phi = Math.PI/3.5;  _state.spherical.theta = Math.PI/4;   break;
    }
    _updateViewportPosition();
  }

  function focusOnObject(obj) {
    if (!obj) return;
    const box    = new THREE.Box3().setFromObject(obj);
    const center = box.getCenter(new THREE.Vector3());
    const size   = box.getSize(new THREE.Vector3()).length();
    _target.copy(center);
    _state.spherical.radius = Math.max(3, size * 2.5);
    _updateViewportPosition();
  }

  function focusOnPoint(pt, dist) {
    _target.copy(pt);
    _state.spherical.radius = dist || 4;
    _updateViewportPosition();
  }

  // getCamera() — always returns the EDITOR viewport camera (for raycasting etc.)
  function getCamera() { return _viewportCamera; }

  return {
    init, getCamera, getActiveCamera,
    setViewPreset, focusOnObject, focusOnPoint,
    setGizmoCaptured, isGizmoCaptured,
    _setActiveSceneCamera, setOrbitEnabled,
  };
})();

// ══════════════════════════════════════════════════════
//  ObjectManager
// ══════════════════════════════════════════════════════
