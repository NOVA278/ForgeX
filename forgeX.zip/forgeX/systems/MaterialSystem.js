'use strict';
const MaterialSystem = (() => {

  // Per-mesh material data store: mesh.uuid → matData
  const _store = new Map();

  // Image cache: dataUrl → HTMLImageElement (decoded once, reused across materials)
  const _imgCache = new Map();

  // ── Map slot descriptors ──────────────────────────────────────────────────
  // Each entry: { key, fileInputId, slotId, labelId, thumbId, clearId, threeKey, isSRGB }
  const MAP_SLOTS = [
    { key:'normalMap',     fileInputId:'mat-normalmap-file',    slotId:'mat-normal-slot',      labelId:'mat-normal-label',      thumbId:'mat-normal-thumb',      clearId:'mat-normal-clear',      threeKey:'normalMap',     isSRGB:false },
    { key:'roughnessMap',  fileInputId:'mat-roughmap-file',     slotId:'mat-roughmap-slot',    labelId:'mat-roughmap-label',    thumbId:'mat-roughmap-thumb',    clearId:'mat-roughmap-clear',    threeKey:'roughnessMap',  isSRGB:false },
    { key:'metalnessMap',  fileInputId:'mat-metalmap-file',     slotId:'mat-metalmap-slot',    labelId:'mat-metalmap-label',    thumbId:'mat-metalmap-thumb',    clearId:'mat-metalmap-clear',    threeKey:'metalnessMap',  isSRGB:false },
    { key:'aoMap',         fileInputId:'mat-aomap-file',        slotId:'mat-aomap-slot',       labelId:'mat-aomap-label',       thumbId:'mat-aomap-thumb',       clearId:'mat-aomap-clear',       threeKey:'aoMap',         isSRGB:false },
    { key:'emissiveMap',   fileInputId:'mat-emissivemap-file',  slotId:'mat-emissivemap-slot', labelId:'mat-emissivemap-label', thumbId:'mat-emissivemap-thumb', clearId:'mat-emissivemap-clear', threeKey:'emissiveMap',   isSRGB:true  },
  ];

  const DEFAULT = {
    name: 'Material',
    color: '#c8c8c8',
    roughness: 0.58,
    metalness: 0.02,
    opacity: 1.0,
    emissive: '#000000',
    emissiveIntensity: 0.0,
    texDataUrl: null,
    textureName: null,
    // Advanced maps
    normalMapDataUrl: null,    normalMapName: null,    normalScale: 1.0,
    roughnessMapDataUrl: null, roughnessMapName: null,
    metalnessMapDataUrl: null, metalnessMapName: null,
    aoMapDataUrl: null,        aoMapName: null,        aoMapIntensity: 1.0,   aoEnabled: true,
    emissiveMapDataUrl: null,  emissiveMapName: null,
    // UV transforms (applied to all texture maps)
    uvRepeatX: 1.0, uvRepeatY: 1.0,
    uvOffsetX: 0.0, uvOffsetY: 0.0,
    uvRotation: 0.0,
  };

  // Map key → { dataUrl, name } accessors on matData
  const MAP_DATA_KEYS = {
    normalMap:    { url:'normalMapDataUrl',    name:'normalMapName'    },
    roughnessMap: { url:'roughnessMapDataUrl', name:'roughnessMapName' },
    metalnessMap: { url:'metalnessMapDataUrl', name:'metalnessMapName' },
    aoMap:        { url:'aoMapDataUrl',        name:'aoMapName'        },
    emissiveMap:  { url:'emissiveMapDataUrl',  name:'emissiveMapName'  },
  };

  // ── Helpers ──────────────────────────────────────────

  function _hexToInt(hex) { return parseInt(hex.replace('#',''), 16); }
  function _intToHex(int) { return '#' + ('000000' + int.toString(16)).slice(-6); }
  function _clamp01(v)    { return Math.max(0, Math.min(1, v)); }

  // ── Store access ─────────────────────────────────────

  function getMatData(mesh) {
    if (!mesh) return null;
    if (!_store.has(mesh.uuid)) {
      const mat = mesh.material;
      const data = Object.assign({}, DEFAULT);
      if (mat) {
        if (mat.color) data.color = _intToHex(mat.color.getHex());
        data.roughness = mat.roughness !== undefined ? mat.roughness : DEFAULT.roughness;
        data.metalness = mat.metalness !== undefined ? mat.metalness : DEFAULT.metalness;
        data.opacity   = mat.opacity   !== undefined ? mat.opacity   : 1.0;
        // Never snapshot the selection/edit-mode emissive tint into stored data.
        // If the mesh is currently selected or being edited, the emissive on the
        // material is an overlay color — not the user's intended emissive value.
        // Always default to black unless explicitly set by the user via the UI.
        data.emissive          = '#000000';
        data.emissiveIntensity = 0;
      }
      data.name = mesh.name + '_Mat';
      _store.set(mesh.uuid, data);
    }
    return _store.get(mesh.uuid);
  }

  function setMatData(mesh, partial) {
    if (!mesh) return;
    const data = getMatData(mesh);
    Object.assign(data, partial);
    _applyToMesh(mesh);
  }

  function removeMatData(uuid) { _store.delete(uuid); }

  // ── Build / update a THREE.Texture from a dataUrl ────────────────────────

  function _buildTexture(dataUrl, isSRGB, uvData, callback) {
    function _applyImage(img) {
      const tex = new THREE.Texture();
      tex.image           = img;
      tex.wrapS           = THREE.RepeatWrapping;
      tex.wrapT           = THREE.RepeatWrapping;
      tex.generateMipmaps = true;
      tex.minFilter       = THREE.LinearMipMapLinearFilter;
      tex.magFilter       = THREE.LinearFilter;
      if (isSRGB) {
        if (THREE.sRGBEncoding !== undefined)   tex.encoding  = THREE.sRGBEncoding;
        if (typeof THREE.SRGBColorSpace !== 'undefined' && tex.colorSpace !== undefined)
          tex.colorSpace = THREE.SRGBColorSpace;
      } else {
        if (THREE.LinearEncoding !== undefined) tex.encoding  = THREE.LinearEncoding;
        if (typeof THREE.LinearSRGBColorSpace !== 'undefined' && tex.colorSpace !== undefined)
          tex.colorSpace = THREE.LinearSRGBColorSpace;
      }
      _applyUVTransformToTexture(tex, uvData);
      tex.needsUpdate = true;
      callback(tex);
    }

    if (_imgCache.has(dataUrl)) {
      const cached = _imgCache.get(dataUrl);
      if (cached.complete && cached.naturalWidth > 0) { _applyImage(cached); return; }
    }
    const img = new Image();
    img.onload  = () => { _imgCache.set(dataUrl, img); _applyImage(img); };
    img.onerror = () => callback(null);
    img.src = dataUrl;
  }

  // ── Apply UV transform (repeat/offset/rotation) to a texture ─────────────

  function _applyUVTransformToTexture(tex, uvData) {
    if (!tex || !uvData) return;
    tex.repeat.set(
      isFinite(uvData.uvRepeatX) ? uvData.uvRepeatX : 1,
      isFinite(uvData.uvRepeatY) ? uvData.uvRepeatY : 1
    );
    tex.offset.set(
      isFinite(uvData.uvOffsetX) ? uvData.uvOffsetX : 0,
      isFinite(uvData.uvOffsetY) ? uvData.uvOffsetY : 0
    );
    tex.rotation = isFinite(uvData.uvRotation) ? (uvData.uvRotation * Math.PI / 180) : 0;
    tex.needsUpdate = true;
  }

  // ── Apply all UV transforms to all live textures on a material ────────────

  function _applyUVTransformsToMaterial(mat, uvData) {
    const texSlots = ['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap'];
    texSlots.forEach(slot => {
      if (mat[slot]) _applyUVTransformToTexture(mat[slot], uvData);
    });
    mat.needsUpdate = true;
  }

  // ── Main apply to THREE mesh ──────────────────────────────────────────────

  function _applyToMesh(mesh) {
    if (!mesh || !mesh.material) return;
    const isEditing = !!mesh.userData._matEditing;
    // Apply material data (color, roughness, emissive, maps etc.)
    _applyDataToMaterial(mesh.material, getMatData(mesh));
    // In edit mode: flat shading prevents stretched normals; FrontSide avoids overlay z-fighting.
    // No emissive override — the edit toolbar and orange wireframe already signal edit mode clearly.
    if (isEditing) {
      mesh.material.flatShading = true;
      mesh.material.side = THREE.FrontSide;
      mesh.material.needsUpdate = true;
    }
    // Selection highlight is handled entirely by SelectionOutline (wireframe) — never emissive.
  }

  function _applyDataToMaterial(mat, data) {
    mat.color.set(_hexToInt(data.color));
    mat.roughness   = _clamp01(data.roughness);
    mat.metalness   = _clamp01(data.metalness);
    mat.opacity     = _clamp01(data.opacity);
    mat.transparent = data.opacity < 1.0;
    mat.depthWrite  = data.opacity >= 1.0;
    mat.emissive.set(_hexToInt(data.emissive));
    mat.emissiveIntensity = Math.max(0, data.emissiveIntensity);

    // AO intensity — zero it out if aoEnabled is false
    const aoOn = data.aoEnabled !== false;
    mat.aoMapIntensity = aoOn ? (isFinite(data.aoMapIntensity) ? data.aoMapIntensity : 1.0) : 0.0;

    // Normal map scale
    if (mat.normalScale) {
      const ns = isFinite(data.normalScale) ? data.normalScale : 1.0;
      mat.normalScale.set(ns, ns);
    }

    // Ensure uv2 exists for aoMap (Three.js r128 needs uv2)
    _ensureUV2(mat);

    // ── Base albedo texture ────────────────────
    _syncMapSlot(mat, 'map', data.texDataUrl, true, data);

    // ── Advanced maps ─────────────────────────
    _syncMapSlot(mat, 'normalMap',     data.normalMapDataUrl,    false, data);
    _syncMapSlot(mat, 'roughnessMap',  data.roughnessMapDataUrl, false, data);
    _syncMapSlot(mat, 'metalnessMap',  data.metalnessMapDataUrl, false, data);
    _syncMapSlot(mat, 'aoMap',         data.aoMapDataUrl,        false, data);
    _syncMapSlot(mat, 'emissiveMap',   data.emissiveMapDataUrl,  true,  data);

    mat.needsUpdate = true;
  }

  // Sync a single map slot on a material — loads if needed, clears if null
  function _syncMapSlot(mat, slotName, dataUrl, isSRGB, uvData) {
    const LOADING = '__loading__';
    const sentinel = `_${slotName}Url`;

    if (!dataUrl) {
      if (mat[slotName]) { mat[slotName].dispose(); mat[slotName] = null; }
      mat[sentinel] = null;
      return;
    }

    const alreadyLoaded = mat[sentinel] && mat[sentinel] !== LOADING && mat[sentinel] === dataUrl;
    if (alreadyLoaded) {
      // Just refresh UV transforms in case they changed
      if (mat[slotName]) _applyUVTransformToTexture(mat[slotName], uvData);
      return;
    }
    if (mat[sentinel] === LOADING) return;

    mat[sentinel] = LOADING;
    _buildTexture(dataUrl, isSRGB, uvData, (tex) => {
      if (!tex) { mat[sentinel] = null; return; }
      if (mat[slotName]) mat[slotName].dispose();
      mat[slotName]   = tex;
      mat[sentinel]   = dataUrl;
      // Re-enforce opacity/transparency so async texture load doesn't
      // accidentally make the object transparent (e.g. when applying a normal map).
      const opacity = isFinite(mat.opacity) ? mat.opacity : 1.0;
      mat.transparent = opacity < 1.0;
      mat.depthWrite  = opacity >= 1.0;
      mat.needsUpdate = true;
    });
  }

  // Ensure uv2 attribute exists (needed for aoMap in Three.js r128)
  function _ensureUV2(mat) {
    // This is handled at the geometry level when needed; flag on material
    // so consumers know to set uv2 = uv copy on the geometry.
    mat._needsUV2 = true;
  }

  // Full restore after selection state clears
  function restoreFromData(mesh) {
    if (!mesh || !mesh.material) return;
    const data = getMatData(mesh);
    const mat  = mesh.material;
    // Force reload sentinel for all slots so textures are re-applied
    ['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap'].forEach(slot => {
      mat[`_${slot}Url`] = null;
    });
    // Reset emissive override flags so emissive is restored from data
    mesh.userData._matSelected = false;
    mesh.userData._matEditing  = false;
    _applyDataToMaterial(mat, data);
  }

  // ── Serialise / Deserialise ───────────────────────────

  function serialise(mesh) {
    if (!mesh) return null;
    return Object.assign({}, getMatData(mesh));
  }

  function deserialise(mesh, saved) {
    if (!mesh || !saved) return;
    const data = Object.assign({}, DEFAULT, saved);
    // Backwards compat
    if (!data.textureName && data.texDataUrl) data.textureName = 'Texture';
    // Default new UV fields for old saves
    if (!isFinite(data.uvRepeatX)) data.uvRepeatX = 1;
    if (!isFinite(data.uvRepeatY)) data.uvRepeatY = 1;
    if (!isFinite(data.uvOffsetX)) data.uvOffsetX = 0;
    if (!isFinite(data.uvOffsetY)) data.uvOffsetY = 0;
    if (!isFinite(data.uvRotation)) data.uvRotation = 0;

    _store.set(mesh.uuid, data);
    mesh.userData._matSelected = false;
    mesh.userData._matEditing  = false;
    // Clear all sentinels and stale GPU maps
    if (mesh.material) {
      ['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap'].forEach(slot => {
        mesh.material[`_${slot}Url`] = null;
        if (mesh.material[slot]) { mesh.material[slot].dispose(); mesh.material[slot] = null; }
      });
      mesh.material.needsUpdate = true;
    }
    _applyDataToMaterial(mesh.material, data);
  }

  // ── UI ────────────────────────────────────────────────

  let _collapsed    = false;
  let _uvCollapsed  = false;
  let _texFileInput = null;

  function initUI() {
    _texFileInput = document.getElementById('mat-tex-file-input');

    // Collapsible header (main material)
    const header = document.getElementById('mat-section-header');
    if (header) {
      header.addEventListener('click', () => {
        _collapsed = !_collapsed;
        header.classList.toggle('collapsed', _collapsed);
        const body = document.getElementById('mat-body');
        if (body) body.style.display = _collapsed ? 'none' : '';
      });
    }

    // UV section collapsible
    const uvHeader = document.getElementById('mat-uv-header');
    if (uvHeader) {
      uvHeader.addEventListener('click', () => {
        _uvCollapsed = !_uvCollapsed;
        uvHeader.classList.toggle('collapsed', _uvCollapsed);
        const uvBody = document.getElementById('mat-uv-body');
        if (uvBody) uvBody.style.display = _uvCollapsed ? 'none' : '';
      });
    }

    // Name
    const nameInput = document.getElementById('mat-name');
    if (nameInput) {
      nameInput.addEventListener('input', () => {
        const obj = SelectionSystem.getSelected(); if (!obj) return;
        setMatData(obj, { name: nameInput.value });
      });
    }

    // Base color
    _bindColorPair('mat-color', 'mat-color-hex', 'color');

    // Base texture
    if (_texFileInput) {
      _texFileInput.addEventListener('change', () => {
        const file = _texFileInput.files[0]; if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
          const obj = SelectionSystem.getSelected(); if (!obj) return;
          if (obj.material) obj.material._mapUrl = null;
          setMatData(obj, { texDataUrl: e.target.result, textureName: file.name });
          _refreshTexUI(e.target.result, file.name);
        };
        reader.readAsDataURL(file);
      });
    }
    const texBtn = document.getElementById('mat-tex-btn');
    if (texBtn) texBtn.addEventListener('click', () => { if (_texFileInput) { _texFileInput.value=''; _texFileInput.click(); } });
    const texClear = document.getElementById('mat-tex-clear');
    if (texClear) {
      texClear.addEventListener('click', (e) => {
        e.stopPropagation();
        const obj = SelectionSystem.getSelected(); if (!obj) return;
        if (obj.material) obj.material._mapUrl = null;
        setMatData(obj, { texDataUrl: null, textureName: null });
        _refreshTexUI(null, null);
      });
    }

    // Sliders
    _bindSlider('mat-roughness',        'mat-roughness-val',         2, (v) => ({ roughness: v }));
    _bindSlider('mat-metalness',        'mat-metalness-val',         2, (v) => ({ metalness: v }));
    _bindSlider('mat-opacity',          'mat-opacity-val',           2, (v) => ({ opacity: v }));
    _bindSlider('mat-emissive-intensity','mat-emissive-intensity-val',2,(v) => ({ emissiveIntensity: v }));
    _bindSlider('mat-normal-scale',     'mat-normal-scale-val',      2, (v) => ({ normalScale: v*3 })); // 0-3 range
    _bindSlider('mat-ao-intensity',     'mat-ao-intensity-val',      2, (v) => ({ aoMapIntensity: v }));

    // AO on/off toggle
    const aoToggleBtn = document.getElementById('mat-ao-toggle');
    if (aoToggleBtn) {
      aoToggleBtn.addEventListener('click', () => {
        const mesh = SelectionSystem ? SelectionSystem.getSelected() : null;
        const data = mesh ? getMatData(mesh) : null;
        if (!data) return;
        const nowOn = data.aoEnabled === false; // flip
        setMatData(mesh, { aoEnabled: nowOn });
        aoToggleBtn.textContent = nowOn ? 'ON' : 'OFF';
        aoToggleBtn.style.background = nowOn ? 'var(--accent-dim)' : 'var(--bg-active)';
        aoToggleBtn.style.color      = nowOn ? 'var(--accent)'     : 'var(--text-dim)';
        aoToggleBtn.style.borderColor= nowOn ? 'var(--accent-dim)' : 'var(--border)';
      });
    }

    // Emissive color
    _bindColorPair('mat-emissive', 'mat-emissive-hex', 'emissive');

    // ── Advanced map slots ──────────────────────────────
    MAP_SLOTS.forEach(slot => {
      _initMapSlot(slot);
    });

    // ── UV controls ──────────────────────────────────────
    _bindUVInput('mat-uv-repeat-x', 'uvRepeatX');
    _bindUVInput('mat-uv-repeat-y', 'uvRepeatY');
    _bindUVInput('mat-uv-offset-x', 'uvOffsetX');
    _bindUVInput('mat-uv-offset-y', 'uvOffsetY');
    _bindUVInput('mat-uv-rotation', 'uvRotation');

    const resetBtn = document.getElementById('mat-uv-reset');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        const obj = SelectionSystem.getSelected(); if (!obj) return;
        setMatData(obj, { uvRepeatX:1, uvRepeatY:1, uvOffsetX:0, uvOffsetY:0, uvRotation:0 });
        _syncUVFieldsFromData(getMatData(obj));
        // Re-apply UV transforms to live textures
        if (obj.material) _applyUVTransformsToMaterial(obj.material, getMatData(obj));
      });
    }
  }

  function _initMapSlot(slot) {
    const slotEl  = document.getElementById(slot.slotId);
    const fileEl  = document.getElementById(slot.fileInputId);
    const clearEl = document.getElementById(slot.clearId);
    if (!slotEl || !fileEl) return;

    slotEl.addEventListener('click', (e) => {
      if (clearEl && clearEl.contains(e.target)) return; // handled by clear button
      fileEl.value = '';
      fileEl.click();
    });

    fileEl.addEventListener('change', () => {
      const file = fileEl.files[0]; if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const obj = SelectionSystem.getSelected(); if (!obj) return;
        const update = {};
        update[MAP_DATA_KEYS[slot.key].url]  = ev.target.result;
        update[MAP_DATA_KEYS[slot.key].name] = file.name;
        if (obj.material) obj.material[`_${slot.threeKey}Url`] = null;
        setMatData(obj, update);
        _refreshMapSlotUI(slot, ev.target.result, file.name);
        _showMapExtras(slot.key, true);
      };
      reader.readAsDataURL(file);
    });

    if (clearEl) {
      clearEl.addEventListener('click', (e) => {
        e.stopPropagation();
        const obj = SelectionSystem.getSelected(); if (!obj) return;
        if (obj.material) obj.material[`_${slot.threeKey}Url`] = null;
        const update = {};
        update[MAP_DATA_KEYS[slot.key].url]  = null;
        update[MAP_DATA_KEYS[slot.key].name] = null;
        setMatData(obj, update);
        _refreshMapSlotUI(slot, null, null);
        _showMapExtras(slot.key, false);
      });
    }
  }

  function _showMapExtras(mapKey, show) {
    if (mapKey === 'normalMap') {
      const row = document.getElementById('mat-normal-scale-row');
      if (row) row.style.display = show ? '' : 'none';
    }
    if (mapKey === 'aoMap') {
      const row = document.getElementById('mat-ao-intensity-row');
      if (row) row.style.display = show ? '' : 'none';
    }
  }

  function _refreshMapSlotUI(slot, dataUrl, fileName) {
    const slotEl  = document.getElementById(slot.slotId);
    const labelEl = document.getElementById(slot.labelId);
    const thumbEl = document.getElementById(slot.thumbId);
    const clearEl = document.getElementById(slot.clearId);
    if (!slotEl) return;
    if (dataUrl) {
      slotEl.classList.add('has-map');
      if (labelEl) labelEl.textContent = fileName ? fileName.substring(0,16) : 'Set';
      if (thumbEl) { thumbEl.src = dataUrl; }
      if (clearEl) clearEl.style.display = 'flex';
    } else {
      slotEl.classList.remove('has-map');
      if (labelEl) labelEl.textContent = 'None';
      if (thumbEl) { thumbEl.src = ''; }
      if (clearEl) clearEl.style.display = 'none';
    }
  }

  function _bindColorPair(pickerId, hexId, dataKey) {
    const picker = document.getElementById(pickerId);
    const hex    = document.getElementById(hexId);
    if (picker) {
      picker.addEventListener('input', () => {
        const v = picker.value;
        if (hex) hex.value = v;
        const obj = SelectionSystem.getSelected(); if (!obj) return;
        const update = {}; update[dataKey] = v;
        setMatData(obj, update);
      });
    }
    if (hex) {
      hex.addEventListener('input', () => {
        const raw = hex.value.trim();
        if (!/^#[0-9a-fA-F]{6}$/.test(raw)) return;
        if (picker) picker.value = raw;
        const obj = SelectionSystem.getSelected(); if (!obj) return;
        const update = {}; update[dataKey] = raw;
        setMatData(obj, update);
      });
    }
  }

  function _bindSlider(sliderId, valId, decimals, dataFn) {
    const slider = document.getElementById(sliderId);
    const valEl  = document.getElementById(valId);
    if (!slider) return;
    slider.addEventListener('input', () => {
      const v = parseInt(slider.value) / 100;
      if (valEl) valEl.textContent = v.toFixed(decimals);
      const obj = SelectionSystem.getSelected(); if (!obj) return;
      setMatData(obj, dataFn(v));
    });
  }

  function _bindUVInput(inputId, dataKey) {
    const el = document.getElementById(inputId);
    if (!el) return;
    el.addEventListener('input', () => {
      const val = parseFloat(el.value);
      if (!isFinite(val)) return;
      const obj = SelectionSystem.getSelected(); if (!obj) return;
      const update = {}; update[dataKey] = val;
      setMatData(obj, update);
      // Immediately refresh UV transforms on live textures (no full reload needed)
      if (obj.material) _applyUVTransformsToMaterial(obj.material, getMatData(obj));
    });
  }

  function _refreshTexUI(dataUrl, fileName) {
    const btn     = document.getElementById('mat-tex-btn');
    const clear   = document.getElementById('mat-tex-clear');
    const label   = document.getElementById('mat-tex-label');
    const preview = document.getElementById('mat-tex-preview');
    if (!btn) return;
    if (dataUrl) {
      btn.classList.add('has-tex');
      if (label)   label.textContent = fileName ? fileName.substring(0,18) : 'Texture set';
      if (preview) { preview.src = dataUrl; preview.style.display = 'block'; }
      if (clear)   clear.style.display = '';
    } else {
      btn.classList.remove('has-tex');
      if (label)   label.textContent = 'Upload image…';
      if (preview) { preview.src=''; preview.style.display='none'; }
      if (clear)   clear.style.display = 'none';
    }
  }

  function _syncUVFieldsFromData(data) {
    const _set = (id, val) => { const el=document.getElementById(id); if(el) el.value=isFinite(val)?val:0; };
    _set('mat-uv-repeat-x', data.uvRepeatX);
    _set('mat-uv-repeat-y', data.uvRepeatY);
    _set('mat-uv-offset-x', data.uvOffsetX);
    _set('mat-uv-offset-y', data.uvOffsetY);
    _set('mat-uv-rotation', data.uvRotation);
  }

  // Populate all UI fields from a mesh's material data
  function refreshUI(mesh) {
    const panel    = document.getElementById('mat-panel');
    const tabEmpty = document.getElementById('mat-tab-empty');
    if (!panel) return;
    if (!mesh) {
      panel.style.display='none';
      if (tabEmpty) tabEmpty.style.display='';
      return;
    }
    panel.style.display = '';
    if (tabEmpty) tabEmpty.style.display='none';

    const data = getMatData(mesh);

    const nameInput = document.getElementById('mat-name');
    if (nameInput) nameInput.value = data.name;

    const colorPicker = document.getElementById('mat-color');
    const colorHex    = document.getElementById('mat-color-hex');
    if (colorPicker) colorPicker.value = data.color;
    if (colorHex)    colorHex.value    = data.color;

    _setSlider('mat-roughness',         'mat-roughness-val',         2, data.roughness);
    _setSlider('mat-metalness',         'mat-metalness-val',         2, data.metalness);
    _setSlider('mat-opacity',           'mat-opacity-val',           2, data.opacity);
    _setSlider('mat-emissive-intensity','mat-emissive-intensity-val',2, data.emissiveIntensity);

    const emPicker = document.getElementById('mat-emissive');
    const emHex    = document.getElementById('mat-emissive-hex');
    if (emPicker) emPicker.value = data.emissive;
    if (emHex)    emHex.value    = data.emissive;

    // Base texture
    _refreshTexUI(data.texDataUrl, data.textureName || null);

    // Advanced map slots
    MAP_SLOTS.forEach(slot => {
      const urlKey  = MAP_DATA_KEYS[slot.key].url;
      const nameKey = MAP_DATA_KEYS[slot.key].name;
      _refreshMapSlotUI(slot, data[urlKey], data[nameKey]);
      _showMapExtras(slot.key, !!data[urlKey]);
    });

    // Normal scale slider (0-3 range encoded as 0-300)
    const nsSlider = document.getElementById('mat-normal-scale');
    const nsVal    = document.getElementById('mat-normal-scale-val');
    if (nsSlider) nsSlider.value = Math.round((isFinite(data.normalScale)?data.normalScale:1.0) * 100 / 3);
    if (nsVal)    nsVal.textContent = (isFinite(data.normalScale)?data.normalScale:1.0).toFixed(2);

    // AO intensity
    _setSlider('mat-ao-intensity', 'mat-ao-intensity-val', 2, isFinite(data.aoMapIntensity)?data.aoMapIntensity:1.0);

    // AO on/off toggle button state
    const aoToggleBtn = document.getElementById('mat-ao-toggle');
    if (aoToggleBtn) {
      const aoOn = data.aoEnabled !== false;
      aoToggleBtn.textContent = aoOn ? 'ON' : 'OFF';
      aoToggleBtn.style.background = aoOn ? 'var(--accent-dim)' : 'var(--bg-active)';
      aoToggleBtn.style.color      = aoOn ? 'var(--accent)'     : 'var(--text-dim)';
      aoToggleBtn.style.borderColor= aoOn ? 'var(--accent-dim)' : 'var(--border)';
    }

    // UV fields
    _syncUVFieldsFromData(data);
  }

  function _setSlider(sliderId, valId, decimals, value) {
    const slider = document.getElementById(sliderId);
    const valEl  = document.getElementById(valId);
    if (slider) slider.value = Math.round(value * 100);
    if (valEl)  valEl.textContent = value.toFixed(decimals);
  }

  return {
    initUI,
    refreshUI,
    getMatData,
    setMatData,
    removeMatData,
    serialise,
    deserialise,
    restoreFromData,
    _applyToMesh,
    _applyUVTransformsToMaterial,
  };
})();


// ══════════════════════════════════════════════════════
//  LightManager — centralized, fully rebuilt lighting &
//  shadow system for ForgeX.
//  Architecture: UI → LightManager → Three.js Scene
//  ALL lights, shadows, and gizmo-safety are managed here.
// ══════════════════════════════════════════════════════
