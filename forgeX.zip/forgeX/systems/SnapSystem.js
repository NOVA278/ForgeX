'use strict';
const SnapSystem = (() => {
  let _enabled = false;
  let _type = 'grid'; // 'grid'|'vert'|'edge'
  const GRID_SIZE = 0.5;

  function isEnabled() { return _enabled; }
  function getType()   { return _type; }

  function toggle() {
    _enabled = !_enabled;
    _updateUI();
    return _enabled;
  }

  function setType(t) {
    _type = t;
    ['grid','vert','edge'].forEach(s => {
      const el = document.getElementById('snap-type-'+s);
      if(el) el.classList.toggle('active', s===t);
    });
    _updateUI();
  }

  function _updateUI() {
    const btn = document.getElementById('btn-snap');
    const lbl = document.getElementById('snap-btn-label');
    const ind = document.getElementById('snap-indicator');
    const tLbl = document.getElementById('snap-type-label');
    const dropTrigger = document.getElementById('snap-dropdown-trigger');
    if(btn) btn.classList.toggle('active', _enabled);
    if(lbl) lbl.textContent = _enabled ? 'ON' : 'OFF';
    if(ind) {
      ind.classList.toggle('snap-on', _enabled);
      ind.classList.toggle('visible', true);
    }
    if(tLbl) tLbl.textContent = _enabled ? _type.toUpperCase() : 'OFF';
    if(dropTrigger) dropTrigger.classList.toggle('snap-active', _enabled);
    // auto-hide indicator after 2s
    clearTimeout(SnapSystem._hideTimer);
    SnapSystem._hideTimer = setTimeout(() => {
      if(ind) ind.classList.remove('visible');
    }, 2000);
  }

  // Show snap preview dot at screen coords
  function showPreview(sx, sy) {
    const el = document.getElementById('snap-preview');
    if(!el) return;
    el.style.display = 'block';
    el.style.left = sx + 'px';
    el.style.top = sy + 'px';
  }
  function hidePreview() {
    const el = document.getElementById('snap-preview');
    if(el) el.style.display = 'none';
  }

  // Snap a world-space point. Returns {x,y,z} snapped.
  // meshData, mesh needed for vert/edge snap
  function snapPoint(worldPt, meshData, mesh, camera, canvas, excludeVerts) {
    if(!_enabled) return worldPt.clone();

    if(_type === 'grid') {
      return new THREE.Vector3(
        Math.round(worldPt.x / GRID_SIZE) * GRID_SIZE,
        Math.round(worldPt.y / GRID_SIZE) * GRID_SIZE,
        Math.round(worldPt.z / GRID_SIZE) * GRID_SIZE
      );
    }

    if((_type === 'vert' || _type === 'edge') && meshData) {
      const worldMat = mesh.matrixWorld;
      let bestDist = Infinity;
      let bestPos = worldPt.clone();

      if(_type === 'vert') {
        meshData.verts.forEach((v, i) => {
          if(excludeVerts && excludeVerts.has(i)) return;
          const wp = new THREE.Vector3(v.x, v.y, v.z).applyMatrix4(worldMat);
          const d = wp.distanceTo(worldPt);
          if(d < bestDist) { bestDist = d; bestPos = wp; }
        });
      } else { // edge midpoints
        meshData.edges.forEach(e => {
          const va = meshData.verts[e.a], vb = meshData.verts[e.b];
          const mid = new THREE.Vector3(
            (va.x+vb.x)/2, (va.y+vb.y)/2, (va.z+vb.z)/2
          ).applyMatrix4(worldMat);
          const d = mid.distanceTo(worldPt);
          if(d < bestDist) { bestDist = d; bestPos = mid; }
        });
      }

      // Accept the snap only if bestPos is within SNAP_PX pixels of the cursor in screen space.
      // This replaces the old world-space threshold (< 2.0 units) which behaved incorrectly
      // at different zoom levels — too sticky when zoomed in, unusable when zoomed out.
      const SNAP_PX = 20;
      if(camera && canvas) {
        const rect = canvas.getBoundingClientRect();
        const ndcCursor = worldPt.clone().project(camera);
        const ndcSnap   = bestPos.clone().project(camera);
        const pxCursor = { x: (ndcCursor.x+1)*0.5*rect.width, y: (-ndcCursor.y+1)*0.5*rect.height };
        const pxSnap   = { x: (ndcSnap.x  +1)*0.5*rect.width, y: (-ndcSnap.y  +1)*0.5*rect.height };
        const screenDist = Math.sqrt((pxCursor.x-pxSnap.x)**2 + (pxCursor.y-pxSnap.y)**2);
        if(screenDist <= SNAP_PX) {
          showPreview(pxSnap.x, pxSnap.y);
          return bestPos;
        }
      }
      // No snap candidate close enough — return the raw cursor position unchanged
      return worldPt.clone();
    }

    return worldPt.clone();
  }

  return { isEnabled, getType, toggle, setType, showPreview, hidePreview, snapPoint, _hideTimer:null };
})();

// ══════════════════════════════════════════════════════
//  EditModeSystem — vertex/edge/face selection + overlay + transforms
// ══════════════════════════════════════════════════════
