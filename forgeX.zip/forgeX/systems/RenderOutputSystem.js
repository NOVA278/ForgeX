'use strict';
/**
 * RenderOutputSystem — viewport screenshot / render export for ForgeX
 *
 * Captures the current Three.js WebGL canvas and optionally applies
 * post-processing effects (vignette, brightness/contrast, bloom-like glow)
 * before downloading as a PNG or JPEG.
 *
 * A lightweight modal panel lets the user choose:
 *  - Resolution multiplier (1×, 2×, 4×)
 *  - Format (PNG / JPEG)
 *  - Post-processing toggles
 */
const RenderOutputSystem = (() => {

  let _modal  = null;
  let _canvas = null; // preview canvas

  // ── Build UI ──────────────────────────────────────────────────────────────

  function _buildModal() {
    if (_modal) return;
    _modal = document.createElement('div');
    _modal.id = 'render-output-modal';
    _modal.innerHTML = `
      <div class="ro-inner">
        <div class="ro-header">
          <span class="ro-title">
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <rect x="1" y="1.5" width="10" height="9" rx="1" stroke="currentColor" stroke-width="1.2"/>
              <path d="M1 8l3-3 2.5 2.5L9 5l2 3" stroke="currentColor" stroke-width="1" stroke-linejoin="round"/>
              <circle cx="4" cy="5" r="1" fill="currentColor" opacity="0.6"/>
            </svg>
            Render Output
          </span>
          <button class="ro-close" id="ro-close">✕</button>
        </div>

        <div class="ro-body">
          <!-- Preview -->
          <div class="ro-preview-wrap">
            <canvas id="ro-preview-canvas"></canvas>
            <div class="ro-preview-label">Preview</div>
          </div>

          <!-- Settings -->
          <div class="ro-settings">
            <div class="ro-section-label">Resolution</div>
            <div class="ro-radio-group">
              <label class="ro-radio"><input type="radio" name="ro-res" value="1" checked> 1× (viewport)</label>
              <label class="ro-radio"><input type="radio" name="ro-res" value="2"> 2× (HD)</label>
              <label class="ro-radio"><input type="radio" name="ro-res" value="4"> 4× (4K)</label>
            </div>

            <div class="ro-section-label" style="margin-top:10px">Format</div>
            <div class="ro-radio-group">
              <label class="ro-radio"><input type="radio" name="ro-fmt" value="png" checked> PNG (lossless)</label>
              <label class="ro-radio"><input type="radio" name="ro-fmt" value="jpeg"> JPEG (smaller)</label>
            </div>

            <div class="ro-section-label" style="margin-top:10px">Post-Processing</div>
            <label class="ro-check"><input type="checkbox" id="ro-pp-vignette" checked> Vignette</label>
            <label class="ro-check"><input type="checkbox" id="ro-pp-sharpen"> Sharpen</label>
            <label class="ro-check"><input type="checkbox" id="ro-pp-bloom"> Bloom Glow</label>

            <div class="ro-section-label" style="margin-top:10px">Adjustments</div>
            <div class="ro-slider-row">
              <span class="ro-slider-label">Brightness</span>
              <input type="range" id="ro-brightness" min="-50" max="50" value="0" class="ro-slider">
              <span class="ro-slider-val" id="ro-brightness-val">0</span>
            </div>
            <div class="ro-slider-row">
              <span class="ro-slider-label">Contrast</span>
              <input type="range" id="ro-contrast" min="-50" max="50" value="0" class="ro-slider">
              <span class="ro-slider-val" id="ro-contrast-val">0</span>
            </div>
            <div class="ro-slider-row">
              <span class="ro-slider-label">Saturation</span>
              <input type="range" id="ro-saturation" min="-100" max="100" value="0" class="ro-slider">
              <span class="ro-slider-val" id="ro-sat-val">0</span>
            </div>

            <button class="ro-preview-btn" id="ro-preview-btn">↺ Refresh Preview</button>
            <button class="ro-export-btn" id="ro-export-btn">
              <svg width="10" height="10" viewBox="0 0 12 12" fill="none">
                <path d="M2 10h8M6 2v6M3.5 5.5L6 8l2.5-2.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              Export Render
            </button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(_modal);

    _canvas = document.getElementById('ro-preview-canvas');

    document.getElementById('ro-close').addEventListener('click', close);
    _modal.addEventListener('click', e => { if (e.target === _modal) close(); });

    document.getElementById('ro-preview-btn').addEventListener('click', _refreshPreview);
    document.getElementById('ro-export-btn').addEventListener('click', _exportRender);

    // Slider value readouts
    ['brightness', 'contrast', 'saturation'].forEach(id => {
      const slider = document.getElementById('ro-' + id);
      const label  = document.getElementById('ro-' + id.slice(0,2) + (id === 'saturation' ? 'at-val' : id.slice(2) + '-val'));
      if (slider && label) {
        slider.addEventListener('input', () => { label.textContent = slider.value; });
      }
    });
    // Fix IDs for saturation label
    const satSlider = document.getElementById('ro-saturation');
    const satLabel  = document.getElementById('ro-sat-val');
    if (satSlider && satLabel) satSlider.addEventListener('input', () => satLabel.textContent = satSlider.value);
    const brSlider = document.getElementById('ro-brightness');
    const brLabel  = document.getElementById('ro-brightness-val');
    if (brSlider && brLabel) brSlider.addEventListener('input', () => brLabel.textContent = brSlider.value);
    const coSlider = document.getElementById('ro-contrast');
    const coLabel  = document.getElementById('ro-contrast-val');
    if (coSlider && coLabel) coSlider.addEventListener('input', () => coLabel.textContent = coSlider.value);
  }

  // ── Capture ───────────────────────────────────────────────────────────────

  function _getSettings() {
    const res    = parseInt(document.querySelector('input[name="ro-res"]:checked')?.value || '1');
    const fmt    = document.querySelector('input[name="ro-fmt"]:checked')?.value || 'png';
    const vign   = document.getElementById('ro-pp-vignette')?.checked ?? true;
    const sharp  = document.getElementById('ro-pp-sharpen')?.checked  ?? false;
    const bloom  = document.getElementById('ro-pp-bloom')?.checked    ?? false;
    const bright = parseInt(document.getElementById('ro-brightness')?.value || '0');
    const cont   = parseInt(document.getElementById('ro-contrast')?.value   || '0');
    const sat    = parseInt(document.getElementById('ro-saturation')?.value || '0');
    return { res, fmt, vign, sharp, bloom, bright, cont, sat };
  }

  /**
   * Capture the WebGL canvas, apply post-processing on a 2D canvas, return it.
   */
  function _capture(s) {
    // Force a render pass so preserveDrawingBuffer captures latest frame
    if (typeof RendererManager !== 'undefined') {
      const renderer = RendererManager.getRenderer();
      if (renderer) {
        const scene  = SceneManager.getScene();
        const camera = CameraManager.getCamera();
        renderer.render(scene, camera);
      }
    }

    const src = document.getElementById('viewport-canvas');
    if (!src) return null;

    const W = src.width  * s.res;
    const H = src.height * s.res;

    const offscreen = document.createElement('canvas');
    offscreen.width  = W;
    offscreen.height = H;
    const ctx = offscreen.getContext('2d');

    // Draw scaled capture
    ctx.drawImage(src, 0, 0, W, H);

    // ── Brightness / Contrast ─────────────────────────────────────────────
    if (s.bright !== 0 || s.cont !== 0 || s.sat !== 0) {
      const imgData = ctx.getImageData(0, 0, W, H);
      const d = imgData.data;
      const br = s.bright;
      const co = (259 * (s.cont + 255)) / (255 * (259 - s.cont));
      const satF = (s.sat + 100) / 100;

      for (let i = 0; i < d.length; i += 4) {
        let r = d[i], g = d[i+1], b = d[i+2];

        // Brightness
        r += br; g += br; b += br;

        // Contrast
        r = co * (r - 128) + 128;
        g = co * (g - 128) + 128;
        b = co * (b - 128) + 128;

        // Saturation (luma-based)
        const gray = 0.299 * r + 0.587 * g + 0.114 * b;
        r = gray + satF * (r - gray);
        g = gray + satF * (g - gray);
        b = gray + satF * (b - gray);

        d[i]   = Math.max(0, Math.min(255, r));
        d[i+1] = Math.max(0, Math.min(255, g));
        d[i+2] = Math.max(0, Math.min(255, b));
      }
      ctx.putImageData(imgData, 0, 0);
    }

    // ── Bloom (simple bright-pass blur overlay) ───────────────────────────
    if (s.bloom) {
      const bloom = document.createElement('canvas');
      bloom.width = W; bloom.height = H;
      const bctx = bloom.getContext('2d');
      bctx.drawImage(offscreen, 0, 0);
      bctx.filter = 'blur(8px) brightness(1.4)';
      bctx.drawImage(offscreen, 0, 0);
      ctx.globalAlpha = 0.4;
      ctx.globalCompositeOperation = 'screen';
      ctx.drawImage(bloom, 0, 0);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';
    }

    // ── Sharpen (unsharp mask approximation) ─────────────────────────────
    if (s.sharp) {
      const imgData = ctx.getImageData(0, 0, W, H);
      const d = imgData.data;
      const w = W, h = H;
      const copy = new Uint8ClampedArray(d);
      const kernel = [-1/8, -1/8, -1/8, -1/8, 2, -1/8, -1/8, -1/8, -1/8];
      for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
          for (let c = 0; c < 3; c++) {
            let val = 0;
            for (let ky = -1; ky <= 1; ky++) {
              for (let kx = -1; kx <= 1; kx++) {
                val += copy[((y + ky) * w + (x + kx)) * 4 + c] * kernel[(ky+1)*3+(kx+1)];
              }
            }
            d[(y * w + x) * 4 + c] = Math.max(0, Math.min(255, copy[(y * w + x) * 4 + c] + val));
          }
        }
      }
      ctx.putImageData(imgData, 0, 0);
    }

    // ── Vignette ──────────────────────────────────────────────────────────
    if (s.vign) {
      const grad = ctx.createRadialGradient(W/2, H/2, H*0.25, W/2, H/2, H*0.75);
      grad.addColorStop(0, 'rgba(0,0,0,0)');
      grad.addColorStop(1, 'rgba(0,0,0,0.55)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);
    }

    return offscreen;
  }

  function _refreshPreview() {
    const s = _getSettings();
    const captured = _capture(s);
    if (!captured || !_canvas) return;

    const maxPrev = 380;
    const ratio   = Math.min(maxPrev / captured.width, maxPrev / captured.height);
    _canvas.width  = Math.floor(captured.width  * ratio);
    _canvas.height = Math.floor(captured.height * ratio);
    const ctx = _canvas.getContext('2d');
    ctx.drawImage(captured, 0, 0, _canvas.width, _canvas.height);
  }

  function _exportRender() {
    const s        = _getSettings();
    const captured = _capture(s);
    if (!captured) return;

    const mimeType = s.fmt === 'jpeg' ? 'image/jpeg' : 'image/png';
    const quality  = s.fmt === 'jpeg' ? 0.92 : undefined;
    const ext      = s.fmt === 'jpeg' ? '.jpg' : '.png';

    let name = window.prompt('Save render as:', 'forgex_render');
    if (name === null || name.trim() === '') name = 'forgex_render';
    name = name.trim().replace(/\.(png|jpg|jpeg)$/i, '');

    captured.toBlob(blob => {
      const url = URL.createObjectURL(blob);
      const a   = document.createElement('a');
      a.href     = url;
      a.download = name + ext;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, mimeType, quality);
  }

  // ── Open / Close ──────────────────────────────────────────────────────────

  function open() {
    _buildModal();
    _modal.classList.add('active');
    // Slight delay so modal transition completes before capture
    setTimeout(_refreshPreview, 120);
  }

  function close() {
    if (_modal) _modal.classList.remove('active');
  }

  return { open, close };
})();
