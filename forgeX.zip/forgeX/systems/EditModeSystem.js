'use strict';
const EditModeSystem = (() => {
  let _active = false;
  let _mesh = null;       // the object being edited
  let _meshData = null;   // {verts, edges, faces}
  let _camera = null;
  let _canvas = null;
  let _scene = null;

  // Selection state
  let _elemType = 'vert'; // 'vert'|'edge'|'face'
  let _selected = new Set(); // indices
  let _xray = false;

  // Overlay THREE objects
  let _overlayGroup = null;
  let _vertPoints = null;   // THREE.Points for vertices
  let _edgeLines = null;    // THREE.LineSegments for edges
  let _faceMeshes = [];     // per-face highlight overlays

  // ── Edit Gizmo ──
  let _gizmoGroup = null;
  let _editGizmoDragging = false;
  let _editGizmoDragAxis = null;   // 'x'|'y'|'z'
  let _editGizmoDragMode = null;   // 'translate'|'rotate'|'scale'
  let _editGizmoHitPlane = new THREE.Plane();
  let _editGizmoDragStartWorld = new THREE.Vector3();
  let _editGizmoMouseStart = {x:0,y:0};
  let _editGizmoPivot = new THREE.Vector3();     // world-space center of selection
  let _editGizmoDragStartVerts = [];  // copy of affected vert positions before drag
  let _editGizmoActiveTouchId = null;
  let _editGizmoRay = new THREE.Raycaster();
  const _EG_COLORS = {x:0xcc2222,y:0x1a9933,z:0x1a44cc};
  const _EG_COLORS_H = {x:0xff4444,y:0x33cc55,z:0x4477ff};
  const _EG_COLOR_ACT = 0xffcc00;
  let _egAxisMaterials = {}; // axis -> [mats]
  let _egHovered = null;
  let _egTranslateG = null, _egRotateG = null, _egScaleG = null;
  let _egCurrentMode = 'translate'; // default to translate in edit mode

  // Touch/drag state for box select
  let _boxSelecting = false;
  let _tapStart = null;
  let _tapTouchId = null;
  let _mouseMoved = false;
  let _mouseDownPos = {x:0,y:0};
  let _mouseDownConsumedByGizmo = false; // true when gizmo captured this mousedown

  // Raycaster
  const _ray = new THREE.Raycaster();

  // ── Inset state ──
  let _insetActive = false;
  let _insetSnapshot = null;   // deep copy of meshData before inset preview
  let _insetAmount = 0.2;
  let _insetDragStartX = 0;
  let _insetDragStartAmount = 0;
  let _insetTouchId = null;
  let _insetFaceIndices = [];  // selected face indices captured at inset-start

  // ── Bevel state ──
  let _bevelActive = false;
  let _bevelSnapshot = null;   // deep copy of meshData before bevel preview
  let _bevelAmount = 0.1;
  let _bevelDragStartX = 0;
  let _bevelDragStartAmount = 0;
  let _bevelTouchId = null;
  let _bevelEdgeIndices = [];   // selected edge indices captured at bevel-start
  let _bevelInputHandlers = {};

  // ── Colors ──
  const C_VERT_DEFAULT = new THREE.Color(0xffffff);
  const C_VERT_SEL     = new THREE.Color(0xffcc00);
  const C_EDGE_DEFAULT = new THREE.Color(0x4488ff);
  const C_EDGE_SEL     = new THREE.Color(0xff8800);
  const C_FACE_DEFAULT_ALPHA = 0.0;
  const C_FACE_SEL_ALPHA = 0.35;

  function init(canvas, camera, scene) {
    _canvas = canvas;
    _camera = camera;
    _scene  = scene;
  }

  // Stable buf-index → unique-vert-index mapping, built once on enter
  let _bufToUniqVert = null;

  // Called at enter() — original Three.js geometry may not be identity-ordered,
  // so we use position-key matching to map buffer slots to unique vert indices.
  function _buildBufToUniqMapFromGeometry() {
    const geo = _mesh.geometry;
    const posAttr = geo.attributes.position;
    const posCount = posAttr.count;
    const PREC = 5;
    const keyFor = (x,y,z) => `${x.toFixed(PREC)},${y.toFixed(PREC)},${z.toFixed(PREC)}`;
    const keyToUniq = new Map();
    _meshData.verts.forEach((v, vi) => {
      const k = keyFor(v.x, v.y, v.z);
      if(!keyToUniq.has(k)) keyToUniq.set(k, vi);
    });
    _bufToUniqVert = new Int32Array(posCount);
    for(let i=0; i<posCount; i++){
      const x=posAttr.getX(i), y=posAttr.getY(i), z=posAttr.getZ(i);
      const k = keyFor(x,y,z);
      _bufToUniqVert[i] = keyToUniq.has(k) ? keyToUniq.get(k) : -1;
    }
  }

  // Called after _writebackGeometry('topology') — we wrote the buffer ourselves
  // in meshData.verts order, so bufferIndex i maps directly to unique vert i.
  // This avoids position-key collisions when two verts share the same location
  // (e.g. freshly extruded cap verts at distance=0).
  function _buildBufToUniqMap() {
    const geo = _mesh.geometry;
    const posCount = geo.attributes.position.count;
    _bufToUniqVert = new Int32Array(posCount);
    for(let i = 0; i < posCount; i++) {
      _bufToUniqVert[i] = i < _meshData.verts.length ? i : -1;
    }
  }

  // ── Enter/Exit Edit Mode ──
  function enter(mesh) {
    if(_active) exit();
    if(!mesh) return;
    _mesh = mesh;
    _active = true;
    _selected.clear();
    _xray = false; // always start with X-Ray OFF

    // Compute topology
    _meshData = EditMeshData.buildFromGeometry(_mesh.geometry, _mesh);

    // Build stable buffer→vert mapping before any edits happen
    // (key-based because original Three.js geometry isn't identity-ordered)
    _buildBufToUniqMapFromGeometry();

    // Clear any stale undo history from a previous edit session
    UndoHistory.clear();

    // Reset undo/redo button states for edit mode (nothing to undo yet)
    const undoBtn=document.getElementById('btn-undo');
    const redoBtn=document.getElementById('btn-redo');
    if(undoBtn){undoBtn.disabled=true;undoBtn.style.opacity='0.35';undoBtn.style.cursor='not-allowed';}
    if(redoBtn){redoBtn.disabled=true;redoBtn.style.opacity='0.35';redoBtn.style.cursor='not-allowed';}

    // Dim the mesh
    ObjectManager.setEditMode(_mesh, true);

    // Build overlays
    _buildOverlays();
    _buildEditGizmo();

    // Wire input
    _bindInput();
    _bindGizmoInput();

    document.getElementById('edit-toolbar').classList.add('visible');
    document.getElementById('edit-mode-badge').classList.add('visible');
    document.getElementById('edit-props-panel').classList.add('visible');
    document.getElementById('props-content').style.display = 'none';
    document.getElementById('props-empty').style.display = 'none';

    _setXray(_xray);
    _refreshOverlay();
    _refreshUI();
    _updateGizmoVisibility();
    EventBus.emit('editmode:changed', true);
  }

  function exit() {
    if(!_active) return;
    // Cancel any active inset session before exiting
    if(_insetActive) _cancelInset();
    // Cancel any active bevel session before exiting
    if(_bevelActive) _cancelBevel();
    _editGizmoDragging = false;
    _active = false;
    // Restore material/shadow state BEFORE writeback so computeVertexNormals
    // runs with smooth shading active — prevents corrupt normals causing
    // shadow artefacts after extrude or other topology ops.
    if(_mesh){ ObjectManager.setEditMode(_mesh, false); }
    // Force shadow maps to regenerate — castShadow was disabled during edit mode,
    // so the cached shadow map is stale. Without this the object casts no shadow
    // until something else (e.g. adding a light) triggers a shadow map refresh.
    if(typeof RenderLoop !== 'undefined') RenderLoop.resetShadowWarmup();
    // Persist all edit-mode geometry changes to the underlying object
    if(_mesh && _meshData) {
      _writebackGeometry('topology');
      SceneIO.markGeometryEdited(_mesh);
    }
    _bufToUniqVert = null;
    _mouseDownConsumedByGizmo = false;
    _unbindInput();
    _unbindGizmoInput();
    _destroyOverlays();
    _destroyEditGizmo();
    SnapSystem.hidePreview();
    UndoHistory.clear();
    if(_mesh){ ObjectManager.setSelected(_mesh, true); }
    _mesh = null;
    _meshData = null;
    _selected.clear();

    document.getElementById('edit-toolbar').classList.remove('visible');
    document.getElementById('edit-mode-badge').classList.remove('visible');
    document.getElementById('edit-props-panel').classList.remove('visible');
    document.getElementById('props-empty').style.display = '';
    document.getElementById('props-content').style.display = 'none';
    const hint = document.getElementById('edit-transform-hint');
    if(hint) hint.classList.remove('visible');

    // Restore object-mode undo/redo button state
    ObjectUndoHistory._refreshButtons();

    EventBus.emit('editmode:changed', false);
    EventBus.emit('selection:changed', SelectionSystem.getSelected());
  }

  function isActive() { return _active; }
  function getMesh()  { return _mesh; }

  // ── Geometry writeback — push meshData back into BufferGeometry ──
  // mode 'verts'    : fast path — only vert positions changed, topology intact
  // mode 'topology' : full rebuild — used after extrude/topology ops
  // ── Box-projection UV generation ──────────────────────
  // Generates UVs for all triangles using triplanar (box) projection.
  // Each triangle is projected onto the plane most aligned with its face normal.
  // Scale is normalised to the mesh bounding box so textures tile consistently.
  // Also copies UVs to uv2 so aoMap works correctly (Three.js r128 requirement).
  function _generateBoxUVs(geo) {
    geo.computeBoundingBox();
    const bb  = geo.boundingBox;
    const sX  = (bb.max.x - bb.min.x) || 1;
    const sY  = (bb.max.y - bb.min.y) || 1;
    const sZ  = (bb.max.z - bb.min.z) || 1;

    const posAttr = geo.attributes.position;
    const normAttr = geo.attributes.normal;
    const count   = posAttr.count;
    const uvArr   = new Float32Array(count * 2);

    for (let i = 0; i < count; i++) {
      const x = posAttr.getX(i);
      const y = posAttr.getY(i);
      const z = posAttr.getZ(i);

      let nx = 0, ny = 0, nz = 0;
      if (normAttr) {
        nx = Math.abs(normAttr.getX(i));
        ny = Math.abs(normAttr.getY(i));
        nz = Math.abs(normAttr.getZ(i));
      }

      let u, v;
      if (nx >= ny && nx >= nz) {
        u = (z - bb.min.z) / sZ;
        v = (y - bb.min.y) / sY;
      } else if (ny >= nx && ny >= nz) {
        u = (x - bb.min.x) / sX;
        v = (z - bb.min.z) / sZ;
      } else {
        u = (x - bb.min.x) / sX;
        v = (y - bb.min.y) / sY;
      }

      uvArr[i * 2]     = u;
      uvArr[i * 2 + 1] = v;
    }

    const uvAttr = new THREE.BufferAttribute(uvArr, 2);
    geo.setAttribute('uv', uvAttr);
    // uv2 is a copy of uv so aoMap works in Three.js r128
    geo.setAttribute('uv2', new THREE.BufferAttribute(uvArr.slice(), 2));
    if (geo.attributes.uv) geo.attributes.uv.needsUpdate = true;
  }

  function _writebackGeometry(mode) {
    if(!_mesh || !_meshData) return;
    const geo = _mesh.geometry;

    if(mode === 'topology') {
      // Full rebuild from meshData
      const verts = _meshData.verts;
      const faces = _meshData.faces;
      const positions = new Float32Array(verts.length * 3);
      for(let i=0;i<verts.length;i++){
        positions[i*3]=verts[i].x; positions[i*3+1]=verts[i].y; positions[i*3+2]=verts[i].z;
      }
      const indices = new Uint32Array(faces.length * 3);
      for(let i=0;i<faces.length;i++){
        indices[i*3]=faces[i].verts[0]; indices[i*3+1]=faces[i].verts[1]; indices[i*3+2]=faces[i].verts[2];
      }
      geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      geo.setIndex(new THREE.BufferAttribute(indices, 1));
      geo.computeVertexNormals();
      geo.computeBoundingBox();
      geo.computeBoundingSphere();
      // Generate UVs after normals are computed (box projection uses normals)
      _generateBoxUVs(geo);
      geo.attributes.position.needsUpdate = true;
      // Rebuild buf->uniq map so subsequent vert-only drags stay correct
      _buildBufToUniqMap();
      // Ensure material reflects UV availability and re-apply UV transforms
      if (_mesh.material) {
        _mesh.material.needsUpdate = true;
        if (typeof MaterialSystem !== 'undefined') {
          const uvData = MaterialSystem.getMatData(_mesh);
          if (uvData) MaterialSystem._applyUVTransformsToMaterial(_mesh.material, uvData);
        }
      }
    } else {
      // Fast path: vert positions only
      if(!_bufToUniqVert){ _writebackGeometry('topology'); return; }
      const posAttr = geo.attributes.position;
      const posCount = posAttr.count;
      for(let i=0;i<posCount;i++){
        const vi=_bufToUniqVert[i];
        if(vi<0||vi>=_meshData.verts.length) continue;
        const v=_meshData.verts[vi];
        posAttr.setXYZ(i,v.x,v.y,v.z);
      }
      posAttr.needsUpdate=true;
      geo.computeVertexNormals();
      geo.computeBoundingBox();
      geo.computeBoundingSphere();
      // Regenerate UVs to match updated positions
      _generateBoxUVs(geo);
      if (_mesh.material) {
        _mesh.material.needsUpdate = true;
        if (typeof MaterialSystem !== 'undefined') {
          const uvData = MaterialSystem.getMatData(_mesh);
          if (uvData) MaterialSystem._applyUVTransformsToMaterial(_mesh.material, uvData);
        }
      }
    }

    _syncOverlayTransform();
  }

  // ── Rebuild overlay positions to match meshData (vert-only changes) ──
  function _rebuildOverlayPositions() {
    if(!_overlayGroup || !_meshData) return;
    // Safety: if face count changed (e.g. after extrude), do a full rebuild
    if(_faceMeshes.length !== _meshData.faces.length) { _rebuildOverlaysFull(); return; }

    // Update vertex point positions
    if(_vertPoints){
      const posArr = [];
      _meshData.verts.forEach(v => posArr.push(v.x, v.y, v.z));
      _vertPoints.geometry.setAttribute('position', new THREE.Float32BufferAttribute(posArr, 3));
      _vertPoints.geometry.attributes.position.needsUpdate = true;
    }

    // Update edge line positions
    if(_edgeLines){
      const edgePosArr = [];
      _meshData.edges.forEach(e => {
        const va=_meshData.verts[e.a], vb=_meshData.verts[e.b];
        edgePosArr.push(va.x,va.y,va.z, vb.x,vb.y,vb.z);
      });
      _edgeLines.geometry.setAttribute('position', new THREE.Float32BufferAttribute(edgePosArr, 3));
      _edgeLines.geometry.attributes.position.needsUpdate = true;
    }

    // Update face mesh positions
    _faceMeshes.forEach((fm, fi) => {
      const f = _meshData.faces[fi];
      const va=_meshData.verts[f.verts[0]], vb=_meshData.verts[f.verts[1]], vc=_meshData.verts[f.verts[2]];
      fm.geometry.setAttribute('position', new THREE.Float32BufferAttribute([va.x,va.y,va.z,vb.x,vb.y,vb.z,vc.x,vc.y,vc.z], 3));
      fm.geometry.attributes.position.needsUpdate = true;
      // Update face center
      f.center = {x:(va.x+vb.x+vc.x)/3, y:(va.y+vb.y+vc.y)/3, z:(va.z+vb.z+vc.z)/3};
    });
  }

  // ── Compute pivot (world-space center of selected elements) ──
  function _computePivot() {
    if(!_meshData || _selected.size === 0) return new THREE.Vector3();
    const worldMat = _mesh.matrixWorld;
    let cx=0,cy=0,cz=0,count=0;
    const vertIndices = new Set();

    if(_elemType === 'vert') {
      _selected.forEach(i => vertIndices.add(i));
    } else if(_elemType === 'edge') {
      _selected.forEach(ei => { const e=_meshData.edges[ei]; if(e){vertIndices.add(e.a);vertIndices.add(e.b);} });
    } else {
      _selected.forEach(fi => { const f=_meshData.faces[fi]; if(f) f.verts.forEach(v=>vertIndices.add(v)); });
    }

    vertIndices.forEach(vi => {
      const v = _meshData.verts[vi];
      const wp = new THREE.Vector3(v.x,v.y,v.z).applyMatrix4(worldMat);
      cx+=wp.x; cy+=wp.y; cz+=wp.z; count++;
    });
    if(count===0) return new THREE.Vector3();
    return new THREE.Vector3(cx/count, cy/count, cz/count);
  }

  // Get the unique vertex indices affected by current selection
  function _getAffectedVertIndices() {
    const verts = new Set();
    if(_elemType === 'vert') {
      _selected.forEach(i => verts.add(i));
    } else if(_elemType === 'edge') {
      _selected.forEach(ei => { const e=_meshData.edges[ei]; if(e){verts.add(e.a);verts.add(e.b);} });
    } else {
      _selected.forEach(fi => { const f=_meshData.faces[fi]; if(f) f.verts.forEach(v=>verts.add(v)); });
    }
    return verts;
  }

  // ── Edit Gizmo Build ──
  function _egMakeMat(color){ return new THREE.MeshBasicMaterial({color,depthTest:false,depthWrite:false}); }
  function _egMakeLineMat(color){ return new THREE.LineBasicMaterial({color,depthTest:false,depthWrite:false,linewidth:3}); }
  function _egMakeHitMat(){ return new THREE.MeshBasicMaterial({transparent:true,opacity:0.001,depthTest:true,depthWrite:false,side:THREE.DoubleSide}); }

  function _buildEGTranslate() {
    const g=new THREE.Group(); g.name='eg-translate';
    const L=1.2,cH=0.28,cR=0.09,hitR=0.18;
    const ROT={x:{z:-Math.PI/2},y:{},z:{x:Math.PI/2}};
    _egAxisMaterials.translate = {};
    ['x','y','z'].forEach(axis => {
      const axVec=new THREE.Vector3(axis==='x'?1:0,axis==='y'?1:0,axis==='z'?1:0);
      const color=_EG_COLORS[axis];
      const lineMat=_egMakeLineMat(color);
      const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),axVec.clone().multiplyScalar(L)]),lineMat);
      line.renderOrder=999; line.userData={axis,egizmo:true};
      const coneMat=_egMakeMat(color);
      const cone=new THREE.Mesh(new THREE.ConeGeometry(cR,cH,10),coneMat);
      cone.renderOrder=999; cone.userData={axis,egizmo:true};
      cone.position.copy(axVec.clone().multiplyScalar(L+cH*0.5));
      if(ROT[axis].z!==undefined) cone.rotation.z=ROT[axis].z;
      if(ROT[axis].x!==undefined) cone.rotation.x=ROT[axis].x;
      const hit=new THREE.Mesh(new THREE.CylinderGeometry(hitR,hitR,L+cH,8),_egMakeHitMat());
      hit.renderOrder=999; hit.userData={axis,egizmoHit:true,mode:'translate'};
      hit.position.copy(axVec.clone().multiplyScalar((L+cH)*0.5));
      if(ROT[axis].z!==undefined) hit.rotation.z=ROT[axis].z;
      if(ROT[axis].x!==undefined) hit.rotation.x=ROT[axis].x;
      _egAxisMaterials.translate[axis]=[lineMat,coneMat];
      g.add(line,cone,hit);
    });
    return g;
  }

  function _buildEGRotate() {
    const g=new THREE.Group(); g.name='eg-rotate';
    const r=1.2,segs=64,hitTR=0.13;
    _egAxisMaterials.rotate = {};
    ['x','y','z'].forEach(axis => {
      const color=_EG_COLORS[axis]; const pts=[];
      for(let i=0;i<=segs;i++){ const a=(i/segs)*Math.PI*2; if(axis==='x')pts.push(new THREE.Vector3(0,Math.cos(a)*r,Math.sin(a)*r)); else if(axis==='y')pts.push(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r)); else pts.push(new THREE.Vector3(Math.cos(a)*r,Math.sin(a)*r,0)); }
      const ringMat=_egMakeLineMat(color);
      const ring=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),ringMat);
      ring.renderOrder=999; ring.userData={axis,egizmo:true};
      const hit=new THREE.Mesh(new THREE.TorusGeometry(r,hitTR,8,48),_egMakeHitMat());
      hit.renderOrder=999; hit.userData={axis,egizmoHit:true,mode:'rotate'};
      const TORUS_ROT={x:{axis:'y',angle:Math.PI/2},y:{axis:'x',angle:Math.PI/2},z:null};
      const tr=TORUS_ROT[axis]; if(tr){if(tr.axis==='y')hit.rotation.y=tr.angle;else hit.rotation.x=tr.angle;}
      _egAxisMaterials.rotate[axis]=[ringMat];
      g.add(ring,hit);
    });
    return g;
  }

  function _buildEGScale() {
    const g=new THREE.Group(); g.name='eg-scale';
    const L=1.2,boxS=0.18,hitR=0.18;
    const ROT={x:{z:-Math.PI/2},y:{},z:{x:Math.PI/2}};
    _egAxisMaterials.scale = {};
    ['x','y','z'].forEach(axis => {
      const axVec=new THREE.Vector3(axis==='x'?1:0,axis==='y'?1:0,axis==='z'?1:0);
      const color=_EG_COLORS[axis];
      const lineMat=_egMakeLineMat(color);
      const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),axVec.clone().multiplyScalar(L)]),lineMat);
      line.renderOrder=999; line.userData={axis,egizmo:true};
      const boxMat=_egMakeMat(color);
      const box=new THREE.Mesh(new THREE.BoxGeometry(boxS,boxS,boxS),boxMat);
      box.renderOrder=999; box.position.copy(axVec.clone().multiplyScalar(L+boxS*0.5)); box.userData={axis,egizmo:true};
      const hit=new THREE.Mesh(new THREE.CylinderGeometry(hitR,hitR,L+boxS,8),_egMakeHitMat());
      hit.renderOrder=999; hit.userData={axis,egizmoHit:true,mode:'scale'};
      hit.position.copy(axVec.clone().multiplyScalar((L+boxS)*0.5));
      if(ROT[axis].z!==undefined) hit.rotation.z=ROT[axis].z;
      if(ROT[axis].x!==undefined) hit.rotation.x=ROT[axis].x;
      _egAxisMaterials.scale[axis]=[lineMat,boxMat];
      g.add(line,box,hit);
    });
    return g;
  }

  function _buildEditGizmo() {
    _gizmoGroup = new THREE.Group();
    _gizmoGroup.name = '__editgizmo__';
    _gizmoGroup.userData.nonSelectable = true;
    _gizmoGroup.renderOrder = 999;

    _egTranslateG = _buildEGTranslate();
    _egRotateG    = _buildEGRotate();
    _egScaleG     = _buildEGScale();
    [_egTranslateG,_egRotateG,_egScaleG].forEach(g=>{g.visible=false;_gizmoGroup.add(g);});
    _scene.add(_gizmoGroup);
  }

  function _destroyEditGizmo() {
    if(_gizmoGroup){ _scene.remove(_gizmoGroup); _gizmoGroup=null; }
    _egTranslateG=null; _egRotateG=null; _egScaleG=null;
    _egAxisMaterials={};
  }

  function _updateGizmoVisibility() {
    if(!_gizmoGroup) return;
    const show = _active && _selected.size > 0;
    _gizmoGroup.visible = show;
    if(!show) return;
    // Position at pivot
    const piv = _computePivot();
    _gizmoGroup.position.copy(piv);
    _editGizmoPivot.copy(piv);
    // Scale with distance
    const dist = _camera.position.distanceTo(piv);
    const tanH = Math.tan(_camera.fov*(Math.PI/180)/2);
    const ws = dist*tanH*0.22;
    _gizmoGroup.scale.setScalar(Math.min(2.5,Math.max(0.3,ws)));
    // Show correct gizmo
    if(_egTranslateG) _egTranslateG.visible = _egCurrentMode==='translate';
    if(_egRotateG)    _egRotateG.visible    = _egCurrentMode==='rotate';
    if(_egScaleG)     _egScaleG.visible     = _egCurrentMode==='scale';
  }

  function setEditTransformMode(mode) {
    _egCurrentMode = mode;
    _updateGizmoVisibility();
    // Sync main toolbar buttons
    ['translate','rotate','scale'].forEach(m=>{
      const ids={translate:'btn-move',rotate:'btn-rotate',scale:'btn-scale'};
      const el=document.getElementById(ids[m]); if(el) el.classList.toggle('active',m===mode);
    });
    const hint = document.getElementById('edit-transform-hint');
    if(hint){
      const labels={translate:'Move (G) — drag gizmo axis', rotate:'Rotate (R) — drag gizmo ring', scale:'Scale (S) — drag gizmo cube'};
      hint.textContent = labels[mode]||mode;
      hint.classList.add('visible');
      clearTimeout(setEditTransformMode._timer);
      setEditTransformMode._timer = setTimeout(()=>hint.classList.remove('visible'),1800);
    }
  }

  // ── Gizmo hit detection ──
  function _getEditGizmoHits(clientX, clientY, isTouch=false) {
    if(!_gizmoGroup || !_gizmoGroup.visible) return [];
    _gizmoGroup.updateMatrixWorld(true);
    const r = _canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(((clientX-r.left)/r.width)*2-1,-((clientY-r.top)/r.height)*2+1);
    _editGizmoRay.setFromCamera(ndc, _camera);
    _editGizmoRay.params.Line = {threshold: isTouch?0.08:0.04};
    const hitProxies = [];
    // Only collect hit proxies that belong to the currently active mode
    _gizmoGroup.traverse(c=>{ if(c.isMesh&&c.userData.egizmoHit===true&&c.userData.mode===_egCurrentMode) hitProxies.push(c); });
    if(hitProxies.length===0) return [];
    return _editGizmoRay.intersectObjects(hitProxies, false);
  }

  function _egSetAxisColor(axis, color) {
    const mats = _egAxisMaterials[_egCurrentMode] && _egAxisMaterials[_egCurrentMode][axis];
    if(!mats) return; mats.forEach(m=>m.color.setHex(color));
  }

  function _egSetHover(axis) {
    if(_egHovered === axis) return;
    if(_egHovered) _egSetAxisColor(_egHovered, _EG_COLORS[_egHovered]);
    _egHovered = axis;
    if(axis) _egSetAxisColor(axis, _EG_COLORS_H[axis]);
  }

  // ── Gizmo drag plane ──
  function _buildEGDragPlane(axisKey) {
    const AXIS_VEC = {x:new THREE.Vector3(1,0,0),y:new THREE.Vector3(0,1,0),z:new THREE.Vector3(0,0,1)};
    const axVec = AXIS_VEC[axisKey];
    const toCamera = _camera.position.clone().sub(_editGizmoPivot).normalize();
    let normal = toCamera.clone().addScaledVector(axVec, -toCamera.dot(axVec));
    if(normal.lengthSq()<1e-6){ normal = Math.abs(axVec.x)<0.9?new THREE.Vector3().crossVectors(axVec,new THREE.Vector3(1,0,0)):new THREE.Vector3().crossVectors(axVec,new THREE.Vector3(0,1,0)); }
    _editGizmoHitPlane.setFromNormalAndCoplanarPoint(normal.normalize(), _editGizmoPivot);
  }

  function _egScreenToWorld(clientX, clientY) {
    const r = _canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(((clientX-r.left)/r.width)*2-1,-((clientY-r.top)/r.height)*2+1);
    _editGizmoRay.setFromCamera(ndc, _camera);
    const out = new THREE.Vector3();
    return _editGizmoRay.ray.intersectPlane(_editGizmoHitPlane, out) ? out : null;
  }

  // ── Start drag: snapshot original vert positions, compute pivot ──
  function _egStartDrag(clientX, clientY, isTouch=false) {
    if(_selected.size===0) return false;
    if(!_gizmoGroup || !_gizmoGroup.visible) return false;
    const hits = _getEditGizmoHits(clientX, clientY, isTouch);
    if(!hits.length) return false;
    const axis = hits[0].object.userData.axis;
    _editGizmoDragAxis = axis;
    _editGizmoDragMode = _egCurrentMode;
    _editGizmoMouseStart = {x:clientX, y:clientY};
    _editGizmoPivot.copy(_computePivot());
    _buildEGDragPlane(axis);
    const startPt = _egScreenToWorld(clientX, clientY);
    _editGizmoDragStartWorld.copy(startPt || _editGizmoPivot);
    // Save vert positions (in local mesh space)
    const affectedVerts = _getAffectedVertIndices();
    _editGizmoDragStartVerts = [];
    affectedVerts.forEach(vi => {
      _editGizmoDragStartVerts.push({vi, x:_meshData.verts[vi].x, y:_meshData.verts[vi].y, z:_meshData.verts[vi].z});
    });
    _editGizmoDragging = true;
    _egSetAxisColor(axis, _EG_COLOR_ACT);
    CameraManager.setGizmoCaptured(true);
    SnapSystem.hidePreview();
    // Push undo BEFORE any vertex mutation happens
    pushUndo();
    // Update drag status
    const statusEl=document.getElementById('drag-status');
    if(statusEl){ statusEl.textContent=`EDIT ${_editGizmoDragMode.toUpperCase()} · ${axis.toUpperCase()}`; statusEl.classList.add('visible'); }
    return true;
  }

  // ── Apply drag transform to affected verts ──
  function _egMoveDrag(clientX, clientY) {
    if(!_editGizmoDragging) return;
    const AXIS_VEC = {x:new THREE.Vector3(1,0,0),y:new THREE.Vector3(0,1,0),z:new THREE.Vector3(0,0,1)};
    const axVec = AXIS_VEC[_editGizmoDragAxis];
    const invWorldMat = new THREE.Matrix4().copy(_mesh.matrixWorld).invert();
    const normWorldMat = new THREE.Matrix3().getNormalMatrix(_mesh.matrixWorld);

    if(_editGizmoDragMode === 'translate') {
      const pt = _egScreenToWorld(clientX, clientY); if(!pt) return;
      let rawDelta = pt.clone().sub(_editGizmoDragStartWorld).dot(axVec);
      // Project axVec to local space for per-vert displacement
      // We apply delta in world space, then convert back to local
      const worldDelta = axVec.clone().multiplyScalar(rawDelta);

      // Snap the world pivot destination
      if(SnapSystem.isEnabled()) {
        const tentativePivot = _editGizmoPivot.clone().add(worldDelta);
        const excludeSet = new Set(_editGizmoDragStartVerts.map(s=>s.vi));
        const snapped = SnapSystem.snapPoint(tentativePivot, _meshData, _mesh, _camera, _canvas, excludeSet);
        const snappedDelta = snapped.clone().sub(_editGizmoPivot);
        // Keep only along axis
        const snappedProj = snappedDelta.dot(axVec);
        worldDelta.copy(axVec.clone().multiplyScalar(snappedProj));
        // Show preview
        const ndc = snapped.clone().project(_camera);
        const rect = _canvas.getBoundingClientRect();
        SnapSystem.showPreview((ndc.x+1)*0.5*rect.width, (-ndc.y+1)*0.5*rect.height);
      }

      // Apply delta to each affected vert (local space)
      _editGizmoDragStartVerts.forEach(({vi,x,y,z}) => {
        const localOrig = new THREE.Vector3(x,y,z);
        const worldOrig = localOrig.clone().applyMatrix4(_mesh.matrixWorld);
        const worldNew  = worldOrig.clone().add(worldDelta);
        const localNew  = worldNew.clone().applyMatrix4(invWorldMat);
        _meshData.verts[vi].x = localNew.x;
        _meshData.verts[vi].y = localNew.y;
        _meshData.verts[vi].z = localNew.z;
      });

    } else if(_editGizmoDragMode === 'rotate') {
      const dx=clientX-_editGizmoMouseStart.x, dy=clientY-_editGizmoMouseStart.y;
      const pA=_editGizmoPivot.clone().project(_camera), pB=_editGizmoPivot.clone().add(axVec).project(_camera);
      const rect=_canvas.getBoundingClientRect();
      const sx=(pB.x-pA.x)*(rect.width*0.5), sy=(pA.y-pB.y)*(rect.height*0.5);
      const sLen=Math.sqrt(sx*sx+sy*sy);
      let angle;
      if(sLen<1.0){ angle=(dx-dy)*0.012; } else { const nx=sy/sLen,ny=-sx/sLen; angle=(dx*nx+dy*ny)*0.012; }
      const q = new THREE.Quaternion().setFromAxisAngle(axVec, angle);
      // Rotate each vert around world pivot
      _editGizmoDragStartVerts.forEach(({vi,x,y,z}) => {
        const localOrig = new THREE.Vector3(x,y,z);
        const worldOrig = localOrig.clone().applyMatrix4(_mesh.matrixWorld);
        const relWorld  = worldOrig.clone().sub(_editGizmoPivot);
        const rotated   = relWorld.clone().applyQuaternion(q);
        const worldNew  = rotated.add(_editGizmoPivot);
        const localNew  = worldNew.applyMatrix4(invWorldMat);
        _meshData.verts[vi].x = localNew.x;
        _meshData.verts[vi].y = localNew.y;
        _meshData.verts[vi].z = localNew.z;
      });

    } else if(_editGizmoDragMode === 'scale') {
      const dx=clientX-_editGizmoMouseStart.x, dy=clientY-_editGizmoMouseStart.y;
      const pA=_editGizmoPivot.clone().project(_camera), pB=_editGizmoPivot.clone().add(axVec).project(_camera);
      const rect=_canvas.getBoundingClientRect();
      const sx=(pB.x-pA.x)*(rect.width*0.5), sy=(pA.y-pB.y)*(rect.height*0.5);
      const sLen=Math.sqrt(sx*sx+sy*sy);
      let proj;
      if(sLen<1.0) proj=(Math.abs(dx)>Math.abs(dy)?dx:-dy); else proj=(dx*sx+dy*sy)/sLen;
      const sf = Math.max(0.01, 1.0+proj/120);
      // Scale each vert around pivot along axis
      _editGizmoDragStartVerts.forEach(({vi,x,y,z}) => {
        const localOrig = new THREE.Vector3(x,y,z);
        const worldOrig = localOrig.clone().applyMatrix4(_mesh.matrixWorld);
        const relWorld  = worldOrig.clone().sub(_editGizmoPivot);
        // Scale component along axis
        const axComp = relWorld.dot(axVec);
        const scaled  = relWorld.clone().addScaledVector(axVec, axComp*(sf-1));
        const worldNew = scaled.add(_editGizmoPivot);
        const localNew = worldNew.applyMatrix4(invWorldMat);
        _meshData.verts[vi].x = localNew.x;
        _meshData.verts[vi].y = localNew.y;
        _meshData.verts[vi].z = localNew.z;
      });
    }

    // Writeback and refresh
    _writebackGeometry('verts');
    _rebuildOverlayPositions();
    _refreshOverlay();
    _updateGizmoVisibility();
    _refreshUI();
  }

  function _egEndDrag() {
    if(!_editGizmoDragging) return;
    if(_editGizmoDragAxis) _egSetAxisColor(_editGizmoDragAxis, _EG_COLORS[_editGizmoDragAxis]);
    _editGizmoDragging = false;
    _editGizmoDragAxis = null;
    _editGizmoDragStartVerts = [];
    CameraManager.setGizmoCaptured(false);
    SnapSystem.hidePreview();
    const statusEl=document.getElementById('drag-status');
    if(statusEl) statusEl.classList.remove('visible');
  }

  // ── Gizmo input binding ──
  let _gizmoHandlers = {};
  function _bindGizmoInput() {
    const onMouseDown = e => {
      if(e.button!==0) return;
      if(_egStartDrag(e.clientX,e.clientY)){ e._egizmoConsumed=true; e.stopPropagation(); }
    };
    const onMouseMove = e => {
      if(_editGizmoDragging){ _egMoveDrag(e.clientX,e.clientY); }
      else if(_gizmoGroup&&_gizmoGroup.visible){ const h=_getEditGizmoHits(e.clientX,e.clientY); _egSetHover(h.length>0?h[0].object.userData.axis:null); }
    };
    const onMouseUp = () => { if(_editGizmoDragging) _egEndDrag(); };

    const onTouchStart = e => {
      if(e.touches.length!==1) return;
      const t=e.touches[0];
      if(_egStartDrag(t.clientX,t.clientY,true)){ _editGizmoActiveTouchId=t.identifier; e.stopPropagation(); e.preventDefault(); }
    };
    const onTouchMove = e => {
      if(!_editGizmoDragging) return;
      for(let i=0;i<e.changedTouches.length;i++){ const t=e.changedTouches[i]; if(t.identifier===_editGizmoActiveTouchId){ _egMoveDrag(t.clientX,t.clientY); e.stopPropagation(); e.preventDefault(); break; } }
    };
    const onTouchEnd = e => {
      if(!_editGizmoDragging) return;
      for(let i=0;i<e.changedTouches.length;i++){ if(e.changedTouches[i].identifier===_editGizmoActiveTouchId){ _egEndDrag(); _editGizmoActiveTouchId=null; e.stopPropagation(); break; } }
    };
    const onTouchCancel = () => { if(_editGizmoDragging){ _egEndDrag(); } _editGizmoActiveTouchId=null; };

    _gizmoHandlers = { onMouseDown, onMouseMove, onMouseUp, onTouchStart, onTouchMove, onTouchEnd, onTouchCancel };
    _canvas.addEventListener('mousedown', onMouseDown, {capture:true});
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    _canvas.addEventListener('touchstart', onTouchStart, {capture:true,passive:false});
    _canvas.addEventListener('touchmove', onTouchMove, {capture:true,passive:false});
    _canvas.addEventListener('touchend', onTouchEnd, {capture:true,passive:false});
    _canvas.addEventListener('touchcancel', onTouchCancel, {capture:true,passive:false});
  }

  function _unbindGizmoInput() {
    const h=_gizmoHandlers;
    if(h.onMouseDown) _canvas.removeEventListener('mousedown', h.onMouseDown, {capture:true});
    if(h.onMouseMove) window.removeEventListener('mousemove', h.onMouseMove);
    if(h.onMouseUp)   window.removeEventListener('mouseup', h.onMouseUp);
    if(h.onTouchStart)  _canvas.removeEventListener('touchstart', h.onTouchStart, {capture:true});
    if(h.onTouchMove)   _canvas.removeEventListener('touchmove', h.onTouchMove, {capture:true});
    if(h.onTouchEnd)    _canvas.removeEventListener('touchend', h.onTouchEnd, {capture:true});
    if(h.onTouchCancel) _canvas.removeEventListener('touchcancel', h.onTouchCancel, {capture:true});
    _gizmoHandlers = {};
  }

  // ── Overlay construction ──
  function _buildOverlays() {
    _overlayGroup = new THREE.Group();
    _overlayGroup.userData.editOverlay = true;
    _overlayGroup.userData.nonSelectable = true;

    // Vertex points
    const posArr = [];
    _meshData.verts.forEach(v => posArr.push(v.x,v.y,v.z));
    const vertGeo = new THREE.BufferGeometry();
    vertGeo.setAttribute('position', new THREE.Float32BufferAttribute(posArr, 3));

    // Per-vertex color array
    const colArr = new Float32Array(_meshData.verts.length*3);
    for(let i=0;i<_meshData.verts.length;i++){ colArr[i*3]=1;colArr[i*3+1]=1;colArr[i*3+2]=1; }
    vertGeo.setAttribute('color', new THREE.BufferAttribute(colArr, 3));

    const vertMat = new THREE.PointsMaterial({
      size: window.devicePixelRatio > 1.5 ? 7 : 6,
      sizeAttenuation: false,
      vertexColors: true,
      depthTest: !_xray,
      depthWrite: false,
      transparent: true, opacity: 1.0
    });
    _vertPoints = new THREE.Points(vertGeo, vertMat);
    _vertPoints.renderOrder = 10;
    _vertPoints.userData.editOverlay = true;

    // Edge lines
    const edgePosArr = [];
    const edgeColArr = [];
    _meshData.edges.forEach(e => {
      const va=_meshData.verts[e.a], vb=_meshData.verts[e.b];
      edgePosArr.push(va.x,va.y,va.z, vb.x,vb.y,vb.z);
      edgeColArr.push(0.27,0.53,1, 0.27,0.53,1);
    });
    const edgeGeo = new THREE.BufferGeometry();
    edgeGeo.setAttribute('position', new THREE.Float32BufferAttribute(edgePosArr, 3));
    edgeGeo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(edgeColArr), 3));
    const edgeMat = new THREE.LineBasicMaterial({
      vertexColors: true, depthTest: !_xray, depthWrite: false,
      transparent: true, opacity: 0.85
    });
    _edgeLines = new THREE.LineSegments(edgeGeo, edgeMat);
    _edgeLines.renderOrder = 9;
    _edgeLines.userData.editOverlay = true;

    // Face highlight meshes (thin transparent quads per face)
    _faceMeshes = [];
    _meshData.faces.forEach((f,fi) => {
      const va=_meshData.verts[f.verts[0]], vb=_meshData.verts[f.verts[1]], vc=_meshData.verts[f.verts[2]];
      const fg = new THREE.BufferGeometry();
      fg.setAttribute('position', new THREE.Float32BufferAttribute([va.x,va.y,va.z, vb.x,vb.y,vb.z, vc.x,vc.y,vc.z], 3));
      const fm = new THREE.Mesh(fg, new THREE.MeshBasicMaterial({
        color:0xff4444, transparent:true, opacity:0.0,
        side:THREE.DoubleSide, depthTest:!_xray, depthWrite:false
      }));
      fm.renderOrder = 8;
      fm.userData.editOverlay = true;
      fm.userData.faceIndex = fi;
      _faceMeshes.push(fm);
      _overlayGroup.add(fm);
    });

    _overlayGroup.add(_edgeLines, _vertPoints);

    // Apply mesh's world transform to overlay group
    _mesh.updateMatrixWorld(true);
    _overlayGroup.matrixAutoUpdate = false;
    _overlayGroup.matrix.copy(_mesh.matrixWorld);

    _scene.add(_overlayGroup);
  }

  function _destroyOverlays() {
    if(_overlayGroup){ _scene.remove(_overlayGroup); _overlayGroup=null; }
    _vertPoints=null; _edgeLines=null; _faceMeshes=[];
  }

  function _syncOverlayTransform() {
    if(!_overlayGroup||!_mesh) return;
    _mesh.updateMatrixWorld(true);
    _overlayGroup.matrix.copy(_mesh.matrixWorld);
    _overlayGroup.matrixWorldNeedsUpdate = true;
  }

  // ── Full overlay rebuild (needed after topology changes like extrude) ──
  function _rebuildOverlaysFull() {
    _destroyOverlays();
    _buildOverlays();
    _refreshOverlay();
  }

  // ── Extrude selected faces ──
  // Creates geometry at distance=0 (in-place). User drags gizmo to offset.
  function extrudeFaces() {
    if(!_active || !_meshData || _elemType !== 'face' || _selected.size === 0) return false;

    // Snapshot BEFORE any mutation
    pushUndo();

    const verts  = _meshData.verts;
    const faces  = _meshData.faces;
    const edges  = _meshData.edges;

    // --- 1. Collect selected face indices ---
    const selFaceIndices = [..._selected];
    const faceSet = new Set(selFaceIndices);

    // --- 2. Compute mean face normal (used for winding check) ---
    let nx=0, ny=0, nz=0;
    selFaceIndices.forEach(fi => {
      nx += faces[fi].normal.x; ny += faces[fi].normal.y; nz += faces[fi].normal.z;
    });
    const nLen = Math.sqrt(nx*nx+ny*ny+nz*nz) || 1;
    nx/=nLen; ny/=nLen; nz/=nLen;

    // --- 3. Compute centroid of selected region (for outward direction checks) ---
    let cx=0,cy=0,cz=0,cCount=0;
    selFaceIndices.forEach(fi => {
      faces[fi].verts.forEach(vi => {
        cx+=verts[vi].x; cy+=verts[vi].y; cz+=verts[vi].z; cCount++;
      });
    });
    if(cCount>0){ cx/=cCount; cy/=cCount; cz/=cCount; }
    const centroid = {x:cx, y:cy, z:cz};

    // --- 4. Find boundary edges: edges shared with exactly 1 selected face ---
    const edgeFaceSelCount = new Map();
    edges.forEach((e, ei) => {
      let s=0; e.faces.forEach(fi=>{ if(faceSet.has(fi)) s++; });
      edgeFaceSelCount.set(ei, s);
    });

    const boundaryEdgeKeys = new Set();
    const boundaryEdges = [];
    selFaceIndices.forEach(fi => {
      faces[fi].edges.forEach(ei => {
        if((edgeFaceSelCount.get(ei)||0) === 1) {
          const e = edges[ei];
          const key = e.a < e.b ? `${e.a}-${e.b}` : `${e.b}-${e.a}`;
          if(!boundaryEdgeKeys.has(key)) {
            boundaryEdgeKeys.add(key);
            boundaryEdges.push({ a: e.a, b: e.b });
          }
        }
      });
    });

    // --- 5. Duplicate verts at distance=0 (in-place — user moves with gizmo) ---
    const selVertSet = new Set();
    selFaceIndices.forEach(fi => faces[fi].verts.forEach(vi => selVertSet.add(vi)));

    const vertRemap = new Map();
    selVertSet.forEach(vi => {
      const v = verts[vi];
      vertRemap.set(vi, verts.length);
      // Place new vert at exact same position — user drags to offset
      verts.push({ x: v.x, y: v.y, z: v.z });
    });

    // --- 6. Remap selected faces to use new cap verts ---
    selFaceIndices.forEach(fi => {
      const f = faces[fi];
      f.verts = f.verts.map(vi => vertRemap.has(vi) ? vertRemap.get(vi) : vi);
      const va=verts[f.verts[0]], vb=verts[f.verts[1]], vc=verts[f.verts[2]];
      const ab={x:vb.x-va.x,y:vb.y-va.y,z:vb.z-va.z};
      const ac={x:vc.x-va.x,y:vc.y-va.y,z:vc.z-va.z};
      const cn={x:ab.y*ac.z-ab.z*ac.y,y:ab.z*ac.x-ab.x*ac.z,z:ab.x*ac.y-ab.y*ac.x};
      const cl=Math.sqrt(cn.x*cn.x+cn.y*cn.y+cn.z*cn.z)||1;
      f.normal={x:cn.x/cl,y:cn.y/cl,z:cn.z/cl};
      f.center={x:(va.x+vb.x+vc.x)/3,y:(va.y+vb.y+vc.y)/3,z:(va.z+vb.z+vc.z)/3};
    });

    // --- 7. Build side quads per boundary edge ---
    // Each boundary edge (a,b) connects original verts to new cap verts (aPrime,bPrime).
    // Winding: determine which tri order makes the normal point away from centroid.
    boundaryEdges.forEach(({ a, b }) => {
      const aPrime = vertRemap.get(a);
      const bPrime = vertRemap.get(b);
      if(aPrime === undefined || bPrime === undefined) return;

      // Edge midpoint → vector away from centroid = outward reference
      const midX=(verts[a].x+verts[b].x)/2, midY=(verts[a].y+verts[b].y)/2, midZ=(verts[a].z+verts[b].z)/2;
      const outX=midX-centroid.x, outY=midY-centroid.y, outZ=midZ-centroid.z;

      // Trial winding T1: [a, b, bPrime]
      const va=verts[a], vb=verts[b], vc=verts[bPrime];
      const abx=vb.x-va.x,aby=vb.y-va.y,abz=vb.z-va.z;
      const acx=vc.x-va.x,acy=vc.y-va.y,acz=vc.z-va.z;
      const tnx=aby*acz-abz*acy, tny=abz*acx-abx*acz, tnz=abx*acy-aby*acx;
      // If trial normal opposes outward direction, flip
      const flip = (tnx*outX + tny*outY + tnz*outZ) < 0;

      // Side triangle 1
      const t1 = flip ? [a, bPrime, b]     : [a, b, bPrime];
      // Side triangle 2
      const t2 = flip ? [a, aPrime, bPrime] : [a, bPrime, aPrime];

      [t1, t2].forEach(tv => {
        const va2=verts[tv[0]],vb2=verts[tv[1]],vc2=verts[tv[2]];
        const ab2x=vb2.x-va2.x,ab2y=vb2.y-va2.y,ab2z=vb2.z-va2.z;
        const ac2x=vc2.x-va2.x,ac2y=vc2.y-va2.y,ac2z=vc2.z-va2.z;
        const cn2x=ab2y*ac2z-ab2z*ac2y,cn2y=ab2z*ac2x-ab2x*ac2z,cn2z=ab2x*ac2y-ab2y*ac2x;
        const cl2=Math.sqrt(cn2x*cn2x+cn2y*cn2y+cn2z*cn2z)||1;
        faces.push({
          verts: tv, edges: [],
          normal: {x:cn2x/cl2, y:cn2y/cl2, z:cn2z/cl2},
          center: {x:(va2.x+vb2.x+vc2.x)/3, y:(va2.y+vb2.y+vc2.y)/3, z:(va2.z+vb2.z+vc2.z)/3}
        });
      });
    });

    // --- 8. Rebuild full edge topology ---
    const newEdgeMap = new Map();
    const newEdges   = [];
    function _getEK(a,b){ return a<b?`${a}-${b}`:`${b}-${a}`; }
    function _getOrAddE(a,b){
      const k=_getEK(a,b);
      if(!newEdgeMap.has(k)){ newEdgeMap.set(k,newEdges.length); newEdges.push({a,b,faces:[]}); }
      return newEdgeMap.get(k);
    }
    faces.forEach((f,fi)=>{
      if(f.verts.length<3) return;
      const eA=_getOrAddE(f.verts[0],f.verts[1]); newEdges[eA].faces.push(fi);
      const eB=_getOrAddE(f.verts[1],f.verts[2]); newEdges[eB].faces.push(fi);
      const eC=_getOrAddE(f.verts[2],f.verts[0]); newEdges[eC].faces.push(fi);
      f.edges=[eA,eB,eC];
    });
    _meshData.edges = newEdges;

    // --- 9. Force DoubleSide on the mesh material so side faces never go invisible ---
    if(_mesh && _mesh.material) {
      _mesh.material.side = THREE.DoubleSide;
      _mesh.material.needsUpdate = true;
    }

    // --- 10. Commit topology to BufferGeometry ---
    _writebackGeometry('topology');

    // --- 11. Rebuild overlays ---
    _rebuildOverlaysFull();

    // --- 12. Select the cap faces; stay in face mode so user can drag-extrude with gizmo ---
    _elemType = 'face';
    _selected.clear();
    selFaceIndices.forEach(fi => _selected.add(fi));
    document.getElementById('elem-vert').classList.remove('active');
    document.getElementById('elem-edge').classList.remove('active');
    document.getElementById('elem-face').classList.add('active');

    _refreshOverlay();
    _refreshUI();
    _updateGizmoVisibility();
    return true;
  }

  // ── X-Ray toggle ──
  function _setXray(on) {
    _xray = on;
    if(_vertPoints){ _vertPoints.material.depthTest=!on; }
    if(_edgeLines){ _edgeLines.material.depthTest=!on; }
    _faceMeshes.forEach(fm=>{ fm.material.depthTest=!on; });
    const btn=document.getElementById('btn-xray');
    if(btn) btn.classList.toggle('active',on);
    const ep=document.getElementById('ep-xray');
    if(ep) ep.textContent=on?'On':'Off';
  }

  function toggleXray() { _setXray(!_xray); }

  // ── Overlay color refresh ──
  function _refreshOverlay() {
    if(!_meshData||!_overlayGroup) return;
    // Safety: if overlay element counts don't match meshData, do full rebuild
    if(_vertPoints && _vertPoints.geometry.attributes.color &&
       _vertPoints.geometry.attributes.color.count !== _meshData.verts.length) {
      _rebuildOverlaysFull(); return;
    }
    if(_edgeLines && _edgeLines.geometry.attributes.color &&
       _edgeLines.geometry.attributes.color.count/2 !== _meshData.edges.length) {
      _rebuildOverlaysFull(); return;
    }
    if(_faceMeshes.length !== _meshData.faces.length) {
      _rebuildOverlaysFull(); return;
    }
    const mode = _elemType;

    // Update vertex colors
    if(_vertPoints){
      const col = _vertPoints.geometry.attributes.color;
      const arr = col.array;
      _meshData.verts.forEach((v,i)=>{
        let sel = false;
        if(mode==='vert') sel=_selected.has(i);
        else if(mode==='edge') sel=[..._selected].some(ei=>_meshData.edges[ei]&&(_meshData.edges[ei].a===i||_meshData.edges[ei].b===i));
        else if(mode==='face') sel=[..._selected].some(fi=>_meshData.faces[fi]&&_meshData.faces[fi].verts.includes(i));
        const c=sel?C_VERT_SEL:C_VERT_DEFAULT;
        arr[i*3]=c.r; arr[i*3+1]=c.g; arr[i*3+2]=c.b;
      });
      col.needsUpdate=true;
      // In edge/face mode hide vertex points (show them dimmed)
      _vertPoints.material.opacity=(mode==='vert')?1.0:0.4;
      _vertPoints.material.size=(mode==='vert')?(window.devicePixelRatio>1.5?7:6):4;
    }

    // Update edge colors
    if(_edgeLines){
      const col = _edgeLines.geometry.attributes.color;
      const arr = col.array;
      _meshData.edges.forEach((e,i)=>{
        let sel=false;
        if(mode==='edge') sel=_selected.has(i);
        else if(mode==='face') sel=[..._selected].some(fi=>_meshData.faces[fi]&&_meshData.faces[fi].edges.includes(i));
        const r=sel?1:0.27, g=sel?0.53:0.53, b=sel?0:1;
        arr[i*6]=r;arr[i*6+1]=g;arr[i*6+2]=b;
        arr[i*6+3]=r;arr[i*6+4]=g;arr[i*6+5]=b;
      });
      col.needsUpdate=true;
      _edgeLines.material.opacity=(mode==='edge')?0.9:0.45;
    }

    // Update face opacities
    _faceMeshes.forEach((fm,i)=>{
      const sel=mode==='face'&&_selected.has(i);
      fm.material.opacity=sel?C_FACE_SEL_ALPHA:C_FACE_DEFAULT_ALPHA;
    });
  }

  // ── Element type switch ──
  function setElemType(type) {
    _elemType = type;
    _selected.clear();
    ['elem-vert','elem-edge','elem-face'].forEach(id=>{
      const el=document.getElementById(id);
      if(el) el.classList.toggle('active',id.endsWith(type.slice(0,4)));
    });
    // Fix: proper IDs
    document.getElementById('elem-vert').classList.toggle('active',type==='vert');
    document.getElementById('elem-edge').classList.toggle('active',type==='edge');
    document.getElementById('elem-face').classList.toggle('active',type==='face');
    _refreshOverlay();
    _refreshUI();
    _updateGizmoVisibility();
  }

  // ── Selection helpers ──
  function selectAll() {
    const count = _elemType==='vert'?_meshData.verts.length:_elemType==='edge'?_meshData.edges.length:_meshData.faces.length;
    for(let i=0;i<count;i++) _selected.add(i);
    _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
  }

  function selectNone() {
    _selected.clear();
    _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
  }

  function selectInverse() {
    if(!_meshData) return;
    const count = _elemType==='vert'?_meshData.verts.length:_elemType==='edge'?_meshData.edges.length:_meshData.faces.length;
    const next = new Set();
    for(let i=0;i<count;i++) { if(!_selected.has(i)) next.add(i); }
    _selected.clear();
    next.forEach(i=>_selected.add(i));
    _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
  }

  // ── UI refresh ──
  function _refreshUI() {
    const total = _elemType==='vert'?_meshData.verts.length:_elemType==='edge'?_meshData.edges.length:_meshData.faces.length;
    const count = _selected.size;
    const el=document.getElementById('edit-sel-count');
    if(el) el.textContent=count;
    const ep=document.getElementById('ep-count');
    if(ep) ep.textContent=`${count} / ${total}`;
    const em=document.getElementById('ep-mode');
    if(em) em.textContent=_elemType==='vert'?'Vertex':_elemType==='edge'?'Edge':'Face';
    const everts=document.getElementById('ep-verts');
    if(everts) everts.textContent=_meshData.verts.length;
    const eedges=document.getElementById('ep-edges');
    if(eedges) eedges.textContent=_meshData.edges.length;
    const efaces=document.getElementById('ep-faces');
    if(efaces) efaces.textContent=_meshData.faces.length;

    // Show median position for selected verts
    const coordSec=document.getElementById('ep-coord-section');
    if(count>0&&_elemType==='vert'){
      coordSec.style.display='';
      const worldMat=_mesh.matrixWorld;
      let mx=0,my=0,mz=0;
      _selected.forEach(i=>{ const v=_meshData.verts[i]; const wp=new THREE.Vector3(v.x,v.y,v.z).applyMatrix4(worldMat); mx+=wp.x;my+=wp.y;mz+=wp.z; });
      mx/=count;my/=count;mz/=count;
      document.getElementById('ep-cx').textContent=mx.toFixed(3);
      document.getElementById('ep-cy').textContent=my.toFixed(3);
      document.getElementById('ep-cz').textContent=mz.toFixed(3);
    } else { coordSec.style.display='none'; }
  }

  // ── Raycasting for element picking ──
  function _getNDC(clientX,clientY) {
    const r=_canvas.getBoundingClientRect();
    return new THREE.Vector2(((clientX-r.left)/r.width)*2-1,-((clientY-r.top)/r.height)*2+1);
  }

  // Project world point to screen pixel
  function _worldToScreen(wx,wy,wz) {
    const v=new THREE.Vector4(wx,wy,wz,1).applyMatrix4(_mesh.matrixWorld);
    const vp=new THREE.Vector3(v.x/v.w,v.y/v.w,v.z/v.w).project(_camera);
    const r=_canvas.getBoundingClientRect();
    return {x:(vp.x+1)*0.5*r.width+r.left, y:(-vp.y+1)*0.5*r.height+r.top, vz:vp.z};
  }

  // Occlusion check: is a world-space point visible from camera?
  function _isVisible(wx,wy,wz) {
    if(_xray) return true;
    const worldPos=new THREE.Vector3(wx,wy,wz).applyMatrix4(_mesh.matrixWorld);
    const dir=worldPos.clone().sub(_camera.position).normalize();
    _ray.set(_camera.position, dir);
    _ray.params.Points={threshold:0.01};
    const dist=_camera.position.distanceTo(worldPos);
    const hits=_ray.intersectObject(_mesh, false);
    // If closest hit is ~same distance as point, it's visible; otherwise occluded
    if(hits.length===0) return true;
    const closest=hits[0].distance;
    return closest >= dist - 0.04; // small tolerance
  }

  // Pick nearest vertex within screen threshold
  function _pickVertex(clientX,clientY,additive,multiThresh) {
    const THRESH = multiThresh || (window.devicePixelRatio>1.5?24:18);
    let best=null, bestDist=THRESH;
    _meshData.verts.forEach((v,i)=>{
      const s=_worldToScreen(v.x,v.y,v.z);
      if(s.vz>1) return; // behind camera
      if(!_xray&&!_isVisible(v.x,v.y,v.z)) return;
      const d=Math.hypot(s.x-clientX,s.y-clientY);
      if(d<bestDist){ bestDist=d; best=i; }
    });
    if(best===null){ if(!additive) _selected.clear(); }
    else { if(additive){ if(_selected.has(best)) _selected.delete(best); else _selected.add(best); } else { _selected.clear(); _selected.add(best); } }
  }

  // Pick nearest edge within screen threshold
  function _pickEdge(clientX,clientY,additive) {
    const THRESH = window.devicePixelRatio>1.5?20:16;
    let best=null, bestDist=THRESH;
    _meshData.edges.forEach((e,i)=>{
      const va=_meshData.verts[e.a], vb=_meshData.verts[e.b];
      if(!_xray&&!_isVisible((va.x+vb.x)/2,(va.y+vb.y)/2,(va.z+vb.z)/2)) return;
      const sa=_worldToScreen(va.x,va.y,va.z), sb=_worldToScreen(vb.x,vb.y,vb.z);
      if(sa.vz>1||sb.vz>1) return;
      // Distance from point to segment
      const d=_pointToSegmentDist(clientX,clientY,sa.x,sa.y,sb.x,sb.y);
      if(d<bestDist){ bestDist=d; best=i; }
    });
    if(best===null){ if(!additive) _selected.clear(); }
    else { if(additive){ if(_selected.has(best)) _selected.delete(best); else _selected.add(best); } else { _selected.clear(); _selected.add(best); } }
  }

  // Pick face via raycasting
  function _pickFace(clientX,clientY,additive) {
    _ray.setFromCamera(_getNDC(clientX,clientY),_camera);
    const hits=_ray.intersectObjects(_faceMeshes.filter(_=>!_xray||true),false);
    // In xray, take first hit; otherwise filter by normal facing camera
    let best=null;
    for(const h of hits){
      const fi=h.object.userData.faceIndex;
      const f=_meshData.faces[fi];
      if(_xray){ best=fi; break; }
      // Check normal: must face camera
      const n=new THREE.Vector3(f.normal.x,f.normal.y,f.normal.z).transformDirection(_mesh.matrixWorld);
      const toCamera=_camera.position.clone().sub(h.point).normalize();
      if(n.dot(toCamera)>0){ best=fi; break; }
    }
    // Fallback: find face whose center is nearest to tap
    if(best===null&&_faceMeshes.length){
      const THRESH=window.devicePixelRatio>1.5?40:32;
      let bestDist=THRESH;
      _meshData.faces.forEach((f,fi)=>{
        const fc=f.center;
        if(!_xray&&!_isVisible(fc.x,fc.y,fc.z)) return;
        const s=_worldToScreen(fc.x,fc.y,fc.z);
        if(s.vz>1) return;
        const d=Math.hypot(s.x-clientX,s.y-clientY);
        if(d<bestDist){ bestDist=d; best=fi; }
      });
    }
    if(best===null){ if(!additive) _selected.clear(); }
    else { if(additive){ if(_selected.has(best)) _selected.delete(best); else _selected.add(best); } else { _selected.clear(); _selected.add(best); } }
  }

  function _pointToSegmentDist(px,py,ax,ay,bx,by){
    const dx=bx-ax, dy=by-ay;
    const lenSq=dx*dx+dy*dy;
    if(lenSq===0) return Math.hypot(px-ax,py-ay);
    const t=Math.max(0,Math.min(1,((px-ax)*dx+(py-ay)*dy)/lenSq));
    return Math.hypot(px-(ax+t*dx),py-(ay+t*dy));
  }

  // ── Box select ──
  function _applyBoxSelect(x1,y1,x2,y2,additive) {
    const minX=Math.min(x1,x2), maxX=Math.max(x1,x2);
    const minY=Math.min(y1,y2), maxY=Math.max(y1,y2);
    if(!additive) _selected.clear();
    if(_elemType==='vert'){
      _meshData.verts.forEach((v,i)=>{
        if(!_xray&&!_isVisible(v.x,v.y,v.z)) return;
        const s=_worldToScreen(v.x,v.y,v.z);
        if(s.vz>1) return;
        if(s.x>=minX&&s.x<=maxX&&s.y>=minY&&s.y<=maxY) _selected.add(i);
      });
    } else if(_elemType==='edge'){
      _meshData.edges.forEach((e,i)=>{
        const va=_meshData.verts[e.a], vb=_meshData.verts[e.b];
        const sa=_worldToScreen(va.x,va.y,va.z), sb=_worldToScreen(vb.x,vb.y,vb.z);
        if(sa.vz>1&&sb.vz>1) return;
        const mid=_worldToScreen((va.x+vb.x)/2,(va.y+vb.y)/2,(va.z+vb.z)/2);
        if(!_xray&&!_isVisible((va.x+vb.x)/2,(va.y+vb.y)/2,(va.z+vb.z)/2)) return;
        if(mid.x>=minX&&mid.x<=maxX&&mid.y>=minY&&mid.y<=maxY) _selected.add(i);
      });
    } else {
      _meshData.faces.forEach((f,i)=>{
        const fc=f.center;
        if(!_xray&&!_isVisible(fc.x,fc.y,fc.z)) return;
        const s=_worldToScreen(fc.x,fc.y,fc.z);
        if(s.vz>1) return;
        if(s.x>=minX&&s.x<=maxX&&s.y>=minY&&s.y<=maxY) _selected.add(i);
      });
    }
    _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
  }

  // ── Input binding ──
  let _boundHandlers = {};

  function _bindInput() {
    const onMouseDown = (e) => {
      if(e.button!==0) return;
      _mouseDownPos={x:e.clientX,y:e.clientY};
      _mouseMoved=false;
      _mouseDownConsumedByGizmo = !!e._egizmoConsumed;
    };
    const onMouseMove = (e) => {
      const dx=e.clientX-_mouseDownPos.x, dy=e.clientY-_mouseDownPos.y;
      if(Math.hypot(dx,dy)>5) _mouseMoved=true;
      // Box select with left drag — only when gizmo hasn't claimed this gesture
      if(e.buttons===1&&_mouseMoved&&!CameraManager.isGizmoCaptured()&&!_mouseDownConsumedByGizmo){
        if(!_boxSelecting){ _boxSelecting=true; _showBoxRect(_mouseDownPos.x,_mouseDownPos.y,e.clientX,e.clientY); }
        else { _updateBoxRect(_mouseDownPos.x,_mouseDownPos.y,e.clientX,e.clientY); }
      }
    };
    const onMouseUp = (e) => {
      if(e.button!==0) return;
      if(_editGizmoDragging) return; // gizmo is mid-drag
      if(_mouseDownConsumedByGizmo){ _mouseDownConsumedByGizmo=false; return; } // gizmo owned this gesture
      if(_boxSelecting){
        _boxSelecting=false; _hideBoxRect();
        const additive=e.shiftKey;
        _applyBoxSelect(_mouseDownPos.x,_mouseDownPos.y,e.clientX,e.clientY,additive);
      } else if(!_mouseMoved){
        const additive=e.shiftKey;
        _pickElement(e.clientX,e.clientY,additive);
        _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
      }
    };

    // Touch: tap to pick element (camera handles all drag/orbit)
    const onTouchStart = (e) => {
      if(e.touches.length!==1) return;
      const t=e.touches[0];
      _tapStart={x:t.clientX,y:t.clientY};
      _tapTouchId=t.identifier;
    };
    const onTouchEnd = (e) => {
      if(!_tapStart) return;
      if(_editGizmoDragging) { _tapStart=null; _tapTouchId=null; return; }
      for(const t of e.changedTouches){
        if(t.identifier===_tapTouchId){
          const dist=Math.hypot(t.clientX-_tapStart.x,t.clientY-_tapStart.y);
          if(dist<12){
            // Use multi-select toggle state for additive picking on touch
            const additive = EditModeSystem._multiSelectActive || false;
            _pickElement(t.clientX,t.clientY,additive);
            _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
          }
          _tapStart=null; _tapTouchId=null;
          break;
        }
      }
    };

    _boundHandlers = { onMouseDown, onMouseMove, onMouseUp, onTouchStart, onTouchEnd };
    _canvas.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    _canvas.addEventListener('touchstart', onTouchStart, {passive:true});
    _canvas.addEventListener('touchend', onTouchEnd, {passive:true});
  }

  function _unbindInput() {
    const h=_boundHandlers;
    _canvas.removeEventListener('mousedown', h.onMouseDown);
    window.removeEventListener('mousemove', h.onMouseMove);
    window.removeEventListener('mouseup', h.onMouseUp);
    _canvas.removeEventListener('touchstart', h.onTouchStart);
    _canvas.removeEventListener('touchend', h.onTouchEnd);
    _boundHandlers = {};
  }

  function _pickElement(clientX,clientY,additive){
    if(_elemType==='vert') _pickVertex(clientX,clientY,additive);
    else if(_elemType==='edge') _pickEdge(clientX,clientY,additive);
    else _pickFace(clientX,clientY,additive);
  }

  // ── Box select rect UI ──
  function _showBoxRect(x1,y1,x2,y2){
    const r=document.getElementById('box-select-rect');
    if(!r) return;
    r.style.display='block';
    _updateBoxRect(x1,y1,x2,y2);
  }
  function _updateBoxRect(x1,y1,x2,y2){
    const r=document.getElementById('box-select-rect');
    if(!r) return;
    const vp=_canvas.getBoundingClientRect();
    const mx=Math.min(x1,x2)-vp.left, my=Math.min(y1,y2)-vp.top;
    const w=Math.abs(x2-x1), h=Math.abs(y2-y1);
    r.style.left=mx+'px'; r.style.top=my+'px'; r.style.width=w+'px'; r.style.height=h+'px';
  }
  function _hideBoxRect(){
    const r=document.getElementById('box-select-rect');
    if(r) r.style.display='none';
  }

  // Sync transform if mesh is moved while in edit mode
  function syncMeshTransform() { _syncOverlayTransform(); }

  // Called from render loop to keep gizmo updated
  function tickGizmo() {
    if(!_active || !_gizmoGroup) return;
    _updateGizmoVisibility();
  }

  // ── Inset Tool ──────────────────────────────────────────────────────────
  function _snapshotMeshData() {
    return {
      verts: _meshData.verts.map(v=>({x:v.x,y:v.y,z:v.z})),
      faces: _meshData.faces.map(f=>({verts:f.verts.slice(),edges:f.edges.slice(),normal:{x:f.normal.x,y:f.normal.y,z:f.normal.z},center:{x:f.center.x,y:f.center.y,z:f.center.z}})),
      edges: _meshData.edges.map(e=>({a:e.a,b:e.b,faces:e.faces.slice()}))
    };
  }

  function _restoreSnapshot(snap) {
    _meshData.verts = snap.verts.map(v=>({x:v.x,y:v.y,z:v.z}));
    _meshData.faces = snap.faces.map(f=>({verts:f.verts.slice(),edges:f.edges.slice(),normal:{x:f.normal.x,y:f.normal.y,z:f.normal.z},center:{x:f.center.x,y:f.center.y,z:f.center.z}}));
    _meshData.edges = snap.edges.map(e=>({a:e.a,b:e.b,faces:e.faces.slice()}));
  }

  function _applyInsetPreview(amount) {
    if(!_insetSnapshot || !_meshData) return;
    _restoreSnapshot(_insetSnapshot);

    const verts = _meshData.verts;
    const faces  = _meshData.faces;
    const t = Math.max(0, Math.min(amount, 0.499));
    const newInnerFaceIndices = [];

    _insetFaceIndices.forEach(fi => {
      const face = faces[fi];
      if(!face || face.verts.length < 3) return;

      const vi0=face.verts[0], vi1=face.verts[1], vi2=face.verts[2];
      const ov0=_insetSnapshot.verts[vi0], ov1=_insetSnapshot.verts[vi1], ov2=_insetSnapshot.verts[vi2];

      // Centroid from snapshot
      const cx=(ov0.x+ov1.x+ov2.x)/3, cy=(ov0.y+ov1.y+ov2.y)/3, cz=(ov0.z+ov1.z+ov2.z)/3;

      // New inner verts
      const ni0=verts.length; verts.push({x:ov0.x+(cx-ov0.x)*t, y:ov0.y+(cy-ov0.y)*t, z:ov0.z+(cz-ov0.z)*t});
      const ni1=verts.length; verts.push({x:ov1.x+(cx-ov1.x)*t, y:ov1.y+(cy-ov1.y)*t, z:ov1.z+(cz-ov1.z)*t});
      const ni2=verts.length; verts.push({x:ov2.x+(cx-ov2.x)*t, y:ov2.y+(cy-ov2.y)*t, z:ov2.z+(cz-ov2.z)*t});

      // Replace original face with inner face (same winding → same normal)
      face.verts=[ni0,ni1,ni2];
      const nv0=verts[ni0],nv1=verts[ni1],nv2=verts[ni2];
      const abx=nv1.x-nv0.x,aby=nv1.y-nv0.y,abz=nv1.z-nv0.z;
      const acx=nv2.x-nv0.x,acy=nv2.y-nv0.y,acz=nv2.z-nv0.z;
      const nx=aby*acz-abz*acy, ny=abz*acx-abx*acz, nz=abx*acy-aby*acx;
      const nl=Math.sqrt(nx*nx+ny*ny+nz*nz)||1;
      face.normal={x:nx/nl,y:ny/nl,z:nz/nl};
      face.center={x:(nv0.x+nv1.x+nv2.x)/3,y:(nv0.y+nv1.y+nv2.y)/3,z:(nv0.z+nv1.z+nv2.z)/3};
      newInnerFaceIndices.push(fi);

      // Face normal for winding reference
      const fn=face.normal;

      // Helper: add one side quad connecting outer edge (oA→oB) to inner edge (niA→niB)
      function _addSideQuad(oA,oB,niA,niB){
        const outerA=verts.length; verts.push({x:oA.x,y:oA.y,z:oA.z});
        const outerB=verts.length; verts.push({x:oB.x,y:oB.y,z:oB.z});
        // Check winding alignment with face normal
        const dBx=oB.x-oA.x,dBy=oB.y-oA.y,dBz=oB.z-oA.z;
        const niAv=verts[niA];
        const dAx=niAv.x-oA.x,dAy=niAv.y-oA.y,dAz=niAv.z-oA.z;
        const tnx=dBy*dAz-dBz*dAy, tny=dBz*dAx-dBx*dAz, tnz=dBx*dAy-dBy*dAx;
        const agree=tnx*fn.x+tny*fn.y+tnz*fn.z;
        function _pushTri(a,b,c){
          const va=verts[a],vb=verts[b],vc=verts[c];
          const e1x=vb.x-va.x,e1y=vb.y-va.y,e1z=vb.z-va.z;
          const e2x=vc.x-va.x,e2y=vc.y-va.y,e2z=vc.z-va.z;
          const fnx=e1y*e2z-e1z*e2y,fny=e1z*e2x-e1x*e2z,fnz=e1x*e2y-e1y*e2x;
          const fl=Math.sqrt(fnx*fnx+fny*fny+fnz*fnz)||1;
          faces.push({verts:[a,b,c],edges:[],normal:{x:fnx/fl,y:fny/fl,z:fnz/fl},center:{x:(va.x+vb.x+vc.x)/3,y:(va.y+vb.y+vc.y)/3,z:(va.z+vb.z+vc.z)/3}});
        }
        if(agree>=0){ _pushTri(outerA,outerB,niB); _pushTri(outerA,niB,niA); }
        else         { _pushTri(outerA,niB,outerB); _pushTri(outerA,niA,niB); }
      }

      _addSideQuad(ov0,ov1,ni0,ni1);
      _addSideQuad(ov1,ov2,ni1,ni2);
      _addSideQuad(ov2,ov0,ni2,ni0);
    });

    // Rebuild edge topology
    const edgeMap=new Map(); const newEdges=[];
    function _ek(a,b){return a<b?`${a}-${b}`:`${b}-${a}`;}
    function _goe(a,b){const k=_ek(a,b);if(!edgeMap.has(k)){edgeMap.set(k,newEdges.length);newEdges.push({a,b,faces:[]});}return edgeMap.get(k);}
    faces.forEach((f,fi)=>{
      if(f.verts.length<3)return;
      const eA=_goe(f.verts[0],f.verts[1]);newEdges[eA].faces.push(fi);
      const eB=_goe(f.verts[1],f.verts[2]);newEdges[eB].faces.push(fi);
      const eC=_goe(f.verts[2],f.verts[0]);newEdges[eC].faces.push(fi);
      f.edges=[eA,eB,eC];
    });
    _meshData.edges=newEdges;

    // DoubleSide prevents invisible faces from winding edge cases
    if(_mesh&&_mesh.material){_mesh.material.side=THREE.DoubleSide;_mesh.material.needsUpdate=true;}

    // Full geometry commit
    _writebackGeometry('topology');

    // Select inner faces
    _selected.clear();
    newInnerFaceIndices.forEach(fi=>_selected.add(fi));

    _rebuildOverlaysFull();
    _refreshOverlay();
    _refreshUI();
    _updateGizmoVisibility();
  }

  function startInset() {
    if(!_active||_elemType!=='face'||_selected.size===0) return;
    if(_insetActive) return;
    _insetFaceIndices=[..._selected];
    _insetSnapshot=_snapshotMeshData();
    _insetAmount=0.2;
    _insetActive=true;
    const overlay=document.getElementById('inset-overlay');
    if(overlay) overlay.classList.add('active');
    const slider=document.getElementById('inset-slider');
    if(slider){slider.value=20;slider.style.setProperty('--val','20');}
    const valEl=document.getElementById('inset-amount-val');
    if(valEl) valEl.textContent='0.200';
    CameraManager.setGizmoCaptured(true);
    _applyInsetPreview(_insetAmount);
    _bindInsetInput();
  }

  function _confirmInset() {
    if(!_insetActive) return;
    // The insetSnapshot holds the pre-inset state — push it as the undo entry
    if(_insetSnapshot) UndoHistory.push(_insetSnapshot, _elemType, new Set(_insetFaceIndices));
    _refreshUndoButtons();
    _insetActive=false; _insetSnapshot=null; _insetFaceIndices=[];
    const overlay=document.getElementById('inset-overlay');
    if(overlay) overlay.classList.remove('active');
    CameraManager.setGizmoCaptured(false);
    _unbindInsetInput();
    _writebackGeometry('topology');
    _rebuildOverlaysFull();
    _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
  }

  function _cancelInset() {
    if(!_insetActive) return;
    const savedFaces=[..._insetFaceIndices];
    _insetActive=false;
    if(_insetSnapshot) _restoreSnapshot(_insetSnapshot);
    _insetSnapshot=null; _insetFaceIndices=[];
    const overlay=document.getElementById('inset-overlay');
    if(overlay) overlay.classList.remove('active');
    CameraManager.setGizmoCaptured(false);
    _unbindInsetInput();
    _writebackGeometry('topology');
    _rebuildOverlaysFull();
    _selected.clear();
    savedFaces.forEach(fi=>_selected.add(fi));
    _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
  }

  let _insetInputHandlers={};

  function _bindInsetInput() {
    const slider=document.getElementById('inset-slider');
    const valEl=document.getElementById('inset-amount-val');
    const overlay=document.getElementById('inset-overlay');
    const confirmBtn=document.getElementById('inset-confirm');
    const cancelBtn=document.getElementById('inset-cancel');

    const onSliderInput=()=>{
      const v=parseInt(slider.value,10);
      slider.style.setProperty('--val',v);
      _insetAmount=v/100;
      if(valEl) valEl.textContent=_insetAmount.toFixed(3);
      _applyInsetPreview(_insetAmount);
    };

    let _iMouseDragging=false;
    const onOverlayTouchStart=(e)=>{
      if(e.target.id==='inset-slider'||e.target.closest('#inset-btn-row')) return;
      if(e.touches.length!==1) return;
      const t=e.touches[0]; _insetDragStartX=t.clientX; _insetDragStartAmount=_insetAmount; _insetTouchId=t.identifier;
      e.preventDefault();
    };
    const onOverlayTouchMove=(e)=>{
      if(_insetTouchId===null) return;
      let touch=null; for(const t of e.touches){if(t.identifier===_insetTouchId){touch=t;break;}} if(!touch) return;
      e.preventDefault();
      const dx=touch.clientX-_insetDragStartX;
      const newAmt=Math.max(0,Math.min(0.499,_insetDragStartAmount+dx/200));
      _insetAmount=newAmt;
      const sv=Math.round(newAmt*100);
      if(slider){slider.value=sv;slider.style.setProperty('--val',sv);}
      if(valEl) valEl.textContent=newAmt.toFixed(3);
      _applyInsetPreview(newAmt);
    };
    const onOverlayTouchEnd=()=>{ _insetTouchId=null; };

    const onOverlayMouseDown=(e)=>{
      if(e.target.id==='inset-slider'||e.target.closest('#inset-btn-row')||e.target.closest('#inset-hud')) return;
      _iMouseDragging=true; _insetDragStartX=e.clientX; _insetDragStartAmount=_insetAmount; e.preventDefault();
    };
    const onOverlayMouseMove=(e)=>{
      if(!_iMouseDragging) return;
      const dx=e.clientX-_insetDragStartX;
      const newAmt=Math.max(0,Math.min(0.499,_insetDragStartAmount+dx/200));
      _insetAmount=newAmt;
      const sv=Math.round(newAmt*100);
      if(slider){slider.value=sv;slider.style.setProperty('--val',sv);}
      if(valEl) valEl.textContent=newAmt.toFixed(3);
      _applyInsetPreview(newAmt);
    };
    const onOverlayMouseUp=()=>{ _iMouseDragging=false; };

    const onConfirm=()=>_confirmInset();
    const onCancel=()=>_cancelInset();
    const onKey=(e)=>{
      if(!_insetActive) return;
      if(e.key==='Enter'){e.preventDefault();_confirmInset();}
      if(e.key==='Escape'){e.preventDefault();_cancelInset();}
    };

    slider&&slider.addEventListener('input',onSliderInput);
    overlay&&overlay.addEventListener('touchstart',onOverlayTouchStart,{passive:false});
    overlay&&overlay.addEventListener('touchmove',onOverlayTouchMove,{passive:false});
    overlay&&overlay.addEventListener('touchend',onOverlayTouchEnd,{passive:true});
    overlay&&overlay.addEventListener('mousedown',onOverlayMouseDown);
    window.addEventListener('mousemove',onOverlayMouseMove);
    window.addEventListener('mouseup',onOverlayMouseUp);
    confirmBtn&&confirmBtn.addEventListener('click',onConfirm);
    cancelBtn&&cancelBtn.addEventListener('click',onCancel);
    window.addEventListener('keydown',onKey,{capture:true});

    _insetInputHandlers={onSliderInput,onOverlayTouchStart,onOverlayTouchMove,onOverlayTouchEnd,onOverlayMouseDown,onOverlayMouseMove,onOverlayMouseUp,onConfirm,onCancel,onKey,slider,overlay,confirmBtn,cancelBtn};
  }

  function _unbindInsetInput() {
    const h=_insetInputHandlers;
    h.slider&&h.slider.removeEventListener('input',h.onSliderInput);
    h.overlay&&h.overlay.removeEventListener('touchstart',h.onOverlayTouchStart);
    h.overlay&&h.overlay.removeEventListener('touchmove',h.onOverlayTouchMove);
    h.overlay&&h.overlay.removeEventListener('touchend',h.onOverlayTouchEnd);
    h.overlay&&h.overlay.removeEventListener('mousedown',h.onOverlayMouseDown);
    window.removeEventListener('mousemove',h.onOverlayMouseMove);
    window.removeEventListener('mouseup',h.onOverlayMouseUp);
    h.confirmBtn&&h.confirmBtn.removeEventListener('click',h.onConfirm);
    h.cancelBtn&&h.cancelBtn.removeEventListener('click',h.onCancel);
    window.removeEventListener('keydown',h.onKey,{capture:true});
    _insetInputHandlers={};
  }
  // ── End Inset Tool ───────────────────────────────────────────────────────

  // ══════════════════════════════════════════════════════════════════════════
  //  Bevel Tool
  //  Works on selected edges (edge mode) and collects all edges of selected
  //  faces (face mode). For each selected edge, we:
  //   1. Split both endpoint vertices into two separate verts displaced along
  //      their adjacent edge-loop tangents.
  //   2. Fill a chamfer quad (2 tris) between the two new edge-loop edges.
  //   3. Patch all surrounding faces to use the new split verts instead of
  //      the original verts — preserving clean connected topology.
  //  After every preview the full topology is rebuilt and normals are
  //  recomputed, eliminating flipped/shading artifacts.
  // ══════════════════════════════════════════════════════════════════════════

  function _applyBevelPreview(amount) {
    if(!_bevelSnapshot || !_meshData) return;
    _restoreSnapshot(_bevelSnapshot);

    const t = Math.max(0, Math.min(amount, 0.5));
    if(t < 1e-6) {
      _writebackGeometry('topology');
      _rebuildOverlaysFull();
      _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
      return;
    }

    const verts = _meshData.verts;
    const faces = _meshData.faces;

    // ── Step 1: For each bevel edge endpoint, build a split-vert per incident bevel-edge.
    //   The split-vert is displaced from the original vert along that edge direction by `t`.
    //   Key: edgeKey(vi, ni)  →  new vert index in verts[].
    //   vertSplitMap: vi → Map(edgeKey → newVertIndex)
    const vertBevelNeighbours = new Map();
    _bevelEdgeIndices.forEach(ei => {
      const e = _bevelSnapshot.edges[ei]; if(!e) return;
      if(!vertBevelNeighbours.has(e.a)) vertBevelNeighbours.set(e.a, []);
      if(!vertBevelNeighbours.has(e.b)) vertBevelNeighbours.set(e.b, []);
      vertBevelNeighbours.get(e.a).push(e.b);
      vertBevelNeighbours.get(e.b).push(e.a);
    });

    const _ek = (a,b) => a < b ? `${a}-${b}` : `${b}-${a}`;
    const vertSplitMap = new Map();

    vertBevelNeighbours.forEach((neighbours, vi) => {
      const ov = _bevelSnapshot.verts[vi];
      const innerMap = new Map();
      neighbours.forEach(ni => {
        const nv = _bevelSnapshot.verts[ni];
        const dx=nv.x-ov.x, dy=nv.y-ov.y, dz=nv.z-ov.z;
        const len = Math.sqrt(dx*dx+dy*dy+dz*dz) || 1;
        const newIdx = verts.length;
        verts.push({ x: ov.x+(dx/len)*t, y: ov.y+(dy/len)*t, z: ov.z+(dz/len)*t });
        innerMap.set(_ek(vi, ni), newIdx);
      });
      vertSplitMap.set(vi, innerMap);
    });

    // ── Step 2: Remap existing face vertices.
    //   For each original face, for each corner vi that was split, we need to pick
    //   the correct split-vert. The correct one is the split that was displaced
    //   toward the neighbour that is also a corner of this face (or the one closest
    //   to the face centroid when the edge is fully interior).
    //
    //   Strategy: for each corner vi in a face, collect all OTHER corners of the face.
    //   If a split-vert key matches any of those corners (i.e. vi→neighbour where
    //   neighbour is in this face), use it. Otherwise fall back to closest.
    //   Only iterate over the snapshot's original faces (not newly added chamfer faces).
    const origFaceCount = _bevelSnapshot.faces.length;

    for(let fi = 0; fi < origFaceCount; fi++) {
      const f = faces[fi];
      if(!f || f.verts.length < 3) continue;
      const faceVertSet = new Set(f.verts);
      let changed = false;
      f.verts = f.verts.map(vi => {
        if(!vertSplitMap.has(vi)) return vi;
        const splits = vertSplitMap.get(vi);
        // Prefer the split-vert whose key's neighbour is also in this face
        for(const [key, newVi] of splits) {
          const parts = key.split('-');
          const ni = parseInt(parts[0]) === vi ? parseInt(parts[1]) : parseInt(parts[0]);
          if(faceVertSet.has(ni)) { changed = true; return newVi; }
        }
        // Fallback: pick the split-vert nearest to the face centroid
        const fc = f.center || {
          x:(verts[f.verts[0]].x+verts[f.verts[1]].x+verts[f.verts[2]].x)/3,
          y:(verts[f.verts[0]].y+verts[f.verts[1]].y+verts[f.verts[2]].y)/3,
          z:(verts[f.verts[0]].z+verts[f.verts[1]].z+verts[f.verts[2]].z)/3,
        };
        let bestIdx = vi, bestDist = Infinity;
        splits.forEach(newVi => {
          const sv = verts[newVi];
          const d = Math.hypot(sv.x-fc.x, sv.y-fc.y, sv.z-fc.z);
          if(d < bestDist) { bestDist = d; bestIdx = newVi; }
        });
        if(bestIdx !== vi) changed = true;
        return bestIdx;
      });
      if(changed) {
        const p0=verts[f.verts[0]], p1=verts[f.verts[1]], p2=verts[f.verts[2]];
        const e1x=p1.x-p0.x, e1y=p1.y-p0.y, e1z=p1.z-p0.z;
        const e2x=p2.x-p0.x, e2y=p2.y-p0.y, e2z=p2.z-p0.z;
        const nx=e1y*e2z-e1z*e2y, ny=e1z*e2x-e1x*e2z, nz=e1x*e2y-e1y*e2x;
        const nl=Math.sqrt(nx*nx+ny*ny+nz*nz)||1;
        f.normal={x:nx/nl,y:ny/nl,z:nz/nl};
        f.center={x:(p0.x+p1.x+p2.x)/3,y:(p0.y+p1.y+p2.y)/3,z:(p0.z+p1.z+p2.z)/3};
      }
    }

    // ── Step 3: Add proper chamfer quad faces for each beveled edge.
    //   Each bevel edge (a,b) produces 4 split-verts:
    //     Sa  = split at a pointing toward b  (splitA)
    //     Sb  = split at b pointing toward a  (splitB)
    //   These 2 verts plus the 2 corresponding original verts already remapped in
    //   the surrounding faces define the chamfer strip.
    //   The chamfer quad is: [Sa, Sb, <Sb's counterpart at b>, <Sa's counterpart at a>]
    //   but since each endpoint only has ONE split per bevel-edge here, the flat
    //   chamfer strip is simply the quad [Sa, Sb, Sb_mirror, Sa_mirror] where
    //   Sa_mirror/Sb_mirror are from any OTHER bevel-edges at those verts, or
    //   just the two split verts themselves connected as a single flat quad using
    //   the original vert positions as the "back" of the quad.
    //
    //   For a simple 1-segment bevel: the chamfer quad connects:
    //     splitA (displaced from a toward b)
    //     splitB (displaced from b toward a)
    //   The quad needs 4 verts. We pair splitA with a duplicate "back" vert at a,
    //   and splitB with a duplicate "back" vert at b, but those originals are now
    //   owned by non-bevel adjacent faces. The correct approach:
    //
    //   The chamfer quad verts are the two split verts Sa and Sb.
    //   Because Sa is displaced from a toward b, and Sb from b toward a,
    //   the quad [Sa_from_a, Sb_from_b, splitB_at_b_pointing_away, splitA_at_a_pointing_away]
    //   gives the full chamfer when there are multiple incident bevel edges.
    //   For a single bevel edge with no other bevel edges at the endpoints,
    //   we create the chamfer using the original vert positions as the "far" verts:
    const _pushTri = (v0, v1, v2, refN) => {
      const p0=verts[v0], p1=verts[v1], p2=verts[v2];
      const e1x=p1.x-p0.x, e1y=p1.y-p0.y, e1z=p1.z-p0.z;
      const e2x=p2.x-p0.x, e2y=p2.y-p0.y, e2z=p2.z-p0.z;
      let nx=e1y*e2z-e1z*e2y, ny=e1z*e2x-e1x*e2z, nz=e1x*e2y-e1y*e2x;
      const nl=Math.sqrt(nx*nx+ny*ny+nz*nz)||1;
      // Ensure normal aligns with reference
      if(refN && (nx*refN.x+ny*refN.y+nz*refN.z) < 0) {
        // swap v1 and v2 to flip winding
        [v1, v2] = [v2, v1];
        nx=-nx/nl; ny=-ny/nl; nz=-nz/nl;
      } else { nx/=nl; ny/=nl; nz/=nl; }
      const pp0=verts[v0],pp1=verts[v1],pp2=verts[v2];
      faces.push({verts:[v0,v1,v2], edges:[],
        normal:{x:nx,y:ny,z:nz},
        center:{x:(pp0.x+pp1.x+pp2.x)/3,y:(pp0.y+pp1.y+pp2.y)/3,z:(pp0.z+pp1.z+pp2.z)/3}
      });
    };

    _bevelEdgeIndices.forEach(ei => {
      const e = _bevelSnapshot.edges[ei]; if(!e) return;
      const key = _ek(e.a, e.b);
      const splitA = vertSplitMap.get(e.a) && vertSplitMap.get(e.a).get(key); // at a, pointing toward b
      const splitB = vertSplitMap.get(e.b) && vertSplitMap.get(e.b).get(key); // at b, pointing toward a
      if(splitA === undefined || splitB === undefined) return;

      // Reference normal from first adjacent face
      const adjFaces = _bevelSnapshot.edges[ei].faces;
      let refNormal = null;
      if(adjFaces.length > 0) {
        const rf = _bevelSnapshot.faces[adjFaces[0]];
        if(rf) refNormal = rf.normal;
      }

      // Check if there are other bevel-edges at each endpoint.
      // If so, use their split-verts as the "far" verts of the quad.
      // Otherwise use the original vert index (which surrounding faces will have remapped away from).
      const getOtherSplitAt = (vi, excludeNi) => {
        const splits = vertSplitMap.get(vi);
        if(!splits) return null;
        for(const [k, newVi] of splits) {
          const parts = k.split('-');
          const ni = parseInt(parts[0]) === vi ? parseInt(parts[1]) : parseInt(parts[0]);
          if(ni !== excludeNi) return newVi;
        }
        return null;
      };

      // farA = the split-vert at vertex a pointing AWAY from b (toward other bevel-edge neighbour)
      // farB = the split-vert at vertex b pointing AWAY from a
      const farA = getOtherSplitAt(e.a, e.b);
      const farB = getOtherSplitAt(e.b, e.a);

      if(farA !== null && farB !== null) {
        // Full chamfer quad: farA, splitA, splitB, farB  →  2 tris
        _pushTri(farA, splitA, splitB, refNormal);
        _pushTri(farA, splitB, farB,   refNormal);
      } else if(farA !== null) {
        // Triangle: farA, splitA, splitB
        _pushTri(farA, splitA, splitB, refNormal);
      } else if(farB !== null) {
        // Triangle: splitA, splitB, farB
        _pushTri(splitA, splitB, farB, refNormal);
      } else {
        // No other bevel-edges at either endpoint — simple 2-vert chamfer.
        // The chamfer "strip" degenerates to a line segment, but we still
        // emit a thin quad using the two split-verts and a midpoint to form
        // a visible chamfer face.
        const ov_a = _bevelSnapshot.verts[e.a];
        const ov_b = _bevelSnapshot.verts[e.b];
        // Midpoint of original edge
        const midIdx = verts.length;
        verts.push({
          x:(ov_a.x+ov_b.x)*0.5,
          y:(ov_a.y+ov_b.y)*0.5,
          z:(ov_a.z+ov_b.z)*0.5
        });
        _pushTri(splitA, splitB, midIdx, refNormal);
      }
    });

    // ── Step 4: Rebuild full edge topology ──
    const edgeMap2 = new Map(); const newEdges2 = [];
    const _goe2 = (a,b) => {
      const k = _ek(a,b);
      if(!edgeMap2.has(k)){ edgeMap2.set(k, newEdges2.length); newEdges2.push({a,b,faces:[]}); }
      return edgeMap2.get(k);
    };
    faces.forEach((f,fi) => {
      if(!f || f.verts.length < 3) return;
      const eA=_goe2(f.verts[0],f.verts[1]); newEdges2[eA].faces.push(fi);
      const eB=_goe2(f.verts[1],f.verts[2]); newEdges2[eB].faces.push(fi);
      const eC=_goe2(f.verts[2],f.verts[0]); newEdges2[eC].faces.push(fi);
      f.edges=[eA,eB,eC];
    });
    _meshData.edges = newEdges2;

    // DoubleSide prevents invisible faces from winding edge cases
    if(_mesh && _mesh.material) {
      _mesh.material.side = THREE.DoubleSide;
      _mesh.material.needsUpdate = true;
    }

    // Full geometry commit — recomputes normals, bounding box, bounding sphere
    _writebackGeometry('topology');

    // Rebuild overlays and refresh
    _rebuildOverlaysFull();
    _refreshOverlay();
    _refreshUI();
    _updateGizmoVisibility();
  }

  function startBevel() {
    if(!_active || _selected.size === 0) return;
    if(_insetActive || _bevelActive) return;

    // Collect edge indices: direct selection in edge mode, or all edges of selected faces
    let edgeIndices = [];
    if(_elemType === 'edge') {
      edgeIndices = [..._selected];
    } else if(_elemType === 'face') {
      const edgeSet = new Set();
      _selected.forEach(fi => {
        const f = _meshData.faces[fi];
        if(f) f.edges.forEach(ei => edgeSet.add(ei));
      });
      edgeIndices = [...edgeSet];
    } else {
      return; // vertex mode: no bevel
    }
    if(edgeIndices.length === 0) return;

    _bevelEdgeIndices = edgeIndices;
    _bevelSnapshot = _snapshotMeshData();
    _bevelAmount = 0.1;
    _bevelActive = true;

    const overlay = document.getElementById('bevel-overlay');
    if(overlay) overlay.classList.add('active');
    const slider = document.getElementById('bevel-slider');
    if(slider){ slider.value = 10; slider.style.setProperty('--val','10'); }
    const valEl = document.getElementById('bevel-amount-val');
    if(valEl) valEl.textContent = '0.100';

    CameraManager.setGizmoCaptured(true);
    _applyBevelPreview(_bevelAmount);
    _bindBevelInput();
  }

  function _confirmBevel() {
    if(!_bevelActive) return;
    // The bevelSnapshot holds the pre-bevel state — push it as the undo entry
    if(_bevelSnapshot) UndoHistory.push(_bevelSnapshot, _elemType, new Set(_bevelEdgeIndices));
    _refreshUndoButtons();
    _bevelActive = false; _bevelSnapshot = null; _bevelEdgeIndices = [];
    const overlay = document.getElementById('bevel-overlay');
    if(overlay) overlay.classList.remove('active');
    CameraManager.setGizmoCaptured(false);
    _unbindBevelInput();
    _writebackGeometry('topology');
    _rebuildOverlaysFull();
    _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
  }

  function _cancelBevel() {
    if(!_bevelActive) return;
    _bevelActive = false;
    if(_bevelSnapshot) _restoreSnapshot(_bevelSnapshot);
    _bevelSnapshot = null; _bevelEdgeIndices = [];
    const overlay = document.getElementById('bevel-overlay');
    if(overlay) overlay.classList.remove('active');
    CameraManager.setGizmoCaptured(false);
    _unbindBevelInput();
    _writebackGeometry('topology');
    _rebuildOverlaysFull();
    _refreshOverlay(); _refreshUI(); _updateGizmoVisibility();
  }

  function _bindBevelInput() {
    const slider    = document.getElementById('bevel-slider');
    const valEl     = document.getElementById('bevel-amount-val');
    const overlay   = document.getElementById('bevel-overlay');
    const confirmBtn= document.getElementById('bevel-confirm');
    const cancelBtn = document.getElementById('bevel-cancel');

    const onSliderInput = () => {
      const v = parseInt(slider.value, 10);
      slider.style.setProperty('--val', v);
      _bevelAmount = v / 100;
      if(valEl) valEl.textContent = _bevelAmount.toFixed(3);
      _applyBevelPreview(_bevelAmount);
    };

    let _bMouseDragging = false;
    const onOverlayTouchStart = (e) => {
      if(e.target.id==='bevel-slider'||e.target.closest('#bevel-btn-row')) return;
      if(e.touches.length!==1) return;
      const t=e.touches[0]; _bevelDragStartX=t.clientX; _bevelDragStartAmount=_bevelAmount; _bevelTouchId=t.identifier;
      e.preventDefault();
    };
    const onOverlayTouchMove = (e) => {
      if(_bevelTouchId===null) return;
      let touch=null; for(const t of e.touches){if(t.identifier===_bevelTouchId){touch=t;break;}} if(!touch) return;
      e.preventDefault();
      const dx = touch.clientX - _bevelDragStartX;
      const newAmt = Math.max(0, Math.min(0.5, _bevelDragStartAmount + dx/200));
      _bevelAmount = newAmt;
      const sv = Math.round(newAmt*100);
      if(slider){slider.value=sv; slider.style.setProperty('--val',sv);}
      if(valEl) valEl.textContent = newAmt.toFixed(3);
      _applyBevelPreview(newAmt);
    };
    const onOverlayTouchEnd = () => { _bevelTouchId = null; };

    const onOverlayMouseDown = (e) => {
      if(e.target.id==='bevel-slider'||e.target.closest('#bevel-btn-row')||e.target.closest('#bevel-hud')) return;
      _bMouseDragging=true; _bevelDragStartX=e.clientX; _bevelDragStartAmount=_bevelAmount; e.preventDefault();
    };
    const onOverlayMouseMove = (e) => {
      if(!_bMouseDragging) return;
      const dx = e.clientX - _bevelDragStartX;
      const newAmt = Math.max(0, Math.min(0.5, _bevelDragStartAmount + dx/200));
      _bevelAmount = newAmt;
      const sv = Math.round(newAmt*100);
      if(slider){slider.value=sv; slider.style.setProperty('--val',sv);}
      if(valEl) valEl.textContent = newAmt.toFixed(3);
      _applyBevelPreview(newAmt);
    };
    const onOverlayMouseUp = () => { _bMouseDragging = false; };

    const onConfirm = () => _confirmBevel();
    const onCancel  = () => _cancelBevel();
    const onKey = (e) => {
      if(!_bevelActive) return;
      if(e.key==='Enter'){ e.preventDefault(); _confirmBevel(); }
      if(e.key==='Escape'){ e.preventDefault(); _cancelBevel(); }
    };

    slider    && slider.addEventListener('input', onSliderInput);
    overlay   && overlay.addEventListener('touchstart', onOverlayTouchStart, {passive:false});
    overlay   && overlay.addEventListener('touchmove',  onOverlayTouchMove,  {passive:false});
    overlay   && overlay.addEventListener('touchend',   onOverlayTouchEnd,   {passive:true});
    overlay   && overlay.addEventListener('mousedown',  onOverlayMouseDown);
    window.addEventListener('mousemove', onOverlayMouseMove);
    window.addEventListener('mouseup',   onOverlayMouseUp);
    confirmBtn && confirmBtn.addEventListener('click', onConfirm);
    cancelBtn  && cancelBtn.addEventListener('click',  onCancel);
    window.addEventListener('keydown', onKey, {capture:true});

    _bevelInputHandlers = {onSliderInput,onOverlayTouchStart,onOverlayTouchMove,onOverlayTouchEnd,onOverlayMouseDown,onOverlayMouseMove,onOverlayMouseUp,onConfirm,onCancel,onKey,slider,overlay,confirmBtn,cancelBtn};
  }

  function _unbindBevelInput() {
    const h = _bevelInputHandlers;
    h.slider    && h.slider.removeEventListener('input', h.onSliderInput);
    h.overlay   && h.overlay.removeEventListener('touchstart', h.onOverlayTouchStart);
    h.overlay   && h.overlay.removeEventListener('touchmove',  h.onOverlayTouchMove);
    h.overlay   && h.overlay.removeEventListener('touchend',   h.onOverlayTouchEnd);
    h.overlay   && h.overlay.removeEventListener('mousedown',  h.onOverlayMouseDown);
    window.removeEventListener('mousemove', h.onOverlayMouseMove);
    window.removeEventListener('mouseup',   h.onOverlayMouseUp);
    h.confirmBtn && h.confirmBtn.removeEventListener('click', h.onConfirm);
    h.cancelBtn  && h.cancelBtn.removeEventListener('click',  h.onCancel);
    window.removeEventListener('keydown', h.onKey, {capture:true});
    _bevelInputHandlers = {};
  }
  // ── End Bevel Tool ────────────────────────────────────────────────────────

  // ── Undo/Redo support ──────────────────────────────────────────────────────

  function _refreshUndoButtons() {
    const undoBtn = document.getElementById('btn-undo');
    const redoBtn = document.getElementById('btn-redo');
    if(undoBtn) {
      const can = UndoHistory.canUndo();
      undoBtn.disabled = !can;
      undoBtn.style.opacity = can ? '1' : '0.35';
      undoBtn.style.cursor  = can ? 'pointer' : 'not-allowed';
    }
    if(redoBtn) {
      const can = UndoHistory.canRedo();
      redoBtn.disabled = !can;
      redoBtn.style.opacity = can ? '1' : '0.35';
      redoBtn.style.cursor  = can ? 'pointer' : 'not-allowed';
    }
  }

  // Snapshot current state onto the undo stack. Call BEFORE mutating meshData.
  function pushUndo() {
    if(!_active || !_meshData) return;
    UndoHistory.push(_meshData, _elemType, _selected);
    _refreshUndoButtons();
  }

  // Restore a history state (returned by UndoHistory.undo/redo).
  function applyHistoryState(state) {
    if(!state || !_active) return;
    // Restore meshData in-place
    _meshData.verts = state.meshData.verts.map(v => ({x:v.x, y:v.y, z:v.z}));
    _meshData.faces = state.meshData.faces.map(f => ({
      verts: f.verts.slice(),
      edges: f.edges.slice(),
      normal: {x:f.normal.x, y:f.normal.y, z:f.normal.z},
      center: {x:f.center.x, y:f.center.y, z:f.center.z}
    }));
    _meshData.edges = state.meshData.edges.map(e => ({a:e.a, b:e.b, faces:e.faces.slice()}));

    // Restore selection and elem type
    _elemType = state.elemType;
    _selected.clear();
    state.selected.forEach(i => _selected.add(i));

    // Sync elem-type buttons
    document.getElementById('elem-vert').classList.toggle('active', _elemType === 'vert');
    document.getElementById('elem-edge').classList.toggle('active', _elemType === 'edge');
    document.getElementById('elem-face').classList.toggle('active', _elemType === 'face');

    // Clamp selection to valid range after topology change
    const maxIdx = _elemType === 'vert' ? _meshData.verts.length
                 : _elemType === 'edge' ? _meshData.edges.length
                 : _meshData.faces.length;
    _selected.forEach(i => { if(i >= maxIdx) _selected.delete(i); });

    // Commit to GPU and rebuild
    if(_mesh && _mesh.material) {
      _mesh.material.side = THREE.DoubleSide;
      _mesh.material.needsUpdate = true;
    }
    _writebackGeometry('topology');
    _rebuildOverlaysFull();
    _refreshOverlay();
    _refreshUI();
    _updateGizmoVisibility();
    _refreshUndoButtons();
  }

  // ── End Undo/Redo ─────────────────────────────────────────────────────────

  // ── Loop Cut ─────────────────────────────────────────────────────────────
  // Applies a loop cut at the given factor (0..1) along the edge loop
  // containing seedEdgeIndex. Only operates on quad-paired triangle faces.
  // Returns true on success.
  function applyLoopCut(seedEdgeIndex, factor) {
    if(!_active || !_meshData) return false;
    factor = Math.max(0.001, Math.min(0.999, factor));

    const verts = _meshData.verts;
    const faces  = _meshData.faces;
    const edges  = _meshData.edges;

    // ── 1. Walk the edge loop from the seed edge ──────────────────────────
    // Strategy: for each edge in the loop, find the "opposite" edge in the
    // quad formed by the two triangles sharing this edge (if both faces are
    // triangles that together form a quad, i.e. share exactly two vertices).
    // We collect unique edge indices that form the ring.

    function getOppositeEdge(edgeIdx) {
      const e = edges[edgeIdx];
      if(!e) return -1;
      // The loop advances through the face OPPOSITE the shared edge.
      // For a triangle pair (two tris forming a quad), the "opposite" edge
      // is the edge that doesn't touch either vertex of the current edge AND
      // that is shared by faces that continue the ring.
      // We iterate over both faces, and for each face find the edge not
      // touching e.a or e.b.
      let result = -1;
      for(const fi of e.faces) {
        const f = faces[fi];
        if(!f) continue;
        // Find the vertex in this face not in the current edge
        const oppositeVert = f.verts.find(v => v !== e.a && v !== e.b);
        if(oppositeVert === undefined) continue;
        // The opposite edge of this face relative to our current edge
        // is the edge connecting the two verts that are NOT on our edge.
        // But since we have triangles, the "through-face" edge connects
        // oppositeVert to... we need the quad partner face.
        // Instead: find the OTHER face sharing this edge face.
        // The continuation edge in the loop is the one in the SAME face
        // that is parallel — meaning: connects two verts both NOT on our edge.
        // For a pure triangle that's the edge opposite the shared edge vertex:
        // we want the edge that doesn't share e.a or e.b.
        for(const ei of f.edges) {
          if(ei === edgeIdx) continue;
          const ce = edges[ei];
          if(!ce) continue;
          if(ce.a !== e.a && ce.a !== e.b && ce.b !== e.a && ce.b !== e.b) {
            result = ei;
            break;
          }
        }
        if(result !== -1) break;
      }
      return result;
    }

    // Walk loop: start from seedEdgeIndex, follow opposite edges
    const loopEdges = [];
    const visited = new Set();
    let cur = seedEdgeIndex;
    while(cur !== -1 && !visited.has(cur)) {
      visited.add(cur);
      loopEdges.push(cur);
      cur = getOppositeEdge(cur);
      if(cur === seedEdgeIndex) break; // closed loop
    }

    if(loopEdges.length === 0) return false;

    // ── 2. For each loop edge, compute the new midpoint vertex ───────────
    // Map from edge index → new vert index (to avoid duplicates at shared verts)
    const edgeToNewVert = new Map();
    loopEdges.forEach(ei => {
      const e = edges[ei];
      const va = verts[e.a], vb = verts[e.b];
      const nx = va.x + (vb.x - va.x) * factor;
      const ny = va.y + (vb.y - va.y) * factor;
      const nz = va.z + (vb.z - va.z) * factor;
      const vi = verts.length;
      verts.push({x:nx, y:ny, z:nz});
      edgeToNewVert.set(ei, vi);
    });

    // ── 3. Split each face that contains a loop edge ─────────────────────
    // For each loop edge, it touches 1 or 2 faces. Each face gets split
    // by the new midpoint vertex: a triangle is split into two triangles.
    // If two loop edges share the same face (forming a quad pair) we split
    // the quad into 3 triangles instead.
    const newFaces = [];   // replacement faces (added, not mutated in-place)
    const removedFaceSet = new Set();

    const faceProcessed = new Set();

    loopEdges.forEach(ei => {
      const e = edges[ei];
      const newVi = edgeToNewVert.get(ei);

      e.faces.forEach(fi => {
        if(faceProcessed.has(fi)) return;
        faceProcessed.add(fi);
        removedFaceSet.add(fi);

        const f = faces[fi];
        if(!f) return;
        const [v0, v1, v2] = f.verts;

        // Does this face contain ONE loop edge or TWO?
        const loopEdgesInFace = f.edges.filter(fei => edgeToNewVert.has(fei));

        if(loopEdgesInFace.length === 1) {
          // ── Simple split: one new vert splits triangle into 2 ──────────
          const cutEi = loopEdgesInFace[0];
          const cutE  = edges[cutEi];
          const nv    = edgeToNewVert.get(cutEi);

          // Find the vertex NOT on the cut edge
          const apex = f.verts.find(v => v !== cutE.a && v !== cutE.b);
          if(apex === undefined) return;

          // Two new triangles: (cutE.a, nv, apex) and (nv, cutE.b, apex)
          // Determine winding: original was (v0,v1,v2) — check which winding
          // maintains the same normal orientation.
          function _pushTri(a,b,c){
            const va=verts[a],vb=verts[b],vc=verts[c];
            const e1x=vb.x-va.x,e1y=vb.y-va.y,e1z=vb.z-va.z;
            const e2x=vc.x-va.x,e2y=vc.y-va.y,e2z=vc.z-va.z;
            const nx=e1y*e2z-e1z*e2y,ny=e1z*e2x-e1x*e2z,nz=e1x*e2y-e1y*e2x;
            const nl=Math.sqrt(nx*nx+ny*ny+nz*nz)||1;
            newFaces.push({
              verts:[a,b,c], edges:[],
              normal:{x:nx/nl,y:ny/nl,z:nz/nl},
              center:{x:(va.x+vb.x+vc.x)/3,y:(va.y+vb.y+vc.y)/3,z:(va.z+vb.z+vc.z)/3}
            });
          }

          // Preserve original winding direction
          // Original edge direction in face: find which way (cutE.a→cutE.b) appears
          let aIdx=-1, bIdx=-1;
          for(let i=0;i<3;i++){
            if(f.verts[i]===cutE.a) aIdx=i;
            if(f.verts[i]===cutE.b) bIdx=i;
          }
          const forward = (aIdx+1)%3 === bIdx;
          if(forward){
            _pushTri(cutE.a, nv, apex);
            _pushTri(nv, cutE.b, apex);
          } else {
            _pushTri(cutE.b, nv, apex);
            _pushTri(nv, cutE.a, apex);
          }

        } else if(loopEdgesInFace.length >= 2) {
          // ── Two loop edges in same face: split into 3 tris ───────────────
          // This happens when two consecutive loop edges share a face.
          const ei0 = loopEdgesInFace[0], ei1 = loopEdgesInFace[1];
          const nv0 = edgeToNewVert.get(ei0), nv1 = edgeToNewVert.get(ei1);
          const e0  = edges[ei0], e1 = edges[ei1];

          // Find the shared vertex between the two cut edges (the "pivot")
          const sharedVert = [e0.a,e0.b].find(v => v===e1.a || v===e1.b);
          if(sharedVert === undefined){
            // Fallback: just split on first edge
            const nv = edgeToNewVert.get(ei0);
            const cutE = e0;
            const apex = f.verts.find(v => v !== cutE.a && v !== cutE.b);
            if(apex === undefined) return;
            function _pt(a,b,c){
              const va=verts[a],vb=verts[b],vc=verts[c];
              const e1x=vb.x-va.x,e1y=vb.y-va.y,e1z=vb.z-va.z;
              const e2x=vc.x-va.x,e2y=vc.y-va.y,e2z=vc.z-va.z;
              const nx=e1y*e2z-e1z*e2y,ny=e1z*e2x-e1x*e2z,nz=e1x*e2y-e1y*e2x;
              const nl=Math.sqrt(nx*nx+ny*ny+nz*nz)||1;
              newFaces.push({verts:[a,b,c],edges:[],normal:{x:nx/nl,y:ny/nl,z:nz/nl},center:{x:(va.x+vb.x+vc.x)/3,y:(va.y+vb.y+vc.y)/3,z:(va.z+vb.z+vc.z)/3}});
            }
            _pt(cutE.a, nv, apex); _pt(nv, cutE.b, apex);
            return;
          }

          // The apex is the vert NOT on either cut edge
          const apex = f.verts.find(v => v !== e0.a && v !== e0.b && v !== e1.a && v !== e1.b);

          function _pushTri3(a,b,c){
            const va=verts[a],vb=verts[b],vc=verts[c];
            const e1x=vb.x-va.x,e1y=vb.y-va.y,e1z=vb.z-va.z;
            const e2x=vc.x-va.x,e2y=vc.y-va.y,e2z=vc.z-va.z;
            const nx=e1y*e2z-e1z*e2y,ny=e1z*e2x-e1x*e2z,nz=e1x*e2y-e1y*e2x;
            const nl=Math.sqrt(nx*nx+ny*ny+nz*nz)||1;
            newFaces.push({verts:[a,b,c],edges:[],normal:{x:nx/nl,y:ny/nl,z:nz/nl},center:{x:(va.x+vb.x+vc.x)/3,y:(va.y+vb.y+vc.y)/3,z:(va.z+vb.z+vc.z)/3}});
          }

          // Determine "other" end of each cut edge (away from shared vert)
          const otherV0 = e0.a === sharedVert ? e0.b : e0.a;
          const otherV1 = e1.a === sharedVert ? e1.b : e1.a;

          if(apex !== undefined){
            // Triangle: sharedVert corner → nv0 --- nv1
            // 3 tris: (sharedVert, nv0, nv1), (nv0, otherV0, apex||nv1), (nv1, nv0, apex||otherV1)
            // Simpler: (pivot→nv0→nv1), (nv0→otherV0→apex), (nv1→apex→otherV1) — check winding
            // Use face normal to orient
            const fn = f.normal;
            function _windOk(a,b,c){
              const va=verts[a],vb=verts[b],vc=verts[c];
              const e1x=vb.x-va.x,e1y=vb.y-va.y,e1z=vb.z-va.z;
              const e2x=vc.x-va.x,e2y=vc.y-va.y,e2z=vc.z-va.z;
              const nx=e1y*e2z-e1z*e2y,ny=e1z*e2x-e1x*e2z,nz=e1x*e2y-e1y*e2x;
              return nx*fn.x+ny*fn.y+nz*fn.z > 0;
            }
            if(_windOk(sharedVert,nv0,nv1))  _pushTri3(sharedVert,nv0,nv1);
            else                              _pushTri3(sharedVert,nv1,nv0);
            if(_windOk(nv0,otherV0,apex))     _pushTri3(nv0,otherV0,apex);
            else                              _pushTri3(nv0,apex,otherV0);
            if(_windOk(nv1,apex,otherV1))     _pushTri3(nv1,apex,otherV1);
            else                              _pushTri3(nv1,otherV1,apex);
          } else {
            // No distinct apex (degenerate) — just one strip
            if(_windOk2(sharedVert,nv0,nv1)){_pushTri3(sharedVert,nv0,nv1);}
            else {_pushTri3(sharedVert,nv1,nv0);}
            function _windOk2(a,b,c){
              const va=verts[a],vb=verts[b],vc=verts[c];
              const e1x=vb.x-va.x,e1y=vb.y-va.y,e1z=vb.z-va.z;
              const e2x=vc.x-va.x,e2y=vc.y-va.y,e2z=vc.z-va.z;
              const nx=e1y*e2z-e1z*e2y,ny=e1z*e2x-e1x*e2z,nz=e1x*e2y-e1y*e2x;
              const fn=f.normal;
              return nx*fn.x+ny*fn.y+nz*fn.z > 0;
            }
          }
        }
      });
    });

    // ── 4. Rebuild faces array: keep untouched faces, add new ones ────────
    const finalFaces = [];
    faces.forEach((f, fi) => {
      if(!removedFaceSet.has(fi)) finalFaces.push(f);
    });
    newFaces.forEach(f => finalFaces.push(f));
    _meshData.faces = finalFaces;

    // ── 5. Rebuild full edge topology ─────────────────────────────────────
    const newEdgeMap = new Map();
    const newEdges   = [];
    function _ek(a,b){ return a<b?`${a}-${b}`:`${b}-${a}`; }
    function _goe(a,b){
      const k=_ek(a,b);
      if(!newEdgeMap.has(k)){ newEdgeMap.set(k,newEdges.length); newEdges.push({a,b,faces:[]}); }
      return newEdgeMap.get(k);
    }
    _meshData.faces.forEach((f,fi)=>{
      if(f.verts.length<3) return;
      const eA=_goe(f.verts[0],f.verts[1]); newEdges[eA].faces.push(fi);
      const eB=_goe(f.verts[1],f.verts[2]); newEdges[eB].faces.push(fi);
      const eC=_goe(f.verts[2],f.verts[0]); newEdges[eC].faces.push(fi);
      f.edges=[eA,eB,eC];
    });
    _meshData.edges = newEdges;

    // ── 6. Force DoubleSide and commit ────────────────────────────────────
    if(_mesh && _mesh.material){
      _mesh.material.side = THREE.DoubleSide;
      _mesh.material.needsUpdate = true;
    }
    _writebackGeometry('topology');

    // ── 7. Select the new loop edge verts so they're visible ─────────────
    _elemType = 'vert';
    _selected.clear();
    edgeToNewVert.forEach(vi => _selected.add(vi));
    document.getElementById('elem-vert').classList.add('active');
    document.getElementById('elem-edge').classList.remove('active');
    document.getElementById('elem-face').classList.remove('active');

    _rebuildOverlaysFull();
    _refreshOverlay();
    _refreshUI();
    _updateGizmoVisibility();
    return true;
  }

  // Compute the edge loop from a seed edge (for preview)
  function getLoopEdges(seedEdgeIndex) {
    if(!_active||!_meshData) return [];
    const edges = _meshData.edges;
    const faces  = _meshData.faces;

    function getOppositeEdge(edgeIdx) {
      const e = edges[edgeIdx];
      if(!e) return -1;
      let result = -1;
      for(const fi of e.faces) {
        const f = faces[fi];
        if(!f) continue;
        for(const ei of f.edges) {
          if(ei === edgeIdx) continue;
          const ce = edges[ei];
          if(!ce) continue;
          if(ce.a !== e.a && ce.a !== e.b && ce.b !== e.a && ce.b !== e.b) {
            result = ei; break;
          }
        }
        if(result !== -1) break;
      }
      return result;
    }

    const loopEdges = [];
    const visited = new Set();
    let cur = seedEdgeIndex;
    while(cur !== -1 && !visited.has(cur)) {
      visited.add(cur);
      loopEdges.push(cur);
      cur = getOppositeEdge(cur);
      if(cur === seedEdgeIndex) break;
    }
    return loopEdges;
  }

  // ── End Loop Cut ──────────────────────────────────────────────────────────

  return {
    init, enter, exit, isActive, getMesh,
    setElemType, selectAll, selectNone, selectInverse,
    toggleXray, syncMeshTransform, tickGizmo,
    setEditTransformMode, extrudeFaces, startInset, startBevel,
    applyLoopCut, getLoopEdges,
    pushUndo, applyHistoryState,
    getSelected:()=>_selected,
    getElemType:()=>_elemType,
    getMeshData:()=>_meshData,
    getCanvas:()=>_canvas,
    getCamera:()=>_camera,
    worldToScreen:(wx,wy,wz)=>_worldToScreen(wx,wy,wz),
    _multiSelectActive: false
  };
})();

// ══════════════════════════════════════════════════════
//  LoopCutSystem  — mobile-first rewrite
//
//  Touch workflow (3 steps):
//    1. TAP anywhere on the mesh surface
//       → raycasts the mesh, finds the hit face
//       → computes two candidate loops (H and V) from that face
//       → shows direction-picker in HUD (Horizontal / Vertical)
//    2. TAP a direction button (or auto-selects if only one loop exists)
//       → preview line appears at factor=0.5
//    3. DRAG left/right on the viewport to slide the factor
//       → Confirm commits, Cancel aborts
//
//  Desktop workflow (unchanged feel):
//    Mouse-move hovers edges, click locks the loop, drag repositions.
// ══════════════════════════════════════════════════════
