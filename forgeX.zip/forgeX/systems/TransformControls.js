'use strict';
const TransformControlsModule = (() => {
  let _currentMode='translate', _attached=false, _camera=null, _canvas=null, _scene=null;
  const _gizmoGroup=new THREE.Group();
  _gizmoGroup.name='__gizmo__'; _gizmoGroup.userData.nonSelectable=true; _gizmoGroup.renderOrder=999;

  let _dragging=false, _dragAxis=null, _hoveredAxis=null, _objRef=null;
  let _multiObjStarts = []; // [{obj, pos, rot, scale}] for multi-select drag
  let _objStart={pos:new THREE.Vector3(),rot:new THREE.Euler(),scale:new THREE.Vector3()};
  let _mouseScreenStart={x:0,y:0};
  let _dragStartWorld=new THREE.Vector3();
  let _hitPlane=new THREE.Plane();
  const _ray=new THREE.Raycaster();
  let _absorbedLastTouch=false, _activeTouchId=null;

  const COLORS={x:0xcc2222,y:0x1a9933,z:0x1a44cc};
  const COLORS_HOVER={x:0xff4444,y:0x33cc55,z:0x4477ff};
  const COLOR_ACTIVE=0xffcc00;
  const _axisMaterials={translate:{},rotate:{},scale:{}};

  function _makeMat(color){ return new THREE.MeshBasicMaterial({color,depthTest:false,depthWrite:false}); }
  function _makeLineMat(color){ return new THREE.LineBasicMaterial({color,depthTest:false,depthWrite:false,linewidth:4}); }
  function _makeHitMat(){ return new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:0.001,depthTest:false,depthWrite:false,side:THREE.DoubleSide}); }

  function _buildTranslateGizmo(){
    const g=new THREE.Group(); g.name='translate';
    const L=1.4,cH=0.32,cR=0.10,hitR=0.22;
    const ROT={x:{z:-Math.PI/2},y:{},z:{x:Math.PI/2}};
    ['x','y','z'].forEach(axis=>{
      const axVec=new THREE.Vector3(axis==='x'?1:0,axis==='y'?1:0,axis==='z'?1:0);
      const color=COLORS[axis];
      const lineGeo=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),axVec.clone().multiplyScalar(L)]);
      const lineMat=_makeLineMat(color); _axisMaterials.translate[axis]=[lineMat];
      const line=new THREE.Line(lineGeo,lineMat); line.renderOrder=999; line.userData={axis,gizmo:true};
      const coneMat=_makeMat(color); _axisMaterials.translate[axis].push(coneMat);
      const cone=new THREE.Mesh(new THREE.ConeGeometry(cR,cH,10),coneMat); cone.renderOrder=999; cone.userData={axis,gizmo:true};
      cone.position.copy(axVec.clone().multiplyScalar(L+cH*0.5));
      if(ROT[axis].z!==undefined) cone.rotation.z=ROT[axis].z;
      if(ROT[axis].x!==undefined) cone.rotation.x=ROT[axis].x;
      const hit=new THREE.Mesh(new THREE.CylinderGeometry(hitR,hitR,L+cH,8),_makeHitMat());
      hit.renderOrder=999; hit.userData={axis,gizmoHit:true,mode:'translate'};
      hit.position.copy(axVec.clone().multiplyScalar((L+cH)*0.5));
      if(ROT[axis].z!==undefined) hit.rotation.z=ROT[axis].z;
      if(ROT[axis].x!==undefined) hit.rotation.x=ROT[axis].x;
      g.add(line,cone,hit);
    });
    return g;
  }

  function _buildRotateGizmo(){
    const g=new THREE.Group(); g.name='rotate';
    const r=1.4,segs=80,hitTR=0.16;
    ['x','y','z'].forEach(axis=>{
      const color=COLORS[axis]; const pts=[];
      for(let i=0;i<=segs;i++){ const a=(i/segs)*Math.PI*2; if(axis==='x')pts.push(new THREE.Vector3(0,Math.cos(a)*r,Math.sin(a)*r)); else if(axis==='y')pts.push(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r)); else pts.push(new THREE.Vector3(Math.cos(a)*r,Math.sin(a)*r,0)); }
      const ringMat=_makeLineMat(color); _axisMaterials.rotate[axis]=[ringMat];
      const ring=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),ringMat); ring.renderOrder=999; ring.userData={axis,gizmo:true};
      const TORUS_ROT={x:{axis:'y',angle:Math.PI/2},y:{axis:'x',angle:Math.PI/2},z:null};
      const hit=new THREE.Mesh(new THREE.TorusGeometry(r,hitTR,8,48),_makeHitMat());
      hit.renderOrder=999; hit.userData={axis,gizmoHit:true,mode:'rotate'};
      const tr=TORUS_ROT[axis]; if(tr){ if(tr.axis==='y')hit.rotation.y=tr.angle; else hit.rotation.x=tr.angle; }
      g.add(ring,hit);
    });
    return g;
  }

  function _buildScaleGizmo(){
    const g=new THREE.Group(); g.name='scale';
    const L=1.4,boxS=0.20,hitR=0.22;
    const ROT={x:{z:-Math.PI/2},y:{},z:{x:Math.PI/2}};
    ['x','y','z'].forEach(axis=>{
      const axVec=new THREE.Vector3(axis==='x'?1:0,axis==='y'?1:0,axis==='z'?1:0);
      const color=COLORS[axis];
      const lineMat=_makeLineMat(color); _axisMaterials.scale[axis]=[lineMat];
      const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),axVec.clone().multiplyScalar(L)]),lineMat);
      line.renderOrder=999; line.userData={axis,gizmo:true};
      const boxMat=_makeMat(color); _axisMaterials.scale[axis].push(boxMat);
      const box=new THREE.Mesh(new THREE.BoxGeometry(boxS,boxS,boxS),boxMat);
      box.renderOrder=999; box.position.copy(axVec.clone().multiplyScalar(L+boxS*0.5)); box.userData={axis,gizmo:true};
      const hit=new THREE.Mesh(new THREE.CylinderGeometry(hitR,hitR,L+boxS,8),_makeHitMat());
      hit.renderOrder=999; hit.userData={axis,gizmoHit:true,mode:'scale'};
      hit.position.copy(axVec.clone().multiplyScalar((L+boxS)*0.5));
      if(ROT[axis].z!==undefined)hit.rotation.z=ROT[axis].z;
      if(ROT[axis].x!==undefined)hit.rotation.x=ROT[axis].x;
      g.add(line,box,hit);
    });
    return g;
  }

  let _translateG,_rotateG,_scaleG;

  function init(scene,camera,canvas){
    _scene=scene; _camera=camera; _canvas=canvas;
    _translateG=_buildTranslateGizmo(); _rotateG=_buildRotateGizmo(); _scaleG=_buildScaleGizmo();
    [_translateG,_rotateG,_scaleG].forEach(g=>{g.visible=false; _gizmoGroup.add(g);});
    // Ensure the gizmo group and ALL its children never cast or receive shadows
    _gizmoGroup.traverse(child => {
      child.castShadow    = false;
      child.receiveShadow = false;
    });
    scene.add(_gizmoGroup);
    _bindEvents();
    EventBus.on('selection:changed',obj=>{
      // Position gizmo at centroid of all selected mesh objects (not scene objects)
      const multiSel = SelectionSystem.getMultiSelected().filter(o => !o.userData.sceneObjectType);
      // Single scene object selected (camera or light)
      if (obj && obj.userData.sceneObjectType) {
        attachTo(obj);
        return;
      }
      if (multiSel.length === 0) { detach(); return; }
      if (multiSel.length === 1) {
        if (!obj || obj.userData.sceneObjectType) { detach(); return; }
        attachTo(obj);
      } else {
        // Multi: place gizmo at centroid, attach logically to active obj
        _objRef = obj;
        const centroid = new THREE.Vector3();
        multiSel.forEach(o => { o.updateMatrixWorld(true); const wp=new THREE.Vector3(); o.getWorldPosition(wp); centroid.add(wp); });
        centroid.divideScalar(multiSel.length);
        _gizmoGroup.position.copy(centroid);
        _attached = true; _updateVisibility(); _doUpdateScale();
      }
    });
    EventBus.on('editmode:changed',active=>{ if(active) detach(); });
  }

  function attachTo(obj){
    if(!obj) return;
    obj.updateMatrixWorld(true);
    const wp=new THREE.Vector3(); obj.getWorldPosition(wp);
    _gizmoGroup.position.copy(wp); _attached=true; _updateVisibility(); _doUpdateScale();
  }

  function detach(){ _attached=false; _gizmoGroup.visible=false; }

  function _updateVisibility(){
    const show=_attached&&!EditModeSystem.isActive();
    _gizmoGroup.visible=show;
    if(_translateG)_translateG.visible=_currentMode==='translate';
    if(_rotateG)_rotateG.visible=_currentMode==='rotate';
    if(_scaleG)_scaleG.visible=_currentMode==='scale';
  }

  function setMode(mode){ _currentMode=mode; _updateVisibility(); }

  function _doUpdateScale(){
    if(!_attached||!_camera) return;
    const dist=_camera.position.distanceTo(_gizmoGroup.position);
    const tanHalf=Math.tan(_camera.fov*(Math.PI/180)/2);
    const worldSize=dist*tanHalf*0.22;
    _gizmoGroup.scale.setScalar(Math.min(3.0,Math.max(0.4,worldSize)));
  }

  function syncToObject(obj){
    if(!obj||!_attached) return;
    obj.updateMatrixWorld(true);
    const wp=new THREE.Vector3(); obj.getWorldPosition(wp);
    _gizmoGroup.position.copy(wp); _doUpdateScale();
    if(!obj.userData.sceneObjectType) EditModeSystem.syncMeshTransform();
  }

  function _getNDC(clientX,clientY){
    const r=_canvas.getBoundingClientRect();
    return new THREE.Vector2(((clientX-r.left)/r.width)*2-1,-((clientY-r.top)/r.height)*2+1);
  }

  function _getGizmoHits(clientX,clientY,isTouch=false){
    if(!_gizmoGroup.visible) return [];
    _gizmoGroup.updateMatrixWorld(true);
    _ray.setFromCamera(_getNDC(clientX,clientY),_camera);
    _ray.params.Line=_ray.params.Line||{}; _ray.params.Line.threshold=isTouch?0.12:0.05;
    const hitProxies=[];
    _gizmoGroup.traverse(c=>{ if(c.isMesh&&c.userData.gizmoHit===true)hitProxies.push(c); });
    if(hitProxies.length===0) return [];
    const hits=_ray.intersectObjects(hitProxies,false);
    return hits.filter(h=>h.object.userData.mode===_currentMode||!h.object.userData.mode);
  }

  function _screenToWorldOnPlane(clientX,clientY){
    _ray.setFromCamera(_getNDC(clientX,clientY),_camera);
    const out=new THREE.Vector3();
    return _ray.ray.intersectPlane(_hitPlane,out)?out:null;
  }

  const _AXIS_VEC={x:new THREE.Vector3(1,0,0),y:new THREE.Vector3(0,1,0),z:new THREE.Vector3(0,0,1)};

  function _buildDragPlane(axisKey){
    const axVec=_AXIS_VEC[axisKey];
    const gizmoPos=_gizmoGroup.position.clone();
    const toCamera=_camera.position.clone().sub(gizmoPos).normalize();
    const dot=toCamera.dot(axVec);
    let normal=toCamera.clone().addScaledVector(axVec,-dot);
    if(normal.lengthSq()<1e-6){ normal=Math.abs(axVec.x)<0.9?new THREE.Vector3().crossVectors(axVec,new THREE.Vector3(1,0,0)):new THREE.Vector3().crossVectors(axVec,new THREE.Vector3(0,1,0)); }
    _hitPlane.setFromNormalAndCoplanarPoint(normal.normalize(),gizmoPos);
  }

  function _setHover(axis){
    if(_hoveredAxis===axis) return;
    if(_hoveredAxis) _setAxisColor(_hoveredAxis,COLORS[_hoveredAxis]);
    _hoveredAxis=axis;
    if(axis) _setAxisColor(axis,COLORS_HOVER[axis]);
  }

  function _setAxisColor(axis,color){
    const mats=_axisMaterials[_currentMode]&&_axisMaterials[_currentMode][axis];
    if(!mats) return; mats.forEach(m=>m.color.setHex(color));
  }

  function _startDrag(clientX,clientY,isTouch=false){
    if(!_gizmoGroup.visible) return false;
    const hits=_getGizmoHits(clientX,clientY,isTouch);
    if(!hits.length) return false;
    _objRef=SelectionSystem.getSelected(); if(!_objRef) return false;
    _dragging=true; _dragAxis=hits[0].object.userData.axis;
    _objStart.pos.copy(_objRef.position); _objStart.rot.copy(_objRef.rotation); _objStart.scale.copy(_objRef.scale);
    // Push undo for all scene objects (meshes, cameras, lights)
    ObjectUndoHistory.push(_objRef);
    // Signal drag start so HierarchySystem can snapshot the world matrix for child propagation
    _objRef.updateMatrixWorld(true);
    EventBus.emit('transform:dragStart', _objRef);

    // Record start state for all selected objects (multi-transform — mesh only)
    _multiObjStarts = [];
    const multiSel = SelectionSystem.getMultiSelected().filter(o => !o.userData.sceneObjectType && o !== _objRef);
    multiSel.forEach(obj => {
      _multiObjStarts.push({ obj, pos: obj.position.clone(), rot: obj.rotation.clone(), scale: obj.scale.clone() });
    });

    _mouseScreenStart={x:clientX,y:clientY};
    if(_currentMode==='translate'){ _buildDragPlane(_dragAxis); const startPt=_screenToWorldOnPlane(clientX,clientY); _dragStartWorld.copy(startPt||_gizmoGroup.position); }
    _setAxisColor(_dragAxis,COLOR_ACTIVE);
    const statusEl=document.getElementById('drag-status');
    if(statusEl){ statusEl.textContent=`${_currentMode.toUpperCase()} · ${_dragAxis.toUpperCase()}`; statusEl.classList.add('visible'); }
    return true;
  }

  function _moveDrag(clientX,clientY){
    if(!_dragging||!_objRef) return;
    const axVec=_AXIS_VEC[_dragAxis];

    // Helper to apply transform to one object using its stored start state
    function _applyToObj(obj, start) {
      if(_currentMode==='translate'){
        const pt=_screenToWorldOnPlane(clientX,clientY); if(!pt) return;
        const proj=pt.clone().sub(_dragStartWorld).dot(axVec);
        obj.position.copy(start.pos).addScaledVector(axVec,proj);
      } else if(_currentMode==='rotate'){
        const dx=clientX-_mouseScreenStart.x, dy=clientY-_mouseScreenStart.y;
        const gizmoPos=_gizmoGroup.position.clone();
        const pA=gizmoPos.clone().project(_camera), pB=gizmoPos.clone().add(axVec).project(_camera);
        const rect=_canvas.getBoundingClientRect();
        const sx=(pB.x-pA.x)*(rect.width*0.5), sy=(pA.y-pB.y)*(rect.height*0.5);
        const sLen=Math.sqrt(sx*sx+sy*sy);
        let angle;
        if(sLen<1.0){ angle=(dx-dy)*0.012; } else { const nx=sy/sLen, ny=-sx/sLen; angle=(dx*nx+dy*ny)*0.012; }
        const q=new THREE.Quaternion().setFromAxisAngle(axVec,angle);
        const startQ=new THREE.Quaternion().setFromEuler(start.rot);
        obj.quaternion.copy(q.multiply(startQ));
      } else if(_currentMode==='scale'){
        const dx=clientX-_mouseScreenStart.x, dy=clientY-_mouseScreenStart.y;
        const gizmoPos=_gizmoGroup.position.clone();
        const pA=gizmoPos.clone().project(_camera), pB=gizmoPos.clone().add(axVec).project(_camera);
        const rect=_canvas.getBoundingClientRect();
        const sx=(pB.x-pA.x)*(rect.width*0.5), sy=(pA.y-pB.y)*(rect.height*0.5);
        const sLen=Math.sqrt(sx*sx+sy*sy);
        let proj;
        if(sLen<1.0) proj=(Math.abs(dx)>Math.abs(dy)?dx:-dy); else proj=(dx*sx+dy*sy)/sLen;
        const sf=Math.max(0.01,1.0+proj/150);
        const sc=start.scale;
        if(_dragAxis==='x')obj.scale.set(sc.x*sf,sc.y,sc.z);
        else if(_dragAxis==='y')obj.scale.set(sc.x,sc.y*sf,sc.z);
        else obj.scale.set(sc.x,sc.y,sc.z*sf);
      }
      obj.updateMatrixWorld(true);
    }

    // Apply to primary
    _applyToObj(_objRef, _objStart);

    // Apply same delta to all other selected objects
    if (_multiObjStarts) {
      _multiObjStarts.forEach(({obj, pos, rot, scale}) => _applyToObj(obj, {pos, rot, scale}));
    }

    // Recompute gizmo centroid position
    const multiSel = SelectionSystem.getMultiSelected().filter(o => !o.userData.sceneObjectType);
    if (multiSel.length > 1) {
      const centroid = new THREE.Vector3();
      multiSel.forEach(o => { const wp=new THREE.Vector3(); o.getWorldPosition(wp); centroid.add(wp); });
      centroid.divideScalar(multiSel.length);
      _gizmoGroup.position.copy(centroid);
    } else {
      const wp=new THREE.Vector3(); _objRef.getWorldPosition(wp);
      _gizmoGroup.position.copy(wp);
    }

    if(!_objRef.userData.sceneObjectType) EditModeSystem.syncMeshTransform();
    EventBus.emit('transform:changed',_objRef);
  }

  function _endDrag(){
    if(!_dragging) return;
    if(_dragAxis) _setAxisColor(_dragAxis,COLORS[_dragAxis]);
    _dragging=false; _dragAxis=null; _objRef=null;
    const statusEl=document.getElementById('drag-status');
    if(statusEl) statusEl.classList.remove('visible');
    CameraManager.setGizmoCaptured(false);
  }

  function _bindEvents(){
    _canvas.addEventListener('mousedown',e=>{
      if(e.button!==0) return;
      if(_startDrag(e.clientX,e.clientY)){ e._gizmoConsumed=true; CameraManager.setGizmoCaptured(true); }
    },{capture:true});
    window.addEventListener('mousemove',e=>{
      if(_dragging){ _moveDrag(e.clientX,e.clientY); }
      else if(_gizmoGroup.visible){ const hits=_getGizmoHits(e.clientX,e.clientY); _setHover(hits.length>0?hits[0].object.userData.axis:null); }
    });
    window.addEventListener('mouseup',()=>{ if(_dragging)_endDrag(); });
    _canvas.addEventListener('touchstart',e=>{
      if(e.touches.length!==1) return;
      _absorbedLastTouch=false; const t=e.touches[0];
      if(_startDrag(t.clientX,t.clientY,true)){ _activeTouchId=t.identifier; _absorbedLastTouch=true; CameraManager.setGizmoCaptured(true); e.stopPropagation(); e.preventDefault(); }
    },{capture:true,passive:false});
    _canvas.addEventListener('touchmove',e=>{
      if(!_dragging) return;
      for(let i=0;i<e.changedTouches.length;i++){ const t=e.changedTouches[i]; if(t.identifier===_activeTouchId){ _moveDrag(t.clientX,t.clientY); e.stopPropagation(); e.preventDefault(); break; } }
    },{capture:true,passive:false});
    _canvas.addEventListener('touchend',e=>{
      if(!_dragging) return;
      for(let i=0;i<e.changedTouches.length;i++){ if(e.changedTouches[i].identifier===_activeTouchId){ _endDrag(); _activeTouchId=null; e.stopPropagation(); break; } }
    },{capture:true,passive:false});
    _canvas.addEventListener('touchcancel',()=>{ if(_dragging)_endDrag(); _activeTouchId=null; },{capture:true,passive:false});
  }

  function isDragging()         { return _dragging; }
  function didAbsorbLastTouch() { return _absorbedLastTouch; }
  function getMode()            { return _currentMode; }

  return { init, setMode, getMode, syncToObject, attachTo, detach, isDragging, didAbsorbLastTouch };
})();

// ══════════════════════════════════════════════════════
//  UISystem
// ══════════════════════════════════════════════════════
