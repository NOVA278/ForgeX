'use strict';
/**
 * SubdivisionSystem — Loop subdivision surface for ForgeX
 *
 * Applies 1–3 levels of Loop subdivision to a mesh non-destructively.
 * The original geometry is stored in userData and restored when subdivision
 * is set back to 0, so it is completely non-destructive.
 *
 * Algorithm: Loop subdivision (1987) — the standard for triangular meshes.
 * All geometry is first triangulated before subdivision is applied.
 */
const SubdivisionSystem = (() => {

  // ── Triangulate a BufferGeometry ──────────────────────────────────────────

  function _triangulate(geo) {
    // If already indexed, convert quads→tris; otherwise treat as triangle soup
    const pos  = geo.attributes.position;
    const norm = geo.attributes.normal;
    const uv   = geo.attributes.uv;
    const idx  = geo.index;

    const newPos   = [];
    const newNorm  = norm ? [] : null;
    const newUV    = uv   ? [] : null;

    function _pushVert(i) {
      newPos.push(pos.getX(i), pos.getY(i), pos.getZ(i));
      if (newNorm) newNorm.push(norm.getX(i), norm.getY(i), norm.getZ(i));
      if (newUV)   newUV.push(uv.getX(i), uv.getY(i));
    }

    if (idx) {
      const arr = idx.array;
      for (let i = 0; i < arr.length; i += 3) {
        _pushVert(arr[i]);
        _pushVert(arr[i+1]);
        _pushVert(arr[i+2]);
      }
    } else {
      for (let i = 0; i < pos.count; i++) _pushVert(i);
    }

    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(newPos),  3));
    if (newNorm) g.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(newNorm), 3));
    if (newUV)   g.setAttribute('uv',     new THREE.BufferAttribute(new Float32Array(newUV),  2));
    g.computeBoundingBox();
    g.computeBoundingSphere();
    return g;
  }

  // ── One pass of Loop subdivision ──────────────────────────────────────────

  function _loopSubdivideOnce(geo) {
    // Work with non-indexed triangle soup for simplicity
    const pos = geo.attributes.position;
    const cnt = pos.count; // must be multiple of 3

    // Edge map: key "i1_i2" (sorted) → midpoint index
    const edgeMap   = new Map();
    const newVerts  = []; // flat [x,y,z, x,y,z, …]

    // First, copy all original verts
    for (let i = 0; i < cnt; i++) {
      newVerts.push(pos.getX(i), pos.getY(i), pos.getZ(i));
    }

    function _edgeKey(a, b) { return a < b ? `${a}_${b}` : `${b}_${a}`; }

    function _midpoint(a, b) {
      const key = _edgeKey(a, b);
      if (edgeMap.has(key)) return edgeMap.get(key);
      const mx = (pos.getX(a) + pos.getX(b)) * 0.5;
      const my = (pos.getY(a) + pos.getY(b)) * 0.5;
      const mz = (pos.getZ(a) + pos.getZ(b)) * 0.5;
      const idx = newVerts.length / 3;
      newVerts.push(mx, my, mz);
      edgeMap.set(key, idx);
      return idx;
    }

    // For Loop subdivision, smooth original verts by their valence
    // Build vertex → neighbour set
    const neighbours = new Array(cnt).fill(null).map(() => new Set());
    const triCount = cnt / 3;
    for (let t = 0; t < triCount; t++) {
      const a = t * 3, b = t * 3 + 1, c = t * 3 + 2;
      neighbours[a].add(b); neighbours[a].add(c);
      neighbours[b].add(a); neighbours[b].add(c);
      neighbours[c].add(a); neighbours[c].add(b);
    }

    // Move original vertices by Loop weights
    function _beta(n) {
      if (n === 3) return 3/16;
      return 3 / (8 * n);
    }

    const smoothed = new Float32Array(cnt * 3);
    for (let i = 0; i < cnt; i++) {
      const nb = [...neighbours[i]];
      const n  = nb.length;
      const b  = _beta(n);
      let sx = pos.getX(i) * (1 - n * b);
      let sy = pos.getY(i) * (1 - n * b);
      let sz = pos.getZ(i) * (1 - n * b);
      nb.forEach(j => {
        sx += pos.getX(j) * b;
        sy += pos.getY(j) * b;
        sz += pos.getZ(j) * b;
      });
      smoothed[i * 3]     = sx;
      smoothed[i * 3 + 1] = sy;
      smoothed[i * 3 + 2] = sz;
    }
    // Apply smoothing to the copy we already pushed
    for (let i = 0; i < cnt; i++) {
      newVerts[i * 3]     = smoothed[i * 3];
      newVerts[i * 3 + 1] = smoothed[i * 3 + 1];
      newVerts[i * 3 + 2] = smoothed[i * 3 + 2];
    }

    // Build new triangles (4 per old triangle)
    const newIndices = [];
    for (let t = 0; t < triCount; t++) {
      const a = t * 3, b = t * 3 + 1, c = t * 3 + 2;
      const ab = _midpoint(a, b);
      const bc = _midpoint(b, c);
      const ca = _midpoint(c, a);
      // 4 sub-triangles
      newIndices.push(a, ab, ca);
      newIndices.push(ab, b, bc);
      newIndices.push(ca, bc, c);
      newIndices.push(ab, bc, ca);
    }

    const posArr = new Float32Array(newVerts);
    const idxArr = newIndices.length > 65535 ? new Uint32Array(newIndices) : new Uint16Array(newIndices);

    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(posArr, 3));
    g.setIndex(new THREE.BufferAttribute(idxArr, 1));
    g.computeVertexNormals();
    g.computeBoundingBox();
    g.computeBoundingSphere();
    return g;
  }

  // ── Public API ─────────────────────────────────────────────────────────────

  /**
   * Apply `levels` levels of subdivision to `mesh`.
   * level 0 restores the original geometry.
   * Caches original geometry in mesh.userData._subdivOrigGeo.
   */
  function applySubdivision(mesh, levels) {
    if (!mesh || !mesh.geometry) return;

    // Cache original
    if (!mesh.userData._subdivOrigGeo) {
      mesh.userData._subdivOrigGeo = mesh.geometry.clone();
    }

    if (levels === 0) {
      mesh.geometry.dispose();
      mesh.geometry = mesh.userData._subdivOrigGeo.clone();
      mesh.userData.subdivLevel = 0;
      return;
    }

    // Start from original each time
    let geo = _triangulate(mesh.userData._subdivOrigGeo.clone());

    for (let i = 0; i < levels; i++) {
      geo = _loopSubdivideOnce(geo);
    }

    mesh.geometry.dispose();
    mesh.geometry = geo;
    mesh.userData.subdivLevel = levels;
    mesh.geometry.computeVertexNormals();
  }

  function getLevel(mesh) {
    return (mesh && mesh.userData.subdivLevel) || 0;
  }

  function clearCache(mesh) {
    if (mesh && mesh.userData._subdivOrigGeo) {
      mesh.userData._subdivOrigGeo.dispose();
      delete mesh.userData._subdivOrigGeo;
    }
  }

  return { applySubdivision, getLevel, clearCache };
})();
