'use strict';
const LoopCutSystem = (() => {
  let _active       = false;
  let _step         = 'idle';   // 'idle' | 'pick' | 'direction' | 'drag'
  let _lockedEdge   = -1;
  let _factor       = 0.5;
  let _loopEdges    = [];
  let _loopEdgesH   = [];   // horizontal candidate
  let _loopEdgesV   = [];   // vertical candidate
  let _seedEdgeH    = -1;
  let _seedEdgeV    = -1;
  let _direction    = null; // 'h' | 'v'
  let _previewLines = null;
  let _canvas       = null;
  let _scene        = null;
  let _dragStartX   = 0;
  let _dragFactor   = 0.5;
  let _isDragging   = false;
  let _activeTouchId = null;
  let _handlers     = {};

  const _ray = new THREE.Raycaster();

  const _previewMat = new THREE.LineBasicMaterial({
    color: 0x50deb4, linewidth: 2, depthTest: false, transparent: true, opacity: 0.9
  });
  const _hoverMat = new THREE.LineBasicMaterial({
    color: 0x50deb4, linewidth: 1, depthTest: false, transparent: true, opacity: 0.4
  });

  // ── Preview geometry ──────────────────────────────────────────────────────

  function _buildPreviewLines(loopEdges, factor, mesh, meshData, mat) {
    if(!mesh || !meshData || loopEdges.length === 0) return null;
    const pts = [];
    loopEdges.forEach(ei => {
      const e = meshData.edges[ei];
      if(!e) return;
      const va = meshData.verts[e.a], vb = meshData.verts[e.b];
      pts.push(
        va.x + (vb.x - va.x) * factor,
        va.y + (vb.y - va.y) * factor,
        va.z + (vb.z - va.z) * factor
      );
    });
    if(pts.length >= 6) pts.push(pts[0], pts[1], pts[2]);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
    const line = new THREE.LineLoop(geo, mat);
    line.applyMatrix4(mesh.matrixWorld);
    line.userData.loopCutPreview = true;
    line.renderOrder = 998;
    return line;
  }

  function _destroyPreview() {
    if(_previewLines && _scene) {
      _scene.remove(_previewLines);
      if(_previewLines.geometry) _previewLines.geometry.dispose();
      _previewLines = null;
    }
  }

  function _updatePreview(mat) {
    _destroyPreview();
    if(!EditModeSystem.isActive() || _loopEdges.length === 0) return;
    const mesh     = EditModeSystem.getMesh();
    const meshData = EditModeSystem.getMeshData();
    if(!mesh || !meshData) return;
    _previewLines = _buildPreviewLines(_loopEdges, _factor, mesh, meshData, mat || _previewMat);
    if(_previewLines) _scene.add(_previewLines);
  }

  // ── HUD helpers ───────────────────────────────────────────────────────────

  function _updateHUDFactor() {
    const el = document.getElementById('loopcut-factor-val');
    if(el) el.textContent = _factor.toFixed(3);
  }

  function _showStep(step) {
    // step: 'pick' | 'drag'
    const pickEl = document.getElementById('loopcut-step-pick');
    const dragEl = document.getElementById('loopcut-step-drag');
    const confirmBtn = document.getElementById('loopcut-confirm');
    if(pickEl) pickEl.style.display = step === 'pick' ? '' : 'none';
    if(dragEl) dragEl.style.display = step === 'drag' ? '' : 'none';
    if(confirmBtn) confirmBtn.disabled = step !== 'drag';
  }

  function _highlightDirBtn(dir) {
    const hBtn = document.getElementById('loopcut-dir-h');
    const vBtn = document.getElementById('loopcut-dir-v');
    if(hBtn) hBtn.classList.toggle('selected', dir === 'h');
    if(vBtn) vBtn.classList.toggle('selected', dir === 'v');
  }

  // ── Loop geometry helpers ─────────────────────────────────────────────────

  // Get the full loop from a seed edge index (unchanged logic)
  function _getLoop(seedEdgeIndex) {
    if(!EditModeSystem.isActive()) return [];
    return EditModeSystem.getLoopEdges(seedEdgeIndex);
  }

  // Raycast the mesh at (clientX, clientY), return the hit face index or -1
  function _raycastFace(clientX, clientY) {
    const mesh   = EditModeSystem.getMesh();
    const canvas = EditModeSystem.getCanvas();
    const camera = EditModeSystem.getCamera();
    if(!mesh || !canvas || !camera) return { faceIndex: -1, point: null };
    const r   = canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(
      ((clientX - r.left) / r.width)  * 2 - 1,
     -((clientY - r.top)  / r.height) * 2 + 1
    );
    _ray.setFromCamera(ndc, camera);
    const hits = _ray.intersectObject(mesh, false);
    if(!hits.length) return { faceIndex: -1, point: null };
    return { faceIndex: hits[0].faceIndex, point: hits[0].point };
  }

  // Given a THREE face index (triangulated), find the corresponding meshData face
  // and return the two "opposite" edge candidates (H and V) from that face.
  function _candidateEdgesFromFace(triFaceIndex) {
    const meshData = EditModeSystem.getMeshData();
    if(!meshData) return { edgeH: -1, edgeV: -1 };

    // THREE buffers one triangle per face (since our faces are already triangles
    // after loop-cut rebuilds). Map tri index → meshData face.
    const mFace = meshData.faces[triFaceIndex];
    if(!mFace || !mFace.edges || mFace.edges.length < 2) {
      // Fallback: just use edge 0 and 1 of the tri face
      return { edgeH: mFace ? mFace.edges[0] : -1, edgeV: mFace ? (mFace.edges[1] || mFace.edges[0]) : -1 };
    }

    // Pick two distinct edges from this face as candidates for H and V directions.
    // We choose the one closest to horizontal (screen-space) as H, and the other as V.
    const camera = EditModeSystem.getCamera();
    const edges  = meshData.edges;

    let bestH = -1, bestV = -1, bestHScore = -1, bestVScore = -1;

    mFace.edges.forEach(ei => {
      const e = edges[ei];
      if(!e) return;
      const sa = EditModeSystem.worldToScreen(meshData.verts[e.a].x, meshData.verts[e.a].y, meshData.verts[e.a].z);
      const sb = EditModeSystem.worldToScreen(meshData.verts[e.b].x, meshData.verts[e.b].y, meshData.verts[e.b].z);
      const dx = Math.abs(sb.x - sa.x), dy = Math.abs(sb.y - sa.y);
      const len = Math.hypot(dx, dy);
      if(len < 1) return;
      const hScore = dx / len; // closer to 1 = more horizontal
      const vScore = dy / len; // closer to 1 = more vertical
      if(hScore > bestHScore) { bestHScore = hScore; bestH = ei; }
      if(vScore > bestVScore) { bestVScore = vScore; bestV = ei; }
    });

    return { edgeH: bestH, edgeV: bestV };
  }

  // ── Main state machine ────────────────────────────────────────────────────

  function start() {
    if(_active) return;
    if(!EditModeSystem.isActive()) return;
    _active     = true;
    _step       = 'pick';
    _lockedEdge = -1;
    _factor     = 0.5;
    _loopEdges  = [];
    _direction  = null;
    _isDragging = false;
    CameraManager.setGizmoCaptured(true);

    const overlay = document.getElementById('loopcut-overlay');
    if(overlay) overlay.classList.add('active');
    _showStep('pick');
    _highlightDirBtn(null);
    _updateHUDFactor();
    _bindInput();

    const btn = document.getElementById('btn-loopcut');
    if(btn) btn.classList.add('active');
  }

  function cancel() {
    if(!_active) return;
    _destroyPreview();
    _active     = false;
    _step       = 'idle';
    _lockedEdge = -1;
    _loopEdges  = [];
    _isDragging = false;
    CameraManager.setGizmoCaptured(false);
    const overlay = document.getElementById('loopcut-overlay');
    if(overlay) overlay.classList.remove('active');
    _unbindInput();
    const btn = document.getElementById('btn-loopcut');
    if(btn) btn.classList.remove('active');
  }

  function confirm() {
    if(!_active || _step !== 'drag') return;
    if(_lockedEdge < 0 || _loopEdges.length === 0) { cancel(); return; }
    EditModeSystem.pushUndo();
    EditModeSystem.applyLoopCut(_lockedEdge, _factor);
    _destroyPreview();
    _active     = false;
    _step       = 'idle';
    _lockedEdge = -1;
    _loopEdges  = [];
    _isDragging = false;
    CameraManager.setGizmoCaptured(false);
    const overlay = document.getElementById('loopcut-overlay');
    if(overlay) overlay.classList.remove('active');
    _unbindInput();
    const btn = document.getElementById('btn-loopcut');
    if(btn) btn.classList.remove('active');
  }

  // Called when user taps the mesh surface (step 1 → step 2)
  function _onMeshTap(clientX, clientY) {
    const { faceIndex } = _raycastFace(clientX, clientY);
    if(faceIndex < 0) return; // missed the mesh

    const { edgeH, edgeV } = _candidateEdgesFromFace(faceIndex);

    _seedEdgeH   = edgeH >= 0 ? edgeH : -1;
    _seedEdgeV   = (edgeV >= 0 && edgeV !== edgeH) ? edgeV : (edgeH >= 0 ? edgeH : -1);
    _loopEdgesH  = _seedEdgeH >= 0 ? _getLoop(_seedEdgeH) : [];
    _loopEdgesV  = _seedEdgeV >= 0 ? _getLoop(_seedEdgeV) : [];

    if(_loopEdgesH.length === 0 && _loopEdgesV.length === 0) return;

    // If only one direction is available, auto-select it
    if(_loopEdgesH.length === 0) { _selectDirection('v'); return; }
    if(_loopEdgesV.length === 0) { _selectDirection('h'); return; }
    if(_seedEdgeH === _seedEdgeV)  { _selectDirection('h'); return; }

    // Show direction picker — preview both loops dimly
    _loopEdges = _loopEdgesH;
    _updatePreview(_hoverMat);
    _highlightDirBtn('h');
    // (don't advance to drag yet — wait for user to tap a direction button)
  }

  function _selectDirection(dir) {
    _direction  = dir;
    _lockedEdge = dir === 'h' ? _seedEdgeH : _seedEdgeV;
    _loopEdges  = dir === 'h' ? _loopEdgesH : _loopEdgesV;
    _factor     = 0.5;
    _step       = 'drag';
    _highlightDirBtn(dir);
    _updatePreview(_previewMat);
    _updateHUDFactor();
    _showStep('drag');
  }

  function _switchDirection() {
    if(!_active || _step !== 'drag') return;
    const newDir = _direction === 'h' ? 'v' : 'h';
    const newEdge = newDir === 'h' ? _seedEdgeH : _seedEdgeV;
    const newLoop = newDir === 'h' ? _loopEdgesH : _loopEdgesV;
    if(newLoop.length === 0) return;
    _direction  = newDir;
    _lockedEdge = newEdge;
    _loopEdges  = newLoop;
    _highlightDirBtn(_direction);
    _updatePreview(_previewMat);
  }

  // ── Mouse hover (desktop only) ────────────────────────────────────────────

  function _getEdgeUnderPointer(clientX, clientY) {
    const meshData = EditModeSystem.getMeshData();
    const mesh     = EditModeSystem.getMesh();
    if(!meshData || !mesh) return -1;
    const THRESH = window.devicePixelRatio > 1.5 ? 22 : 18;
    let best = -1, bestDist = THRESH;
    meshData.edges.forEach((e, i) => {
      const va = meshData.verts[e.a], vb = meshData.verts[e.b];
      const sa = EditModeSystem.worldToScreen(va.x, va.y, va.z);
      const sb = EditModeSystem.worldToScreen(vb.x, vb.y, vb.z);
      if(sa.vz > 1 || sb.vz > 1) return;
      const d = _ptSegDist(clientX, clientY, sa.x, sa.y, sb.x, sb.y);
      if(d < bestDist) { bestDist = d; best = i; }
    });
    return best;
  }

  function _ptSegDist(px,py,ax,ay,bx,by){
    const dx=bx-ax,dy=by-ay,lenSq=dx*dx+dy*dy;
    if(lenSq===0) return Math.hypot(px-ax,py-ay);
    const t=Math.max(0,Math.min(1,((px-ax)*dx+(py-ay)*dy)/lenSq));
    return Math.hypot(px-(ax+t*dx),py-(ay+t*dy));
  }

  function _factorFromDrag(clientX, isTouch) {
    const dx = clientX - _dragStartX;
    const divisor = isTouch ? 110 : 200;
    return Math.max(0.001, Math.min(0.999, _dragFactor + dx / divisor));
  }

  // ── Input binding ─────────────────────────────────────────────────────────

  function _bindInput() {
    const canvas = EditModeSystem.getCanvas();
    _canvas = canvas;

    // ── Mouse (desktop) ──────────────────────────────────────────────────
    let _mouseHoveredEdge = -1;

    const onMouseMove = (e) => {
      if(!_active) return;
      if(_step === 'drag' && (e.buttons === 1 || _isDragging)) {
        _factor = _factorFromDrag(e.clientX, false);
        _updatePreview(_previewMat);
        _updateHUDFactor();
        return;
      }
      if(_step === 'pick') {
        // Desktop hover: show loop preview as mouse scans edges
        const ei = _getEdgeUnderPointer(e.clientX, e.clientY);
        if(ei !== _mouseHoveredEdge) {
          _mouseHoveredEdge = ei;
          if(ei >= 0) {
            _loopEdges = _getLoop(ei);
            _updatePreview(_hoverMat);
          } else {
            _loopEdges = [];
            _destroyPreview();
          }
        }
      }
    };

    const onMouseDown = (e) => {
      if(!_active || e.button !== 0) return;
      e.stopPropagation();
      if(_step === 'drag') {
        _isDragging = true;
        _dragStartX = e.clientX;
        _dragFactor = _factor;
        return;
      }
      if(_step === 'pick') {
        if(_mouseHoveredEdge >= 0) {
          // Desktop: clicking a hovered edge locks it directly (skip direction picker)
          _seedEdgeH  = _mouseHoveredEdge;
          _seedEdgeV  = _mouseHoveredEdge;
          _loopEdgesH = _getLoop(_mouseHoveredEdge);
          _loopEdgesV = _loopEdgesH;
          _selectDirection('h');
        } else {
          // Desktop: tap on mesh surface — same as mobile
          _onMeshTap(e.clientX, e.clientY);
        }
      }
    };

    const onMouseUp = (e) => {
      if(!_active) return;
      _isDragging = false;
    };

    // ── Touch (mobile) ───────────────────────────────────────────────────
    const onTouchStart = (e) => {
      if(!_active) return;
      e.stopPropagation();
      e.preventDefault();
      if(e.touches.length !== 1) return;
      const t = e.touches[0];
      _activeTouchId = t.identifier;

      if(_step === 'drag') {
        _isDragging = true;
        _dragStartX = t.clientX;
        _dragFactor = _factor;
        return;
      }
      if(_step === 'pick') {
        _onMeshTap(t.clientX, t.clientY);
      }
    };

    const onTouchMove = (e) => {
      if(!_active) return;
      e.stopPropagation();
      e.preventDefault();
      for(let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if(t.identifier !== _activeTouchId) continue;
        if(_step === 'drag' && _isDragging) {
          _factor = _factorFromDrag(t.clientX, true);
          _updatePreview(_previewMat);
          _updateHUDFactor();
        }
        break;
      }
    };

    const onTouchEnd = (e) => {
      if(!_active) return;
      e.stopPropagation();
      e.preventDefault();
      for(let i = 0; i < e.changedTouches.length; i++) {
        if(e.changedTouches[i].identifier === _activeTouchId) {
          _isDragging    = false;
          _activeTouchId = null;
          break;
        }
      }
    };

    const onKey = (e) => {
      if(!_active) return;
      if(e.key === 'Escape') { e.preventDefault(); cancel(); return; }
      if(e.key === 'Enter' || e.key === 'Return') { e.preventDefault(); confirm(); return; }
      if(e.key === 'h' || e.key === 'H') { _selectDirection('h'); return; }
      if(e.key === 'v' || e.key === 'V') { _selectDirection('v'); return; }
    };

    _handlers = { onMouseMove, onMouseDown, onMouseUp, onTouchStart, onTouchMove, onTouchEnd, onKey };
    window.addEventListener('mousemove',  onMouseMove);
    canvas.addEventListener('mousedown',  onMouseDown, { capture: true });
    window.addEventListener('mouseup',    onMouseUp);
    canvas.addEventListener('touchstart', onTouchStart, { capture: true, passive: false });
    canvas.addEventListener('touchmove',  onTouchMove,  { capture: true, passive: false });
    canvas.addEventListener('touchend',   onTouchEnd,   { capture: true, passive: false });
    window.addEventListener('keydown',    onKey,        { capture: true });
  }

  function _unbindInput() {
    const canvas = _canvas;
    if(!canvas) return;
    const h = _handlers;
    window.removeEventListener('mousemove',  h.onMouseMove);
    canvas.removeEventListener('mousedown',  h.onMouseDown, { capture: true });
    window.removeEventListener('mouseup',    h.onMouseUp);
    canvas.removeEventListener('touchstart', h.onTouchStart, { capture: true });
    canvas.removeEventListener('touchmove',  h.onTouchMove,  { capture: true });
    canvas.removeEventListener('touchend',   h.onTouchEnd,   { capture: true });
    window.removeEventListener('keydown',    h.onKey,        { capture: true });
    _handlers = {};
  }

  function init(scene) {
    _scene = scene;
    const confirmBtn   = document.getElementById('loopcut-confirm');
    const cancelBtn    = document.getElementById('loopcut-cancel');
    const dirHBtn      = document.getElementById('loopcut-dir-h');
    const dirVBtn      = document.getElementById('loopcut-dir-v');
    const switchDirBtn = document.getElementById('loopcut-switch-dir');

    if(confirmBtn)   confirmBtn.addEventListener('click',   confirm);
    if(cancelBtn)    cancelBtn.addEventListener('click',    cancel);
    if(dirHBtn)      dirHBtn.addEventListener('click',      () => { if(_active) _selectDirection('h'); });
    if(dirVBtn)      dirVBtn.addEventListener('click',      () => { if(_active) _selectDirection('v'); });
    if(switchDirBtn) switchDirBtn.addEventListener('click', () => { if(_active) _switchDirection(); });
  }

  function isActive() { return _active; }

  return { init, start, cancel, confirm, isActive };
})();

// ══════════════════════════════════════════════════════
//  SelectionSystem
// ══════════════════════════════════════════════════════
