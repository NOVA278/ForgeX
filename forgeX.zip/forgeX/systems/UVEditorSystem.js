'use strict';
/**
 * UVEditorSystem — dedicated UV unwrap editor panel for ForgeX
 *
 * Opens a modal overlay with a 2D UV canvas.
 * Supports:
 *  - Displaying UV islands of the selected mesh
 *  - Box projection unwrap
 *  - Spherical projection unwrap
 *  - Planar projection (XY, XZ, YZ)
 *  - Reset to default box UVs
 *  - Apply: writes back to geometry UV attribute
 */
const UVEditorSystem = (() => {

  let _canvas  = null;
  let _ctx     = null;
  let _modal   = null;
  let _mesh    = null;
  let _uvs     = [];   // working copy [[u,v], …] indexed by vertex

  const CANVAS_SIZE = 512;

  // ── Bootstrap UI ──────────────────────────────────────────────────────────

  function _buildModal() {
    if (_modal) return;

    _modal = document.createElement('div');
    _modal.id = 'uv-editor-modal';
    _modal.innerHTML = `
      <div class="uv-editor-inner">
        <div class="uv-editor-header">
          <span class="uv-editor-title">
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <rect x="1" y="1" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.2"/>
              <path d="M1 5h10M5 1v10" stroke="currentColor" stroke-width="0.9" stroke-dasharray="2 1"/>
            </svg>
            UV Editor
          </span>
          <span class="uv-editor-mesh-name" id="uv-mesh-name">—</span>
          <button class="uv-editor-close" id="uv-editor-close">✕</button>
        </div>
        <div class="uv-editor-toolbar">
          <span class="uv-tb-label">Projection:</span>
          <button class="uv-tb-btn active" id="uv-proj-box">Box</button>
          <button class="uv-tb-btn" id="uv-proj-sphere">Sphere</button>
          <button class="uv-tb-btn" id="uv-proj-xy">Planar XY</button>
          <button class="uv-tb-btn" id="uv-proj-xz">Planar XZ</button>
          <button class="uv-tb-btn" id="uv-proj-yz">Planar YZ</button>
          <div class="uv-tb-sep"></div>
          <button class="uv-tb-btn" id="uv-reset">Reset</button>
          <button class="uv-tb-btn uv-apply-btn" id="uv-apply">Apply</button>
        </div>
        <div class="uv-editor-body">
          <canvas id="uv-canvas" width="${CANVAS_SIZE}" height="${CANVAS_SIZE}"></canvas>
          <div class="uv-editor-stats" id="uv-stats"></div>
        </div>
        <div class="uv-editor-footer">
          <span class="uv-footer-hint">UV islands are shown in the 0–1 space. Apply writes UVs back to mesh geometry.</span>
        </div>
      </div>
    `;
    document.body.appendChild(_modal);

    _canvas = document.getElementById('uv-canvas');
    _ctx    = _canvas.getContext('2d');

    // Wire buttons
    document.getElementById('uv-editor-close').addEventListener('click', close);
    document.getElementById('uv-proj-box').addEventListener('click',    () => { _unwrap('box');    _activateBtn('uv-proj-box');    });
    document.getElementById('uv-proj-sphere').addEventListener('click', () => { _unwrap('sphere'); _activateBtn('uv-proj-sphere'); });
    document.getElementById('uv-proj-xy').addEventListener('click',     () => { _unwrap('xy');     _activateBtn('uv-proj-xy');     });
    document.getElementById('uv-proj-xz').addEventListener('click',     () => { _unwrap('xz');     _activateBtn('uv-proj-xz');     });
    document.getElementById('uv-proj-yz').addEventListener('click',     () => { _unwrap('yz');     _activateBtn('uv-proj-yz');     });
    document.getElementById('uv-reset').addEventListener('click',       _resetUVs);
    document.getElementById('uv-apply').addEventListener('click',       _applyUVs);

    // Close on backdrop click
    _modal.addEventListener('click', e => { if (e.target === _modal) close(); });
  }

  function _activateBtn(id) {
    document.querySelectorAll('.uv-tb-btn').forEach(b => b.classList.remove('active'));
    const btn = document.getElementById(id);
    if (btn) btn.classList.add('active');
  }

  // ── UV Generation ─────────────────────────────────────────────────────────

  function _getPositions() {
    if (!_mesh || !_mesh.geometry) return [];
    const pos = _mesh.geometry.attributes.position;
    const mw  = _mesh.matrixWorld;
    const pts = [];
    for (let i = 0; i < pos.count; i++) {
      const v = new THREE.Vector3(pos.getX(i), pos.getY(i), pos.getZ(i)).applyMatrix4(mw);
      pts.push(v);
    }
    return pts;
  }

  function _getBB(pts) {
    const bb = new THREE.Box3();
    pts.forEach(p => bb.expandByPoint(p));
    return bb;
  }

  function _unwrap(method) {
    if (!_mesh) return;
    const pts = _getPositions();
    const geo = _mesh.geometry;
    const count = pts.length;
    _uvs = new Array(count);

    const bb   = _getBB(pts);
    const size = new THREE.Vector3();
    bb.getSize(size);
    const sX = size.x || 1, sY = size.y || 1, sZ = size.z || 1;
    const norm = geo.attributes.normal;

    if (method === 'box') {
      for (let i = 0; i < count; i++) {
        const p = pts[i];
        let nx = 0, ny = 1, nz = 0;
        if (norm) {
          nx = Math.abs(norm.getX(i));
          ny = Math.abs(norm.getY(i));
          nz = Math.abs(norm.getZ(i));
        }
        let u, v;
        if (nx >= ny && nx >= nz) {
          u = (p.z - bb.min.z) / sZ;
          v = (p.y - bb.min.y) / sY;
        } else if (ny >= nx && ny >= nz) {
          u = (p.x - bb.min.x) / sX;
          v = (p.z - bb.min.z) / sZ;
        } else {
          u = (p.x - bb.min.x) / sX;
          v = (p.y - bb.min.y) / sY;
        }
        _uvs[i] = [Math.max(0, Math.min(1, u)), Math.max(0, Math.min(1, v))];
      }
    } else if (method === 'sphere') {
      const center = new THREE.Vector3();
      bb.getCenter(center);
      for (let i = 0; i < count; i++) {
        const d = pts[i].clone().sub(center).normalize();
        const u = 0.5 + Math.atan2(d.z, d.x) / (2 * Math.PI);
        const v = 0.5 - Math.asin(Math.max(-1, Math.min(1, d.y))) / Math.PI;
        _uvs[i] = [u, v];
      }
    } else if (method === 'xy') {
      for (let i = 0; i < count; i++) {
        _uvs[i] = [
          (pts[i].x - bb.min.x) / sX,
          (pts[i].y - bb.min.y) / sY,
        ];
      }
    } else if (method === 'xz') {
      for (let i = 0; i < count; i++) {
        _uvs[i] = [
          (pts[i].x - bb.min.x) / sX,
          (pts[i].z - bb.min.z) / sZ,
        ];
      }
    } else if (method === 'yz') {
      for (let i = 0; i < count; i++) {
        _uvs[i] = [
          (pts[i].y - bb.min.y) / sY,
          (pts[i].z - bb.min.z) / sZ,
        ];
      }
    }

    _draw();
    document.getElementById('uv-stats').textContent =
      `${count} verts · ${method} projection`;
  }

  function _resetUVs() {
    if (!_mesh) return;
    const geo = _mesh.geometry;
    const uv  = geo.attributes.uv;
    if (!uv) { _unwrap('box'); return; }
    _uvs = [];
    for (let i = 0; i < uv.count; i++) {
      _uvs.push([uv.getX(i), uv.getY(i)]);
    }
    _activateBtn('uv-reset');
    _draw();
    document.getElementById('uv-stats').textContent =
      `${uv.count} verts · current UVs`;
  }

  // ── Drawing ───────────────────────────────────────────────────────────────

  function _draw() {
    const W = CANVAS_SIZE, H = CANVAS_SIZE;
    const ctx = _ctx;
    ctx.clearRect(0, 0, W, H);

    // Checkerboard background
    const cell = 32;
    for (let y = 0; y < H; y += cell) {
      for (let x = 0; x < W; x += cell) {
        ctx.fillStyle = ((x / cell + y / cell) % 2 === 0) ? '#1a1a1a' : '#212121';
        ctx.fillRect(x, y, cell, cell);
      }
    }

    // Grid
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.lineWidth   = 0.5;
    for (let i = 0; i <= 4; i++) {
      const t = i / 4 * W;
      ctx.beginPath(); ctx.moveTo(t, 0); ctx.lineTo(t, H); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, t); ctx.lineTo(W, t); ctx.stroke();
    }

    // Border
    ctx.strokeStyle = 'rgba(255,165,50,0.5)';
    ctx.lineWidth   = 1.5;
    ctx.strokeRect(0.75, 0.75, W - 1.5, H - 1.5);

    if (!_uvs.length || !_mesh) return;

    const geo = _mesh.geometry;
    const idx = geo.index;

    function _uvPx(uv) { return [uv[0] * W, (1 - uv[1]) * H]; }

    // Draw triangles
    ctx.strokeStyle = 'rgba(100, 200, 255, 0.6)';
    ctx.fillStyle   = 'rgba(80, 160, 255, 0.07)';
    ctx.lineWidth   = 0.8;

    function _drawTri(a, b, c) {
      if (!_uvs[a] || !_uvs[b] || !_uvs[c]) return;
      const [ax, ay] = _uvPx(_uvs[a]);
      const [bx, by] = _uvPx(_uvs[b]);
      const [cx, cy] = _uvPx(_uvs[c]);
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(bx, by);
      ctx.lineTo(cx, cy);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }

    if (idx) {
      const arr = idx.array;
      for (let i = 0; i < arr.length; i += 3) _drawTri(arr[i], arr[i+1], arr[i+2]);
    } else {
      for (let i = 0; i < _uvs.length; i += 3) _drawTri(i, i+1, i+2);
    }

    // Draw UV points
    ctx.fillStyle = 'rgba(255, 200, 80, 0.8)';
    _uvs.forEach(uv => {
      const [px, py] = _uvPx(uv);
      ctx.beginPath();
      ctx.arc(px, py, 1.5, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  // ── Apply ─────────────────────────────────────────────────────────────────

  function _applyUVs() {
    if (!_mesh || !_uvs.length) return;
    const geo = _mesh.geometry;
    const arr = new Float32Array(_uvs.length * 2);
    _uvs.forEach((uv, i) => { arr[i * 2] = uv[0]; arr[i * 2 + 1] = uv[1]; });
    geo.setAttribute('uv',  new THREE.BufferAttribute(arr, 2));
    geo.setAttribute('uv2', new THREE.BufferAttribute(arr.slice(), 2));

    // Notify material system
    if (_mesh.material && _mesh.material.map) _mesh.material.map.needsUpdate = true;

    const el = document.getElementById('uv-stats');
    if (el) { el.textContent = '✓ UVs applied to mesh'; el.style.color = '#7affa0'; }
    setTimeout(() => { if (el) { el.style.color = ''; _draw(); } }, 1500);
  }

  // ── Open / Close ──────────────────────────────────────────────────────────

  function open(mesh) {
    _buildModal();
    _mesh = mesh;
    _modal.classList.add('active');

    const nameEl = document.getElementById('uv-mesh-name');
    if (nameEl) nameEl.textContent = mesh ? mesh.name : '—';

    _resetUVs();
    _activateBtn('uv-reset');
  }

  function close() {
    if (_modal) _modal.classList.remove('active');
    _mesh = null;
    _uvs  = [];
  }

  function isOpen() { return _modal && _modal.classList.contains('active'); }

  return { open, close, isOpen };
})();
