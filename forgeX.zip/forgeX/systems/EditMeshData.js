'use strict';
const EditMeshData = (() => {

  // Build unique vertices, edges, faces from a BufferGeometry
  function buildFromGeometry(geo, mesh) {
    geo = geo.toNonIndexed ? geo : geo;
    // We work on the index geometry directly
    const posAttr = geo.attributes.position;
    const index = geo.index;

    // Build unique vertex positions (with tolerance-based deduplication)
    const TOLERANCE = 1e-5;
    const rawVerts = []; // {x,y,z}
    const vertexMap = new Map(); // string key -> vert index

    function keyFor(x,y,z) {
      return `${x.toFixed(5)},${y.toFixed(5)},${z.toFixed(5)}`;
    }

    // Get all positions
    const posCount = posAttr.count;
    const bufVerts = []; // index -> unique vert index
    for(let i=0; i<posCount; i++){
      const x=posAttr.getX(i), y=posAttr.getY(i), z=posAttr.getZ(i);
      const k=keyFor(x,y,z);
      if(vertexMap.has(k)){
        bufVerts.push(vertexMap.get(k));
      } else {
        const vi=rawVerts.length;
        rawVerts.push({x,y,z});
        vertexMap.set(k,vi);
        bufVerts.push(vi);
      }
    }

    // Build faces and edges
    const faces = [];
    const edgeMap = new Map(); // "a-b" -> edge index
    const edges = [];

    function getEdgeKey(a,b){ return a<b?`${a}-${b}`:`${b}-${a}`; }
    function getOrAddEdge(a,b){
      const k=getEdgeKey(a,b);
      if(!edgeMap.has(k)){ edgeMap.set(k,edges.length); edges.push({a,b,faces:[]}); }
      return edgeMap.get(k);
    }

    const triCount = index ? index.count/3 : posCount/3;
    for(let i=0; i<triCount; i++){
      let ia,ib,ic;
      if(index){ ia=bufVerts[index.getX(i*3)]; ib=bufVerts[index.getX(i*3+1)]; ic=bufVerts[index.getX(i*3+2)]; }
      else { ia=bufVerts[i*3]; ib=bufVerts[i*3+1]; ic=bufVerts[i*3+2]; }
      if(ia===ib||ib===ic||ia===ic) continue; // degenerate
      const fi=faces.length;
      const eA=getOrAddEdge(ia,ib); edges[eA].faces.push(fi);
      const eB=getOrAddEdge(ib,ic); edges[eB].faces.push(fi);
      const eC=getOrAddEdge(ic,ia); edges[eC].faces.push(fi);
      faces.push({verts:[ia,ib,ic], edges:[eA,eB,eC]});
    }

    // Compute face centers and normals
    const v3a=new THREE.Vector3(), v3b=new THREE.Vector3(), v3c=new THREE.Vector3();
    faces.forEach(f=>{
      const va=rawVerts[f.verts[0]], vb=rawVerts[f.verts[1]], vc=rawVerts[f.verts[2]];
      v3a.set(va.x,va.y,va.z); v3b.set(vb.x,vb.y,vb.z); v3c.set(vc.x,vc.y,vc.z);
      f.center={x:(va.x+vb.x+vc.x)/3, y:(va.y+vb.y+vc.y)/3, z:(va.z+vb.z+vc.z)/3};
      const edge1=v3b.clone().sub(v3a), edge2=v3c.clone().sub(v3a);
      const n=edge1.cross(edge2).normalize();
      f.normal={x:n.x,y:n.y,z:n.z};
    });

    return { verts:rawVerts, edges, faces };
  }

  return { buildFromGeometry };
})();

// ══════════════════════════════════════════════════════
//  SnapSystem — grid, vertex, edge snapping
// ══════════════════════════════════════════════════════
