'use strict';
const SelectionSystem = (() => {
  // _active  = the "primary" selected object (drives the Properties panel / gizmo)
  // _multiSet = Set of all selected mesh objects (always includes _active if mesh)
  let _active = null;
  const _multiSet = new Set();
  let _camera=null, _canvas=null;
  const _ray=new THREE.Raycaster();
  let _mouseDownPos={x:0,y:0}, _touchStartPos={x:0,y:0};

  function init(canvas,camera) {
    _canvas=canvas; _camera=camera;
    canvas.addEventListener('mousedown',_onMouseDown);
    canvas.addEventListener('click',_onClick);
    canvas.addEventListener('touchstart',_onTouchStart,{passive:true});
    canvas.addEventListener('touchend',_onTouchEnd);
  }

  function _getNDC(clientX,clientY) {
    const r=_canvas.getBoundingClientRect();
    return {x:((clientX-r.left)/r.width)*2-1, y:-((clientY-r.top)/r.height)*2+1};
  }

  function _raycast(ndc) {
    _ray.setFromCamera(ndc,_camera);
    // First try mesh objects
    const meshHits=_ray.intersectObjects(SceneManager.getMeshObjects(),false);
    // Also try scene objects (lights) — raycast against their icon children
    const sceneObjs=[...SceneManager.getLightObjects(), ...SceneManager.getCameraObjects()];
    const iconMeshes=[];
    sceneObjs.forEach(node=>{
      node.traverse(c=>{ if(c.isMesh&&c.userData.gizmoIcon) iconMeshes.push(c); });
    });
    const sceneHits=_ray.intersectObjects(iconMeshes,false);
    // Combine: pick closest hit
    let bestMesh=null, bestDist=Infinity;
    if(meshHits.length>0&&meshHits[0].distance<bestDist){ bestDist=meshHits[0].distance; bestMesh=meshHits[0].object; }
    if(sceneHits.length>0&&sceneHits[0].distance<bestDist){ bestDist=sceneHits[0].distance; bestMesh=sceneHits[0].object; }
    if(!bestMesh) return null;
    if(bestMesh.userData.gizmoIcon) return bestMesh.userData.cameraRoot || bestMesh.parent;
    return bestMesh;
  }

  // Apply/clear per-object visual highlight.
  // active = true → blue highlight; multiOnly = true → dimmer tint for secondary sel
  function _applyVisual(obj, active, multiOnly) {
    if (!obj) return;
    // Scene objects (lights/cameras): tint their icon mesh instead of material
    if (obj.userData.sceneObjectType) {
      const isCamera = obj.userData.sceneObjectType === 'camera';
      const restoreColor = isCamera ? 0x4d8ef5 : 0xffe080;
      obj.traverse(c => {
        if (c.isMesh && c.userData.gizmoIcon) {
          if (active) {
            c.material.color.setHex(0xffffff);
            c.material.opacity = 1.0;
            c.material.transparent = false;
          } else {
            c.material.color.setHex(restoreColor);
            c.material.opacity = isCamera ? 0.85 : 1.0;
            c.material.transparent = isCamera;
          }
          c.material.needsUpdate = true;
        }
      });
      return;
    }
    if (active) {
      ObjectManager.setSelected(obj, true);
    } else if (multiOnly) {
      // Secondary selection: mark as selected so outline system draws the wireframe.
      // Do NOT write blue emissive — it washes out the PBR material and persists.
      obj.userData._matSelected = true;
      obj.material.needsUpdate = true;
    } else {
      ObjectManager.setSelected(obj, false);
    }
  }

  function _clearAllVisuals() {
    _multiSet.forEach(obj => {
      if (obj !== _active) _applyVisual(obj, false, false);
    });
    if (_active) _applyVisual(_active, false, false);
  }

  // Core: set a single active object, clearing multi-selection
  function selectObject(obj, additive=false) {
    if (EditModeSystem.isActive() && additive) return; // no multi-select in edit mode

    if (!additive) {
      // Single select: clear everything first
      _clearAllVisuals();
      _multiSet.clear();
      _active = obj;
      if (_active) {
        _multiSet.add(_active);
        _applyVisual(_active, true, false);
      }
    } else {
      // Shift/additive: toggle obj in multi-set
      if (!obj) return; // shift-click on empty → do nothing
      if (_multiSet.has(obj)) {
        // Deselect this object
        _applyVisual(obj, false, false);
        _multiSet.delete(obj);
        // If it was the active, promote another
        if (_active === obj) {
          _active = _multiSet.size > 0 ? [..._multiSet][_multiSet.size - 1] : null;
          if (_active) _applyVisual(_active, true, false);
        }
      } else {
        // Add to selection
        _multiSet.add(obj);
        // Make it the new active
        if (_active && _active !== obj) _applyVisual(_active, false, true); // demote old active to secondary
        _active = obj;
        _applyVisual(_active, true, false);
      }
    }

    EventBus.emit('selection:changed', _active);
    FDEBUG.log('selection', 'selectObject', obj ? obj.name : 'null', 'additive:', additive);
  }

  // Add an object to multi-selection without making it active (used from hierarchy)
  function addToSelection(obj) {
    if (!obj) return;
    if (_multiSet.has(obj)) return;
    _multiSet.add(obj);
    if (!_active) {
      _active = obj;
      _applyVisual(obj, true, false);
    } else {
      _applyVisual(obj, false, true);
    }
    EventBus.emit('selection:changed', _active);
  }

  function getSelected()     { return _active; }
  function getMultiSelected(){ return [..._multiSet]; }
  function isInMultiSel(obj) { return _multiSet.has(obj); }
  function clearSelection()  { selectObject(null); }

  function _onMouseDown(e) { if(e.button!==0) return; _mouseDownPos={x:e.clientX,y:e.clientY}; }

  function _onClick(e) {
    if(EditModeSystem.isActive()) return;
    if(TransformControlsModule.isDragging()) return;
    const dist=Math.hypot(e.clientX-_mouseDownPos.x,e.clientY-_mouseDownPos.y);
    if(dist>5) return;
    if(e._gizmoConsumed) return;
    // If an active area selection tool (box/lasso) is running, suppress click
    if(typeof ObjectModeSelectSystem !== 'undefined' && (ObjectModeSelectSystem.getTool() === 'box' || ObjectModeSelectSystem.getTool() === 'lasso')) return;
    const ndc=_getNDC(e.clientX,e.clientY);
    const hit=_raycast(ndc);
    // Multi tool always adds to selection; shift always adds; select+shift also adds
    const isMulti = typeof ObjectModeSelectSystem !== 'undefined' && ObjectModeSelectSystem.getTool() === 'multi';
    selectObject(hit, e.shiftKey || isMulti);
  }

  function _onTouchStart(e) {
    if(e.touches.length===1) _touchStartPos={x:e.touches[0].clientX,y:e.touches[0].clientY};
  }

  function _onTouchEnd(e) {
    if(EditModeSystem.isActive()) return;
    if(e.changedTouches.length!==1) return;
    if(TransformControlsModule.isDragging()) return;
    if(TransformControlsModule.didAbsorbLastTouch()) return;
    const tool = (typeof ObjectModeSelectSystem !== 'undefined') ? ObjectModeSelectSystem.getTool() : 'select';
    if(tool === 'box' || tool === 'lasso') return;
    const t=e.changedTouches[0];
    const dist=Math.hypot(t.clientX-_touchStartPos.x,t.clientY-_touchStartPos.y);
    if(dist>10) return;
    const additive = tool === 'multi' || (EditModeSystem._multiSelectActive || false);
    selectObject(_raycast(_getNDC(t.clientX,t.clientY)), additive);
  }

  return { init, selectObject, addToSelection, getSelected, getMultiSelected, isInMultiSel, clearSelection };
})();

// ══════════════════════════════════════════════════════
//  ObjectModeSelectSystem — Select / Multi / Box / Lasso
//  Object Mode selection tools for the main viewport
// ══════════════════════════════════════════════════════

const ObjectModeSelectSystem = (() => {
  // Current tool: 'select' | 'multi' | 'box' | 'lasso'
  let _tool = 'select';
  let _canvas = null;
  let _camera = null;
  let _active = false; // true while a box/lasso drag is in progress

  // ── Raycast helper ──────────────────────────────────────────────────────────
  const _ray = new THREE.Raycaster();
  function _raycastObjects(clientX, clientY) {
    const r = _canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(
      ((clientX - r.left) / r.width) * 2 - 1,
      -((clientY - r.top) / r.height) * 2 + 1
    );
    _ray.setFromCamera(ndc, _camera);
    const meshHits = _ray.intersectObjects(SceneManager.getMeshObjects(), false);
    const iconMeshes = [];
    [...SceneManager.getLightObjects(), ...SceneManager.getCameraObjects()].forEach(node => {
      node.traverse(c => { if (c.isMesh && c.userData.gizmoIcon) iconMeshes.push(c); });
    });
    const sceneHits = _ray.intersectObjects(iconMeshes, false);
    let bestObj = null, bestDist = Infinity;
    if (meshHits.length > 0 && meshHits[0].distance < bestDist) {
      bestDist = meshHits[0].distance; bestObj = meshHits[0].object;
    }
    if (sceneHits.length > 0 && sceneHits[0].distance < bestDist) {
      bestObj = sceneHits[0].object;
    }
    if (bestObj && bestObj.userData.gizmoIcon) return bestObj.userData.cameraRoot || bestObj.parent;
    return bestObj;
  }

  // ── Project world point → screen point ──────────────────────────────────────
  function _worldToScreen(wx, wy, wz) {
    const r = _canvas.getBoundingClientRect();
    const v = new THREE.Vector3(wx, wy, wz).project(_camera);
    return { x: (v.x + 1) * 0.5 * r.width + r.left, y: (-v.y + 1) * 0.5 * r.height + r.top, vz: v.z };
  }

  // ── Point-in-polygon test ───────────────────────────────────────────────────
  function _ptInPoly(px, py, poly) {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const xi = poly[i].x, yi = poly[i].y, xj = poly[j].x, yj = poly[j].y;
      if (((yi > py) !== (yj > py)) && (px < (xj - xi) * (py - yi) / (yj - yi) + xi))
        inside = !inside;
    }
    return inside;
  }

  // ── Apply box selection of objects ──────────────────────────────────────────
  function _applyBoxSelect(x1, y1, x2, y2, additive) {
    const minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
    const minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
    const allObjs = [...SceneManager.getMeshObjects(), ...SceneManager.getLightObjects(), ...SceneManager.getCameraObjects()];
    const hits = [];
    allObjs.forEach(obj => {
      if (obj.userData.nonSelectable) return;
      // For lights, raycast the icon; for meshes, use bounding sphere
      let center;
      if (obj.userData.sceneObjectType === 'light') {
        obj.updateMatrixWorld(true);
        const pos = new THREE.Vector3();
        obj.getWorldPosition(pos);
        center = pos;
      } else {
        obj.updateMatrixWorld(true);
        if (!obj.geometry) return;
        obj.geometry.computeBoundingSphere();
        if (!obj.geometry.boundingSphere) return;
        const pos = new THREE.Vector3();
        obj.getWorldPosition(pos);
        center = pos;
      }
      const s = _worldToScreen(center.x, center.y, center.z);
      if (s.vz > 1) return; // behind camera
      if (s.x >= minX && s.x <= maxX && s.y >= minY && s.y <= maxY) hits.push(obj);
    });

    if (!additive) SelectionSystem.clearSelection();
    hits.forEach(obj => {
      if (additive && SelectionSystem.isInMultiSel(obj)) return;
      if (SelectionSystem.getSelected() === null) SelectionSystem.selectObject(obj, false);
      else SelectionSystem.selectObject(obj, true);
    });
  }

  // ── Apply lasso selection of objects ─────────────────────────────────────────
  function _applyLassoSelect(poly, additive, lassoRect) {
    const allObjs = [...SceneManager.getMeshObjects(), ...SceneManager.getLightObjects(), ...SceneManager.getCameraObjects()];
    const hits = [];
    allObjs.forEach(obj => {
      if (obj.userData.nonSelectable) return;
      obj.updateMatrixWorld(true);
      const pos = new THREE.Vector3();
      obj.getWorldPosition(pos);
      const s = _worldToScreen(pos.x, pos.y, pos.z);
      if (s.vz > 1) return;
      // Coords relative to lasso canvas (viewport-relative)
      const lpx = s.x - lassoRect.left;
      const lpy = s.y - lassoRect.top;
      if (_ptInPoly(lpx, lpy, poly)) hits.push(obj);
    });

    if (!additive) SelectionSystem.clearSelection();
    hits.forEach(obj => {
      if (additive && SelectionSystem.isInMultiSel(obj)) return;
      if (SelectionSystem.getSelected() === null) SelectionSystem.selectObject(obj, false);
      else SelectionSystem.selectObject(obj, true);
    });
  }

  // ── Box Select dragging ───────────────────────────────────────────────────────
  function _startBoxMode() {
    const rect = document.getElementById('box-select-rect');
    let start = null, activeTouchId = null;
    _active = true;
    CameraManager.setGizmoCaptured(true); // disable camera orbit

    function _showRect(x1, y1, x2, y2) {
      const vp = _canvas.getBoundingClientRect();
      if (!rect) return;
      rect.style.display = 'block';
      rect.style.left   = (Math.min(x1, x2) - vp.left) + 'px';
      rect.style.top    = (Math.min(y1, y2) - vp.top) + 'px';
      rect.style.width  = Math.abs(x2 - x1) + 'px';
      rect.style.height = Math.abs(y2 - y1) + 'px';
    }

    function _hideRect() { if (rect) rect.style.display = 'none'; }

    function _onDown(e) {
      if (e.button !== 0) { _end(); return; }
      start = { x: e.clientX, y: e.clientY };
    }
    function _onMove(e) {
      if (!start || !(e.buttons & 1)) return;
      _showRect(start.x, start.y, e.clientX, e.clientY);
    }
    function _onUp(e) {
      if (!start) return;
      _hideRect();
      _applyBoxSelect(start.x, start.y, e.clientX, e.clientY, e.shiftKey);
      _end();
    }
    function _onTouchStart(e) {
      if (activeTouchId !== null) return;
      const t = e.touches[0];
      activeTouchId = t.identifier;
      start = { x: t.clientX, y: t.clientY };
      e.preventDefault();
    }
    function _onTouchMove(e) {
      if (!start || activeTouchId === null) return;
      let t = null;
      for (let i = 0; i < e.touches.length; i++) { if (e.touches[i].identifier === activeTouchId) { t = e.touches[i]; break; } }
      if (!t) return;
      _showRect(start.x, start.y, t.clientX, t.clientY);
      e.preventDefault();
    }
    function _onTouchEnd(e) {
      if (!start || activeTouchId === null) return;
      let t = null;
      for (let i = 0; i < e.changedTouches.length; i++) { if (e.changedTouches[i].identifier === activeTouchId) { t = e.changedTouches[i]; break; } }
      if (!t) return;
      _hideRect();
      _applyBoxSelect(start.x, start.y, t.clientX, t.clientY, false);
      _end();
    }
    function _end() {
      _active = false;
      _hideRect();
      CameraManager.setGizmoCaptured(false);
      // After box selection, revert to Select tool
      if (_tool === 'box') _setTool('select');
      _canvas.removeEventListener('mousedown', _onDown);
      window.removeEventListener('mousemove', _onMove);
      window.removeEventListener('mouseup', _onUp);
      _canvas.removeEventListener('touchstart', _onTouchStart);
      window.removeEventListener('touchmove', _onTouchMove);
      window.removeEventListener('touchend', _onTouchEnd);
    }

    _canvas.addEventListener('mousedown', _onDown);
    window.addEventListener('mousemove', _onMove);
    window.addEventListener('mouseup', _onUp);
    _canvas.addEventListener('touchstart', _onTouchStart, { passive: false });
    window.addEventListener('touchmove', _onTouchMove, { passive: false });
    window.addEventListener('touchend', _onTouchEnd, { passive: true });
  }

  // ── Lasso Select dragging ─────────────────────────────────────────────────────
  function _startLassoMode() {
    const lassoEl = document.getElementById('lasso-canvas');
    if (!lassoEl) return;

    const vp = _canvas.getBoundingClientRect();
    lassoEl.width  = vp.width;
    lassoEl.height = vp.height;
    lassoEl.classList.add('active');
    const ctx = lassoEl.getContext('2d');
    let path = [], drawing = false, activeTouchId = null;
    _active = true;
    CameraManager.setGizmoCaptured(true);

    function _draw() {
      ctx.clearRect(0, 0, lassoEl.width, lassoEl.height);
      if (path.length < 2) return;
      ctx.beginPath();
      ctx.moveTo(path[0].x, path[0].y);
      path.forEach(p => ctx.lineTo(p.x, p.y));
      ctx.closePath();
      ctx.fillStyle   = 'rgba(77,142,245,0.10)';
      ctx.strokeStyle = 'rgba(77,142,245,0.80)';
      ctx.lineWidth   = 1.5;
      ctx.setLineDash([4, 3]);
      ctx.fill();
      ctx.stroke();
    }

    function _onDown(e) {
      if (e.button !== 0) { _end(); return; }
      drawing = true; path = [];
      const r = lassoEl.getBoundingClientRect();
      path.push({ x: e.clientX - r.left, y: e.clientY - r.top });
      e.preventDefault(); e.stopPropagation();
    }
    function _onMove(e) {
      if (!drawing) return;
      const r = lassoEl.getBoundingClientRect();
      path.push({ x: e.clientX - r.left, y: e.clientY - r.top });
      _draw();
    }
    function _onUp(e) {
      if (!drawing) return;
      drawing = false;
      const r = lassoEl.getBoundingClientRect();
      _applyLassoSelect(path, e.shiftKey, r);
      _end();
    }
    function _onTouchStart(e) {
      if (activeTouchId !== null) return;
      const t = e.touches[0];
      activeTouchId = t.identifier; drawing = true; path = [];
      const r = lassoEl.getBoundingClientRect();
      path.push({ x: t.clientX - r.left, y: t.clientY - r.top });
      e.preventDefault(); e.stopPropagation();
    }
    function _onTouchMove(e) {
      if (!drawing || activeTouchId === null) return;
      let t = null;
      for (let i = 0; i < e.touches.length; i++) { if (e.touches[i].identifier === activeTouchId) { t = e.touches[i]; break; } }
      if (!t) return;
      const r = lassoEl.getBoundingClientRect();
      path.push({ x: t.clientX - r.left, y: t.clientY - r.top });
      _draw();
      e.preventDefault();
    }
    function _onTouchEnd(e) {
      if (!drawing || activeTouchId === null) return;
      let t = null;
      for (let i = 0; i < e.changedTouches.length; i++) { if (e.changedTouches[i].identifier === activeTouchId) { t = e.changedTouches[i]; break; } }
      if (!t) return;
      drawing = false; activeTouchId = null;
      const r = lassoEl.getBoundingClientRect();
      _applyLassoSelect(path, false, r);
      _end();
    }
    function _end() {
      _active = false;
      ctx.clearRect(0, 0, lassoEl.width, lassoEl.height);
      lassoEl.classList.remove('active');
      CameraManager.setGizmoCaptured(false);
      if (_tool === 'lasso') _setTool('select');
      lassoEl.removeEventListener('mousedown', _onDown);
      window.removeEventListener('mousemove', _onMove);
      window.removeEventListener('mouseup', _onUp);
      lassoEl.removeEventListener('touchstart', _onTouchStart);
      window.removeEventListener('touchmove', _onTouchMove);
      window.removeEventListener('touchend', _onTouchEnd);
    }

    lassoEl.addEventListener('mousedown', _onDown);
    window.addEventListener('mousemove', _onMove);
    window.addEventListener('mouseup', _onUp);
    lassoEl.addEventListener('touchstart', _onTouchStart, { passive: false });
    window.addEventListener('touchmove', _onTouchMove, { passive: false });
    window.addEventListener('touchend', _onTouchEnd, { passive: true });
  }

  // ── Tool switching ─────────────────────────────────────────────────────────
  const _selToolMeta = {
    select: { label:'Selection',    svg:'<path d="M3 1l7 5-4 1-2 4z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/>' },
    multi:  { label:'Multi Select', svg:'<path d="M2 2h3v3H2zM7 2h3v3H7zM2 7h3v3H2zM7 7h3v3H7z" stroke="currentColor" stroke-width="1.1" stroke-linejoin="round"/>' },
    box:    { label:'Box Select',   svg:'<rect x="2" y="2" width="8" height="8" rx="0.5" stroke="currentColor" stroke-width="1.2" stroke-dasharray="2 1.5"/>' },
    lasso:  { label:'Lasso Select', svg:'<path d="M6 2C3.5 2 2 3.5 2 5s1.5 2.5 3 2c1.5-.5 1.5 1 3 1 1.5 0 2-1 2-2 0-2.5-1.5-4-4-4z" stroke="currentColor" stroke-width="1.2" stroke-dasharray="1.5 1.5"/>' },
  };
  function _setTool(tool) {
    _tool = tool;
    // Highlight active item in the dropdown list
    ['select','multi','box','lasso'].forEach(t => {
      const btn = document.getElementById('btn-sel-' + t);
      if (btn) btn.classList.toggle('active', t === tool);
    });
    // Update the trigger label + icon to reflect the current mode
    const meta = _selToolMeta[tool] || _selToolMeta.select;
    const labelEl = document.getElementById('sel-obj-label');
    const iconEl  = document.getElementById('sel-obj-icon');
    if (labelEl) labelEl.textContent = meta.label;
    if (iconEl)  iconEl.innerHTML = meta.svg;
    // Close the dropdown
    const trigger = document.getElementById('sel-obj-dropdown-trigger');
    const panel   = document.getElementById('sel-obj-dropdown-panel');
    if (trigger) trigger.classList.remove('open');
    if (panel)   panel.classList.remove('open');
    // Activate box/lasso immediately on mode switch (while not in edit mode)
    if (!EditModeSystem.isActive()) {
      if (tool === 'box')   _startBoxMode();
      if (tool === 'lasso') _startLassoMode();
    }
  }

  function getTool() { return _tool; }

  // ── Canvas click handler (select + multi tools) ───────────────────────────
  let _mouseDownPos = { x: 0, y: 0 };
  let _touchStartPos = { x: 0, y: 0 };

  function _handleClick(clientX, clientY, shiftKey) {
    if (EditModeSystem.isActive()) return;
    if (_active) return;
    if (_tool === 'box' || _tool === 'lasso') return;
    const hit = _raycastObjects(clientX, clientY);
    const additive = shiftKey || _tool === 'multi';
    SelectionSystem.selectObject(hit, additive);
  }

  // ── Init ──────────────────────────────────────────────────────────────────
  function init(canvas, camera) {
    _canvas = canvas;
    _camera = camera;

    // Wire Selection dropdown toggle
    const _selObjTrigger = document.getElementById('sel-obj-dropdown-trigger');
    const _selObjPanel   = document.getElementById('sel-obj-dropdown-panel');
    if (_selObjTrigger && _selObjPanel) {
      _selObjTrigger.addEventListener('click', e => {
        e.stopPropagation();
        const isOpen = _selObjPanel.classList.contains('open');
        _selObjPanel.classList.toggle('open', !isOpen);
        _selObjTrigger.classList.toggle('open', !isOpen);
      });
      document.addEventListener('click', () => {
        _selObjPanel.classList.remove('open');
        _selObjTrigger.classList.remove('open');
      });
      _selObjPanel.addEventListener('click', e => e.stopPropagation());
    }
    // Wire dropdown items to set the active tool
    ['select','multi','box','lasso'].forEach(tool => {
      const btn = document.getElementById('btn-sel-' + tool);
      if (btn) btn.addEventListener('click', () => _setTool(tool));
    });

    // Keyboard shortcuts: S=select, M=multi, B=box, L=lasso
    window.addEventListener('keydown', e => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (EditModeSystem.isActive()) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === 'b' || e.key === 'B') _setTool('box');
      if (e.key === 'l' || e.key === 'L') _setTool('lasso');
    });
  }

  return { init, getTool, setTool: _setTool };
})();

// ══════════════════════════════════════════════════════
//  TransformControlsModule (Strict Gizmo v4)
// ══════════════════════════════════════════════════════
