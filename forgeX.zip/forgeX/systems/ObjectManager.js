'use strict';
const ObjectManager = (() => {
  let _counter={};

  function _createMaterial(type) {
    const mat = new THREE.MeshStandardMaterial({
      color:             0xc8c8c8,
      roughness:         0.58,
      metalness:         0.02,
      emissive:          new THREE.Color(0x000000),
      emissiveIntensity: 0,
    });
    if(type==='plane' || type==='circle') mat.side=THREE.DoubleSide;
    if(type==='empty') { mat.color.set(0x88aaff); mat.emissive.set(0x2244aa); mat.emissiveIntensity=0.4; mat.roughness=0.3; }
    return mat;
  }

  // Build an icosahedron-based sphere (true geodesic ico-sphere)
  function _buildIcoSphere(radius, detail) {
    // Start with an icosahedron, then subdivide and normalize
    const geo = new THREE.IcosahedronGeometry(radius, detail);
    return geo;
  }

  // Build a flat circle (disc)
  function _buildCircle(radius, segments) {
    return new THREE.CircleGeometry(radius, segments);
  }

  // Build torus knot geometry
  function _buildTorusKnot(radius, tube, p, q) {
    return new THREE.TorusKnotGeometry(radius, tube, 128, 16, p, q);
  }

  // Build a visual "empty" axis helper as a BufferGeometry (small axis cross)
  function _buildEmptyGeo() {
    // Creates 3 axis lines as a LineSegments-compatible BufferGeometry
    // But since we want a Mesh for consistency, we use small thin cylinders
    // merged into a compound geometry using hand-built positions
    const size = 0.4;
    const positions = [];
    const normals   = [];

    function _addBox(cx, cy, cz, sx, sy, sz) {
      // 12 triangles (box faces)
      const hx = sx/2, hy = sy/2, hz = sz/2;
      const verts = [
        // +X
        [cx+hx,cy-hy,cz-hz],[cx+hx,cy+hy,cz-hz],[cx+hx,cy+hy,cz+hz],
        [cx+hx,cy-hy,cz-hz],[cx+hx,cy+hy,cz+hz],[cx+hx,cy-hy,cz+hz],
        // -X
        [cx-hx,cy-hy,cz+hz],[cx-hx,cy+hy,cz+hz],[cx-hx,cy+hy,cz-hz],
        [cx-hx,cy-hy,cz+hz],[cx-hx,cy+hy,cz-hz],[cx-hx,cy-hy,cz-hz],
        // +Y
        [cx-hx,cy+hy,cz-hz],[cx-hx,cy+hy,cz+hz],[cx+hx,cy+hy,cz+hz],
        [cx-hx,cy+hy,cz-hz],[cx+hx,cy+hy,cz+hz],[cx+hx,cy+hy,cz-hz],
        // -Y
        [cx-hx,cy-hy,cz+hz],[cx-hx,cy-hy,cz-hz],[cx+hx,cy-hy,cz-hz],
        [cx-hx,cy-hy,cz+hz],[cx+hx,cy-hy,cz-hz],[cx+hx,cy-hy,cz+hz],
        // +Z
        [cx-hx,cy-hy,cz+hz],[cx+hx,cy-hy,cz+hz],[cx+hx,cy+hy,cz+hz],
        [cx-hx,cy-hy,cz+hz],[cx+hx,cy+hy,cz+hz],[cx-hx,cy+hy,cz+hz],
        // -Z
        [cx+hx,cy-hy,cz-hz],[cx-hx,cy-hy,cz-hz],[cx-hx,cy+hy,cz-hz],
        [cx+hx,cy-hy,cz-hz],[cx-hx,cy+hy,cz-hz],[cx+hx,cy+hy,cz-hz],
      ];
      const norms = [
        [1,0,0],[1,0,0],[1,0,0],[1,0,0],[1,0,0],[1,0,0],
        [-1,0,0],[-1,0,0],[-1,0,0],[-1,0,0],[-1,0,0],[-1,0,0],
        [0,1,0],[0,1,0],[0,1,0],[0,1,0],[0,1,0],[0,1,0],
        [0,-1,0],[0,-1,0],[0,-1,0],[0,-1,0],[0,-1,0],[0,-1,0],
        [0,0,1],[0,0,1],[0,0,1],[0,0,1],[0,0,1],[0,0,1],
        [0,0,-1],[0,0,-1],[0,0,-1],[0,0,-1],[0,0,-1],[0,0,-1],
      ];
      verts.forEach((v,i) => {
        positions.push(...v);
        normals.push(...norms[i]);
      });
    }

    const arm = size * 0.06;
    _addBox(size*0.5, 0, 0, size, arm, arm); // +X arm
    _addBox(0, size*0.5, 0, arm, size, arm); // +Y arm
    _addBox(0, 0, size*0.5, arm, arm, size); // +Z arm

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(positions), 3));
    geo.setAttribute('normal',   new THREE.BufferAttribute(new Float32Array(normals),   3));
    return geo;
  }

  function _buildGeometry(type) {
    switch(type){
      case 'box':        return new THREE.BoxGeometry(1,1,1,2,2,2);
      case 'sphere':     return new THREE.SphereGeometry(0.6,16,12);
      case 'cylinder':   return new THREE.CylinderGeometry(0.5,0.5,1,16,2);
      case 'cone':       return new THREE.ConeGeometry(0.5,1,16,2);
      case 'torus':      return new THREE.TorusGeometry(0.5,0.2,8,24);
      case 'plane':      return new THREE.PlaneGeometry(1.5,1.5,4,4);
      case 'icosphere':  return _buildIcoSphere(0.6, 2);
      case 'torusknot':  return _buildTorusKnot(0.4, 0.15, 2, 3);
      case 'circle':     return _buildCircle(0.7, 32);
      case 'empty':      return _buildEmptyGeo();
      default:           return new THREE.BoxGeometry(1,1,1,2,2,2);
    }
  }

  function _typeName(type) {
    return {
      box:'Cube', sphere:'Sphere', cylinder:'Cylinder', cone:'Cone',
      torus:'Torus', plane:'Plane',
      icosphere:'IcoSphere', torusknot:'TorusKnot', circle:'Circle', empty:'Empty',
    }[type] || 'Mesh';
  }

  function createPrimitive(type) {
    const name=_typeName(type);
    _counter[name]=(_counter[name]||0)+1;
    const geo = _buildGeometry(type);
    // Copy uv → uv2 so aoMap works in Three.js r128
    if (geo.attributes.uv) {
      geo.setAttribute('uv2', geo.attributes.uv.clone());
    }
    const mesh=new THREE.Mesh(geo,_createMaterial(type));
    LightManager.configureMeshShadows(mesh);
    mesh.position.y=type==='plane'?0:0.5;
    mesh.name=_counter[name]===1?name:`${name}.${String(_counter[name]).padStart(3,'0')}`;
    mesh.userData.primitiveType=type; mesh.userData.typeName=name;
    FDEBUG.log('objectCreation', 'createPrimitive', type, mesh.name);
    return mesh;
  }

  function setSelected(mesh,selected) {
    if(!mesh||mesh.userData.editOverlay) return;
    if(selected){
      mesh.userData._matSelected = true;
      // Selection highlight is shown by the SelectionOutline wireframe system —
      // do NOT write blue emissive here. Any emissive tint washes out the PBR
      // shading and persists after deselection, causing the blue-tint bug.
      // The material stays exactly as the user set it.
      mesh.material.needsUpdate = true;
    } else {
      mesh.userData._matSelected = false;
      // Restore material from stored data (clears any stale emissive overrides).
      if(typeof MaterialSystem !== 'undefined') {
        MaterialSystem.restoreFromData(mesh);
      } else {
        mesh.material.emissive = new THREE.Color(0x000000);
        mesh.material.emissiveIntensity = 0;
        mesh.material.needsUpdate = true;
      }
    }
  }

  function setEditMode(mesh, inEditMode) {
    if(!mesh) return;
    if(inEditMode){
      mesh.userData._matEditing = true;
      // Save state for clean restore on exit
      mesh.userData._savedCastShadow  = mesh.castShadow;
      mesh.userData._savedFlatShading = mesh.material.flatShading;
      mesh.userData._savedSide        = mesh.material.side;
      // Disable shadow casting in edit mode — prevents dark shadow-map artifacts
      mesh.castShadow = false;
      // Flat shading eliminates stretched normals during vertex editing.
      // FrontSide only — DoubleSide causes z-fighting with face overlays.
      mesh.material.flatShading = true;
      mesh.material.side = THREE.FrontSide;
      // No emissive tint — let the material stay as-is; the orange wireframe
      // edit overlay and sub-toolbar already make edit mode visually clear.
      mesh.material.needsUpdate = true;
    } else {
      mesh.userData._matEditing = false;
      // Restore shadow casting — delegate to LightManager so the global toggle
      // and per-object helper flags are all respected (raw _savedCastShadow restore
      // would silently desync when the global shadow state changed during editing).
      if (typeof LightManager !== 'undefined') {
        LightManager.configureMeshShadows(mesh);
      } else {
        mesh.castShadow = (mesh.userData._savedCastShadow !== undefined)
          ? mesh.userData._savedCastShadow : true;
      }
      // Restore shading and side
      mesh.material.flatShading = mesh.userData._savedFlatShading || false;
      mesh.material.side = (mesh.userData._savedSide !== undefined)
        ? mesh.userData._savedSide : THREE.FrontSide;
      // Clear any stale emissive that may have been set during editing
      if(typeof MaterialSystem !== 'undefined') {
        MaterialSystem.restoreFromData(mesh);
      } else {
        mesh.material.emissive = new THREE.Color(0x000000);
        mesh.material.emissiveIntensity = 0;
      }
      mesh.material.needsUpdate = true;
    }
  }

  function getGeomInfo(mesh) {
    if(!mesh||!mesh.geometry) return {verts:0,faces:0};
    const geo=mesh.geometry; const pos=geo.attributes.position;
    const verts=pos?pos.count:0;
    const idx=geo.index; const faces=idx?idx.count/3:verts/3;
    return {verts,faces:Math.floor(faces)};
  }

  return { createPrimitive, setSelected, setEditMode, getGeomInfo };
})();

// ══════════════════════════════════════════════════════
//  EditMeshData — topology extraction from BufferGeometry
// ══════════════════════════════════════════════════════
