'use strict';
const LightSystem = (() => {

  // ── Collapsible sections ──────────────────────────────────────────────────
  function _initCollapsibles() {
    const sections = [
      { hdr: 'lt-add-header',    body: 'lt-add-body'    },
      { hdr: 'lt-env-header',    body: 'lt-env-body'    },
      { hdr: 'lt-list-header',   body: 'lt-list-body'   },
      { hdr: 'cam-list-header',  body: 'cam-list-body'  },
      { hdr: 'lt-shadow-header', body: 'lt-shadow-body' },
      { hdr: 'lt-post-header',   body: 'lt-post-body'   },
    ];
    sections.forEach(({ hdr, body }) => {
      const h = document.getElementById(hdr);
      const b = document.getElementById(body);
      if (!h || !b) return;
      h.addEventListener('click', () => {
        const collapsed = h.classList.toggle('collapsed');
        b.style.display = collapsed ? 'none' : '';
      });
    });
  }

  // ── Add-light buttons ─────────────────────────────────────────────────────
  function _initAddButtons() {
    document.querySelectorAll('.lt-add-btn[data-ltype]').forEach(btn => {
      btn.addEventListener('click', () => {
        const ltype = btn.dataset.ltype;
        // All 5 types supported natively now (area uses RectAreaLight or fallback)
        LightManager.addLight(ltype);
        refreshList();
      });
    });
  }

  // ── Environment (viewport ambient) controls ────────────────────────────────
  // These bind to the existing #lt-ambient-intensity / #lt-sun-* inputs
  // and drive the viewport hemisphere / key lights via LightManager internals.
  // (We expose helpers on the viewport lights via the module closure.)
  function _initEnvControls() {
    const ambSlider = document.getElementById('lt-ambient-intensity');
    const ambVal    = document.getElementById('lt-ambient-intensity-val');
    const ambColor  = document.getElementById('lt-ambient-color');
    const ambHex    = document.getElementById('lt-ambient-color-hex');
    const sunSlider = document.getElementById('lt-sun-intensity');
    const sunVal    = document.getElementById('lt-sun-intensity-val');
    const sunColor  = document.getElementById('lt-sun-color');
    const sunHex    = document.getElementById('lt-sun-color-hex');

    function _getVPLight(name) {
      // Access via LightManager's internal viewport array exposed below
      return LightManager._getViewportLight && LightManager._getViewportLight(name);
    }

    if (ambSlider) {
      ambSlider.addEventListener('input', () => {
        const v = parseInt(ambSlider.value) / 100;
        if (ambVal) ambVal.textContent = v.toFixed(2);
        const hemi = _getVPLight('viewport_hemi');
        if (hemi) hemi.intensity = v;
      });
    }
    if (ambColor) {
      ambColor.addEventListener('input', () => {
        const v = ambColor.value;
        if (ambHex) ambHex.value = v;
        const hemi = _getVPLight('viewport_hemi');
        if (hemi) hemi.color.set(v);
      });
    }
    if (ambHex) {
      ambHex.addEventListener('input', () => {
        const v = ambHex.value;
        if (/^#[0-9a-fA-F]{6}$/.test(v)) {
          if (ambColor) ambColor.value = v;
          const hemi = _getVPLight('viewport_hemi');
          if (hemi) hemi.color.set(v);
        }
      });
    }
    if (sunSlider) {
      sunSlider.addEventListener('input', () => {
        const v = parseInt(sunSlider.value) / 100;
        if (sunVal) sunVal.textContent = v.toFixed(2);
        const key = _getVPLight('viewport_key');
        if (key) key.intensity = v;
      });
    }
    if (sunColor) {
      sunColor.addEventListener('input', () => {
        const v = sunColor.value;
        if (sunHex) sunHex.value = v;
        const key = _getVPLight('viewport_key');
        if (key) key.color.set(v);
      });
    }
    if (sunHex) {
      sunHex.addEventListener('input', () => {
        const v = sunHex.value;
        if (/^#[0-9a-fA-F]{6}$/.test(v)) {
          if (sunColor) sunColor.value = v;
          const key = _getVPLight('viewport_key');
          if (key) key.color.set(v);
        }
      });
    }
  }

  // ── Shadow toggle & quality ────────────────────────────────────────────────
  function _initShadowControls() {
    const toggle   = document.getElementById('lt-shadow-toggle');
    const label    = document.getElementById('lt-shadow-label');
    const qualGrp  = document.getElementById('lt-shadow-quality');
    const softSlider = document.getElementById('lt-shadow-softness');
    const softVal    = document.getElementById('lt-shadow-softness-val');

    if (toggle) {
      // Sync UI with actual LightManager state at init time
      const currentlyEnabled = LightManager.getShadowsEnabled();
      toggle.classList.toggle('active', currentlyEnabled);
      toggle.setAttribute('aria-checked', currentlyEnabled);
      if (label) label.textContent = currentlyEnabled ? 'On' : 'Off';

      toggle.addEventListener('click', () => {
        const on = !toggle.classList.contains('active');
        toggle.classList.toggle('active', on);
        toggle.setAttribute('aria-checked', on);
        if (label) label.textContent = on ? 'On' : 'Off';
        LightManager.setShadowsEnabled(on);
      });
    }

    if (qualGrp) {
      qualGrp.querySelectorAll('.lt-quality-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          qualGrp.querySelectorAll('.lt-quality-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          LightManager.setShadowQuality(btn.dataset.q);
        });
      });
    }

    if (softSlider) {
      softSlider.addEventListener('input', () => {
        const v = parseInt(softSlider.value) / 100;
        if (softVal) softVal.textContent = v.toFixed(2);
        LightManager.setShadowSoftness(v);
      });
    }
  }

  // ── Post effects (exposure, contrast) ────────────────────────────────────
  function _initPostControls() {
    const expSlider = document.getElementById('lt-exposure');
    const expVal    = document.getElementById('lt-exposure-val');
    if (expSlider) {
      expSlider.addEventListener('input', () => {
        const v = parseInt(expSlider.value) / 100;
        if (expVal) expVal.textContent = v.toFixed(2);
        const renderer = RendererManager.getRenderer();
        if (renderer) renderer.toneMappingExposure = v;
      });
    }
    // Bloom/contrast are UI-only in r128 without post-processing passes
    const bsSlider = document.getElementById('lt-bloom-strength');
    const bsVal    = document.getElementById('lt-bloom-strength-val');
    if (bsSlider) {
      bsSlider.addEventListener('input', () => {
        const v = parseInt(bsSlider.value) / 100;
        if (bsVal) bsVal.textContent = v.toFixed(2);
      });
    }
    const btSlider = document.getElementById('lt-bloom-threshold');
    const btVal    = document.getElementById('lt-bloom-threshold-val');
    if (btSlider) {
      btSlider.addEventListener('input', () => {
        const v = parseInt(btSlider.value) / 100;
        if (btVal) btVal.textContent = v.toFixed(2);
      });
    }
    const ctSlider = document.getElementById('lt-contrast');
    const ctVal    = document.getElementById('lt-contrast-val');
    if (ctSlider) {
      ctSlider.addEventListener('input', () => {
        const v = parseInt(ctSlider.value) / 100;
        if (ctVal) ctVal.textContent = v.toFixed(2);
      });
    }
  }

  // ── Per-light list rendering ───────────────────────────────────────────────
  const TYPE_ICONS = {
    point:       `<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="6" r="2.5" fill="currentColor" opacity="0.75"/><path d="M6 1v1.5M6 9.5V11M1 6h1.5M9.5 6H11M2.6 2.6l1.1 1.1M8.3 8.3l1.1 1.1M9.4 2.6l-1.1 1.1M3.7 8.3L2.6 9.4" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>`,
    spot:        `<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="3.5" r="1.7" fill="currentColor" opacity="0.75"/><path d="M4.5 5.5L2.5 10M7.5 5.5L9.5 10M4.5 5.5h3" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 1v1.5" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>`,
    directional: `<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M6 1L6 11M1 6L11 6" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><path d="M3 3l6 6M9 3l-6 6" stroke="currentColor" stroke-width="0.9" stroke-linecap="round" opacity="0.4"/></svg>`,
    hemisphere:  `<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M2 8A4 4 0 0 1 10 8" stroke="currentColor" stroke-width="1.2"/><circle cx="6" cy="4" r="1.5" fill="currentColor" opacity="0.65"/></svg>`,
    area:        `<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><rect x="2" y="2.5" width="8" height="5" rx="0.8" stroke="currentColor" stroke-width="1.1"/><path d="M4 8.5v1.5M8 8.5v1.5M3.5 10h5" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>`,
  };

  // Shadow-capable light types (others never show the toggle)
  const SHADOW_CAPABLE = new Set(['directional', 'point', 'spot']);

  function _lightRowHTML(entry) {
    const TYPE_LABELS = { point:'Point', spot:'Spot', directional:'Sun', hemisphere:'Hemi', area:'Area' };
    const typeLabel = TYPE_LABELS[entry.lightType] || 'Light';
    const icon      = TYPE_ICONS[entry.lightType] || TYPE_ICONS.directional;
    const color     = entry.node.userData.lightColor || '#ffffff';
    const intensity = isFinite(entry.node.userData.lightIntensity) ? entry.node.userData.lightIntensity : 1.0;
    const shadow    = !!(entry.node.userData.shadowEnabled !== undefined
      ? entry.node.userData.shadowEnabled
      : entry.node.userData.castShadow);
    const visible   = entry.node.visible;
    const nodeUuid  = entry.node.uuid;
    const canShadow = SHADOW_CAPABLE.has(entry.lightType);

    // Intensity slider max: point/spot go up to 20 (physically), directional up to 5
    const sliderMax = (entry.lightType === 'point' || entry.lightType === 'spot') ? 2000 : 500;
    const sliderVal = Math.round(Math.min(intensity, sliderMax / 100) * 100);

    return `
<div class="lt-light-row" data-uuid="${nodeUuid}">
  <div class="lt-light-row-header">
    <span class="lt-light-type-icon">${icon}</span>
    <span class="lt-light-name">${entry.node.name}</span>
    <span class="lt-light-badge">${typeLabel}</span>
    <div class="lt-light-row-actions">
      <button class="lt-light-action-btn lt-vis-btn${visible ? '' : ' hidden-light'}" data-uuid="${nodeUuid}" title="${visible ? 'Hide' : 'Show'} light">
        <svg width="10" height="10" viewBox="0 0 12 12" fill="none"><path d="M1.5 6C2.5 3.5 4.1 2 6 2s3.5 1.5 4.5 4c-1 2.5-2.6 4-4.5 4S2.5 8.5 1.5 6z" stroke="currentColor" stroke-width="1.1"/><circle cx="6" cy="6" r="1.5" fill="currentColor" opacity="0.8"/></svg>
      </button>
      <button class="lt-light-action-btn lt-del-btn" data-uuid="${nodeUuid}" title="Delete light">
        <svg width="10" height="10" viewBox="0 0 12 12" fill="none"><path d="M2 2l8 8M10 2l-8 8" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>
      </button>
    </div>
  </div>
  <div class="lt-light-props">
    <div class="lt-prop-row">
      <span class="lt-prop-label">Color</span>
      <div class="lt-color-wrap">
        <input type="color" class="lt-color-swatch" data-uuid="${nodeUuid}" value="${color}" title="Light color">
        <input type="text" class="lt-color-hex" data-uuid="${nodeUuid}" value="${color}" maxlength="7" spellcheck="false">
      </div>
    </div>
    <div class="lt-prop-row">
      <span class="lt-prop-label">Intensity</span>
      <div class="lt-intensity-wrap">
        <input type="range" class="lt-intensity-slider" data-uuid="${nodeUuid}" data-max="${sliderMax}" min="0" max="${sliderMax}" value="${sliderVal}" title="Light intensity">
        <input type="number" class="lt-intensity-num" data-uuid="${nodeUuid}" value="${intensity.toFixed(2)}" min="0" step="0.1">
      </div>
    </div>
    ${canShadow ? `
    <div class="lt-prop-row">
      <span class="lt-prop-label">Shadow</span>
      <button class="lt-shadow-btn${shadow ? ' active' : ''}" data-uuid="${nodeUuid}" role="switch" aria-checked="${shadow}">
        ${shadow ? 'On' : 'Off'}
      </button>
    </div>` : `
    <div class="lt-prop-row">
      <span class="lt-prop-label" style="color:var(--text-dim);font-style:italic">No shadows</span>
    </div>`}
  </div>
</div>`;
  }

  function refreshList() {
    const listEl   = document.getElementById('lt-light-list');
    const noLights = document.getElementById('lt-no-lights');
    const countBadge = document.getElementById('lt-light-count');
    if (!listEl) return;

    const lights = LightManager.getSceneLights();

    if (countBadge) countBadge.textContent = lights.length;

    if (lights.length === 0) {
      listEl.innerHTML = '<div class="lt-empty" id="lt-no-lights">No lights in scene.</div>';
      return;
    }

    listEl.innerHTML = lights.map(e => _lightRowHTML(e)).join('');

    // Wire events on the rendered list
    listEl.querySelectorAll('.lt-vis-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const uuid  = btn.dataset.uuid;
        const entry = LightManager.getSceneLights().find(e => e.node.uuid === uuid);
        if (!entry) return;
        LightManager.updateLight(entry.node, { visible: !entry.node.visible });
        refreshList();
      });
    });

    listEl.querySelectorAll('.lt-del-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const uuid  = btn.dataset.uuid;
        const entry = LightManager.getSceneLights().find(e => e.node.uuid === uuid);
        if (!entry) return;
        LightManager.removeLight(entry.node);
        refreshList();
      });
    });

    listEl.querySelectorAll('.lt-color-swatch').forEach(swatch => {
      swatch.addEventListener('input', () => {
        const uuid  = swatch.dataset.uuid;
        const entry = LightManager.getSceneLights().find(e => e.node.uuid === uuid);
        if (!entry) return;
        // Sync hex input
        const hexEl = listEl.querySelector(`.lt-color-hex[data-uuid="${uuid}"]`);
        if (hexEl) hexEl.value = swatch.value;
        LightManager.updateLight(entry.node, { color: swatch.value });
      });
    });

    listEl.querySelectorAll('.lt-color-hex').forEach(hexEl => {
      hexEl.addEventListener('input', () => {
        const uuid  = hexEl.dataset.uuid;
        if (!/^#[0-9a-fA-F]{6}$/.test(hexEl.value)) return;
        const entry = LightManager.getSceneLights().find(e => e.node.uuid === uuid);
        if (!entry) return;
        const swatchEl = listEl.querySelector(`.lt-color-swatch[data-uuid="${uuid}"]`);
        if (swatchEl) swatchEl.value = hexEl.value;
        LightManager.updateLight(entry.node, { color: hexEl.value });
      });
    });

    listEl.querySelectorAll('.lt-intensity-slider').forEach(slider => {
      slider.addEventListener('input', () => {
        const uuid  = slider.dataset.uuid;
        const entry = LightManager.getSceneLights().find(e => e.node.uuid === uuid);
        if (!entry) return;
        const v = parseInt(slider.value) / 100;
        const numEl = listEl.querySelector(`.lt-intensity-num[data-uuid="${uuid}"]`);
        if (numEl) numEl.value = v.toFixed(2);
        LightManager.updateLight(entry.node, { intensity: v });
      });
    });

    listEl.querySelectorAll('.lt-intensity-num').forEach(numEl => {
      numEl.addEventListener('input', () => {
        const uuid  = numEl.dataset.uuid;
        const entry = LightManager.getSceneLights().find(e => e.node.uuid === uuid);
        if (!entry) return;
        const v = parseFloat(numEl.value);
        if (!isFinite(v) || v < 0) return;
        const sliderEl = listEl.querySelector(`.lt-intensity-slider[data-uuid="${uuid}"]`);
        if (sliderEl) sliderEl.value = Math.round(Math.min(v, 10) * 100);
        LightManager.updateLight(entry.node, { intensity: v });
      });
    });

    listEl.querySelectorAll('.lt-shadow-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const uuid  = btn.dataset.uuid;
        const entry = LightManager.getSceneLights().find(e => e.node.uuid === uuid);
        if (!entry) return;
        const on = !btn.classList.contains('active');
        btn.classList.toggle('active', on);
        btn.setAttribute('aria-checked', on);
        btn.textContent = on ? 'On' : 'Off';
        // castShadow prop drives userData.shadowEnabled in updateLight
        LightManager.updateLight(entry.node, { castShadow: on });
      });
    });
  }

  // ── Camera list ───────────────────────────────────────────────────────────

  function refreshCameraList() {
    const listEl     = document.getElementById('cam-camera-list');
    const countBadge = document.getElementById('cam-camera-count');
    if (!listEl) return;

    const cameras = SceneManager.getCameraObjects();
    if (countBadge) countBadge.textContent = cameras.length;

    if (cameras.length === 0) {
      listEl.innerHTML = '<div class="lt-empty" id="cam-no-cameras">No cameras in scene.</div>';
      return;
    }

    listEl.innerHTML = cameras.map(root => {
      const uuid        = root.uuid;
      const name        = root.name || 'Camera';
      const isActive    = (typeof SceneCameraSystem !== 'undefined') &&
                          SceneCameraSystem.isPreviewActive() &&
                          SceneCameraSystem.getPreviewRoot() === root;
      return `
<div class="lt-light-row cam-row${isActive ? ' cam-row-active' : ''}" data-uuid="${uuid}">
  <div class="lt-light-row-header">
    <svg class="lt-light-type-icon" width="12" height="12" viewBox="0 0 12 12" fill="none">
      <rect x="1" y="3" width="6" height="6" rx="0.8" stroke="currentColor" stroke-width="1"/>
      <path d="M7 5L10.5 3.5v5L7 7" stroke="currentColor" stroke-width="1" stroke-linejoin="round"/>
    </svg>
    <span class="lt-light-name">${name}</span>
    <span class="lt-light-badge" style="background:rgba(77,142,245,0.15);color:#4d8ef5">${isActive ? 'LIVE' : 'CAM'}</span>
    <div class="lt-light-row-actions">
      <button class="lt-light-action-btn cam-enter-btn" data-uuid="${uuid}" title="${isActive ? 'Exit camera view' : 'Enter camera view'}">
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
          ${isActive
            ? '<rect x="2" y="2" width="2.5" height="6" rx="0.4" fill="currentColor"/><rect x="5.5" y="2" width="2.5" height="6" rx="0.4" fill="currentColor"/>'
            : '<path d="M2.5 2L8 5L2.5 8V2Z" fill="currentColor"/>'}
        </svg>
      </button>
      <button class="lt-light-action-btn lt-del-btn cam-del-btn" data-uuid="${uuid}" title="Delete camera">
        <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
          <path d="M1.5 1.5L6.5 6.5M6.5 1.5L1.5 6.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>
        </svg>
      </button>
    </div>
  </div>
</div>`;
    }).join('');

    // Wire enter/exit preview buttons
    listEl.querySelectorAll('.cam-enter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (typeof SceneCameraSystem === 'undefined') return;
        const uuid = btn.dataset.uuid;
        const root = SceneManager.getCameraObjects().find(o => o.uuid === uuid);
        if (!root) return;
        if (SceneCameraSystem.isPreviewActive() && SceneCameraSystem.getPreviewRoot() === root) {
          SceneCameraSystem.exitCamera();
        } else {
          SceneCameraSystem.enterCamera(root);
        }
        refreshCameraList();
      });
    });

    // Wire delete buttons
    listEl.querySelectorAll('.cam-del-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (typeof SceneCameraSystem === 'undefined') return;
        const uuid = btn.dataset.uuid;
        const root = SceneManager.getCameraObjects().find(o => o.uuid === uuid);
        if (root) SceneCameraSystem.removeCamera(root);
      });
    });
  }

  // ── Public init ───────────────────────────────────────────────────────────
  function init() {
    _initCollapsibles();
    _initAddButtons();
    _initEnvControls();
    _initShadowControls();
    _initPostControls();

    // Re-render list when LightManager signals any change (add/remove/update/toggle).
    // lightmanager:changed is the single authoritative signal — do NOT subscribe to
    // scene:objectAdded/Removed here, that causes a double-refresh on every light add.
    EventBus.on('lightmanager:changed', () => refreshList());

    // Re-render camera list on any camera add/remove/preview change.
    EventBus.on('cameramanager:changed', () => refreshCameraList());
  }

  // NOTE: Serialisation of light settings is owned by SceneIO → LightManager.
  // LightSystem is UI-only; it has no serialisation responsibility.

  return { init, refreshList, refreshCameraList };
})();


// ══════════════════════════════════════════════════════
//  SceneCameraSystem
//  Manages scene cameras (separate from the viewport editor camera).
//
//  Architecture
//  ─────────────
//  Each scene camera = a CameraRoot (Object3D) that:
//    • is added via SceneManager.addSceneObject(root, 'camera')
//    • contains a THREE.PerspectiveCamera (the actual render camera)
//    • contains a visual icon mesh (non-selectable) so it's visible in-scene
//    • holds userData.sceneObjectType = 'camera'
//    • is the object that gets selected, moved, rotated via TransformControls
//
//  The PerspectiveCamera always stays at local (0,0,0) of the root and
//  inherits all transforms from the root. This guarantees zero desync.
//
//  Preview mode (Enter Camera)
//  ────────────────────────────
//  Swaps CameraManager.getActiveCamera() → returns the scene PerspCamera.
//  The editor orbit controls remain bound to the viewport camera but are
//  visually suppressed (banner shows "Exit Camera").
//  On exit, the viewport camera is restored with no side-effects.
// ══════════════════════════════════════════════════════
