'use strict';
const InputControls = (() => {
  function init(){
    _initTransformButtons();
    _initEditMode();
    _initEditSubtoolbar();
    _initCameraButtons();
    _initAddButtons();
    _initContextMenu();
    _initKeyboard();
    _initFocusButton();
    _initToolsDropdown();
  }

  function _setMode(mode){
    if(EditModeSystem.isActive()){
      if(mode==='translate'||mode==='rotate'||mode==='scale'){
        EditModeSystem.setEditTransformMode(mode);
      }
      return;
    }
    TransformControlsModule.setMode(mode);
    const labels={translate:'MOVE',rotate:'ROTATE',scale:'SCALE'};
    UISystem.showModePill(labels[mode]||mode.toUpperCase());
    ['translate','rotate','scale'].forEach(m=>{
      const ids={translate:'btn-move',rotate:'btn-rotate',scale:'btn-scale'};
      const el=document.getElementById(ids[m]); if(el) el.classList.toggle('active',m===mode);
    });
  }

  function _initTransformButtons(){
    const map={'btn-move':'translate','btn-rotate':'rotate','btn-scale':'scale'};
    Object.entries(map).forEach(([id,mode])=>{ const el=document.getElementById(id); if(el)el.addEventListener('click',()=>_setMode(mode)); });
  }

  function _toggleEditMode(){
    const selected=SelectionSystem.getSelected();
    // Cannot enter edit mode on camera or light scene nodes
    if(selected && selected.userData.sceneObjectType) { UISystem.showModePill('NOT A MESH'); return; }
    if(EditModeSystem.isActive()){
      if(LoopCutSystem.isActive()) {
        LoopCutSystem.cancel();
        if(window._toolsDropdown) window._toolsDropdown.setLoopCutActive(false);
      }
      EditModeSystem.exit();
      const btn=document.getElementById('btn-edit-mode');
      if(btn){ btn.classList.remove('edit-active'); }
      UISystem.showModePill('OBJECT MODE');
      // Re-apply current object mode tool so gizmo/toolbar are consistent
      _setMode(TransformControlsModule.getMode());
      UISystem.refreshProps(selected);
      UISystem.updateStatus(selected);
    } else {
      if(!selected){ UISystem.showModePill('NO SELECTION'); return; }
      EditModeSystem.enter(selected);
      const btn=document.getElementById('btn-edit-mode');
      if(btn){ btn.classList.add('edit-active'); }
      // Sync main toolbar to edit translate mode (unified toolbar)
      EditModeSystem.setEditTransformMode('translate');
      UISystem.showModePill('EDIT MODE',true);
      UISystem.updateStatus(selected);
      document.getElementById('ctx-edit-toggle').textContent='Exit Edit Mode';
    }
    UISystem.refreshOutliner();
  }

  function _initEditMode(){
    const btn=document.getElementById('btn-edit-mode');
    if(btn) btn.addEventListener('click',_toggleEditMode);
  }

  function _initEditSubtoolbar(){
    // Element type buttons
    ['vert','edge','face'].forEach(type=>{
      const id='elem-'+type;
      const el=document.getElementById(id);
      if(el) el.addEventListener('click',()=>{ if(EditModeSystem.isActive()) EditModeSystem.setElemType(type); _updateExtrudeBtn(); });
    });
    // X-Ray
    const xray=document.getElementById('btn-xray');
    if(xray) xray.addEventListener('click',()=>{ if(EditModeSystem.isActive()) EditModeSystem.toggleXray(); });
    // Multi-select toggle
    const msBtn = document.getElementById('btn-multiselect');
    if(msBtn) msBtn.addEventListener('click', () => {
      EditModeSystem._multiSelectActive = !EditModeSystem._multiSelectActive;
      msBtn.classList.toggle('active', EditModeSystem._multiSelectActive);
    });
    // Also reset multi-select when exiting edit mode
    EventBus.on('editmode:changed', (active) => {
      if(!active) {
        EditModeSystem._multiSelectActive = false;
        if(msBtn) msBtn.classList.remove('active');
      }
    });
    // Select dropdown
    _initSelectDropdown();
    // Extrude
    const ext=document.getElementById('btn-extrude');
    if(ext) ext.addEventListener('click',()=>{
      if(!EditModeSystem.isActive()) return;
      if(EditModeSystem.getElemType()!=='face') return;
      if(EditModeSystem.getSelected().size===0) return;
      EditModeSystem.extrudeFaces();
    });
    // Inset
    const insetBtn=document.getElementById('btn-inset');
    if(insetBtn) insetBtn.addEventListener('click',()=>{
      if(!EditModeSystem.isActive()) return;
      if(EditModeSystem.getElemType()!=='face') return;
      if(EditModeSystem.getSelected().size===0) return;
      EditModeSystem.startInset();
    });
    // Bevel
    const bevelBtn=document.getElementById('btn-bevel');
    if(bevelBtn) bevelBtn.addEventListener('click',()=>{
      if(!EditModeSystem.isActive()) return;
      const et=EditModeSystem.getElemType();
      if(et!=='edge'&&et!=='face') return;
      if(EditModeSystem.getSelected().size===0) return;
      EditModeSystem.startBevel();
    });
    // Loop Cut
    const loopCutBtn=document.getElementById('btn-loopcut');
    if(loopCutBtn) loopCutBtn.addEventListener('click',()=>{
      if(!EditModeSystem.isActive()) return;
      if(LoopCutSystem.isActive()){
        LoopCutSystem.cancel();
        if(window._toolsDropdown) window._toolsDropdown.setLoopCutActive(false);
        return;
      }
      LoopCutSystem.start();
      if(window._toolsDropdown) window._toolsDropdown.setLoopCutActive(true);
    });
    // Undo
    const undoBtn=document.getElementById('btn-undo');
    if(undoBtn) undoBtn.addEventListener('click',()=>{
      if(EditModeSystem.isActive()){
        if(!UndoHistory.canUndo()) return;
        const state=UndoHistory.undo(EditModeSystem.getMeshData(),EditModeSystem.getElemType(),EditModeSystem.getSelected());
        if(state) EditModeSystem.applyHistoryState(state);
      } else {
        const obj=SelectionSystem.getSelected();
        if(obj && ObjectUndoHistory.canUndo()) ObjectUndoHistory.undo(obj);
      }
    });
    // Redo
    const redoBtn=document.getElementById('btn-redo');
    if(redoBtn) redoBtn.addEventListener('click',()=>{
      if(EditModeSystem.isActive()){
        if(!UndoHistory.canRedo()) return;
        const state=UndoHistory.redo(EditModeSystem.getMeshData(),EditModeSystem.getElemType(),EditModeSystem.getSelected());
        if(state) EditModeSystem.applyHistoryState(state);
      } else {
        const obj=SelectionSystem.getSelected();
        if(obj && ObjectUndoHistory.canRedo()) ObjectUndoHistory.redo(obj);
      }
    });
  }

  function _updateExtrudeBtn(){
    const btn=document.getElementById('btn-extrude');
    const iBtn=document.getElementById('btn-inset');
    const bBtn=document.getElementById('btn-bevel');
    const isFace=EditModeSystem.isActive()&&EditModeSystem.getElemType()==='face';
    const isEdgeOrFace=EditModeSystem.isActive()&&(EditModeSystem.getElemType()==='edge'||EditModeSystem.getElemType()==='face');
    if(btn) btn.disabled=!isFace;
    if(iBtn) iBtn.disabled=!isFace;
    if(bBtn) bBtn.disabled=!isEdgeOrFace;
  }

  // ── Select Dropdown ──────────────────────────────────────────────────────
  function _initSelectDropdown(){
    const trigger = document.getElementById('sel-dropdown-trigger');
    const panel   = document.getElementById('sel-dropdown-panel');
    if(!trigger || !panel) return;

    let _boxModeActive   = false;
    let _lassoModeActive = false;

    function _open()   { trigger.classList.add('open');  panel.classList.add('open'); }
    function _close()  { trigger.classList.remove('open'); panel.classList.remove('open'); }
    function _toggle() { trigger.classList.contains('open') ? _close() : _open(); }

    trigger.addEventListener('click', (e)=>{ e.stopPropagation(); _toggle(); });
    document.addEventListener('click', (e)=>{
      if(!document.getElementById('sel-dropdown-wrap')?.contains(e.target)) _close();
    });
    document.addEventListener('touchstart', (e)=>{
      if(!document.getElementById('sel-dropdown-wrap')?.contains(e.target)) _close();
    }, {passive:true});

    // ── Box Select mode ────────────────────────────────────────────────────
    function _startBoxSelect() {
      if(!EditModeSystem.isActive()) return;
      _boxModeActive = true;
      trigger.classList.add('tool-active');
      document.getElementById('sel-box')?.classList.add('tool-running');
      CameraManager.setGizmoCaptured(true); // freeze camera

      const canvas = EditModeSystem.getCanvas();
      let start = null, rect = document.getElementById('box-select-rect');
      let activeTouchId = null;

      function _showRect(x1, y1, x2, y2) {
        const vp = canvas.getBoundingClientRect();
        const rx = Math.min(x1,x2) - vp.left;
        const ry = Math.min(y1,y2) - vp.top;
        const w  = Math.abs(x2-x1);
        const h  = Math.abs(y2-y1);
        if(rect) { rect.style.display='block'; rect.style.left=rx+'px'; rect.style.top=ry+'px'; rect.style.width=w+'px'; rect.style.height=h+'px'; }
      }

      // ── Mouse handlers ──
      function _onDown(e) {
        if(e.button !== 0) { _endBox(); return; }
        start = {x: e.clientX, y: e.clientY};
      }
      function _onMove(e) {
        if(!start || !(e.buttons & 1)) return;
        _showRect(start.x, start.y, e.clientX, e.clientY);
      }
      function _onUp(e) {
        if(!start) return;
        if(rect) rect.style.display='none';
        const additive = EditModeSystem._multiSelectActive || false;
        const ms = EditModeSystem.getMeshData();
        if(ms) _applyExternalBoxSelect(start.x, start.y, e.clientX, e.clientY, additive);
        _endBox();
      }

      // ── Touch handlers ──
      function _onTouchStart(e) {
        if(activeTouchId !== null) return; // already tracking one finger
        if(e.touches.length < 1) return;
        const t = e.touches[0];
        activeTouchId = t.identifier;
        start = {x: t.clientX, y: t.clientY};
        e.preventDefault();
      }
      function _onTouchMove(e) {
        if(!start || activeTouchId === null) return;
        let t = null;
        for(let i=0;i<e.touches.length;i++){ if(e.touches[i].identifier===activeTouchId){t=e.touches[i];break;} }
        if(!t) return;
        _showRect(start.x, start.y, t.clientX, t.clientY);
        e.preventDefault();
      }
      function _onTouchEnd(e) {
        if(!start || activeTouchId === null) return;
        let t = null;
        for(let i=0;i<e.changedTouches.length;i++){ if(e.changedTouches[i].identifier===activeTouchId){t=e.changedTouches[i];break;} }
        if(!t) return;
        if(rect) rect.style.display='none';
        const additive = EditModeSystem._multiSelectActive || false;
        const ms = EditModeSystem.getMeshData();
        if(ms) _applyExternalBoxSelect(start.x, start.y, t.clientX, t.clientY, additive);
        _endBox();
      }

      function _endBox() {
        _boxModeActive = false;
        trigger.classList.remove('tool-active');
        document.getElementById('sel-box')?.classList.remove('tool-running');
        CameraManager.setGizmoCaptured(false);
        if(rect) rect.style.display='none';
        canvas.removeEventListener('mousedown',  _onDown);
        window.removeEventListener('mousemove',  _onMove);
        window.removeEventListener('mouseup',    _onUp);
        canvas.removeEventListener('touchstart', _onTouchStart);
        window.removeEventListener('touchmove',  _onTouchMove);
        window.removeEventListener('touchend',   _onTouchEnd);
      }

      canvas.addEventListener('mousedown',  _onDown);
      window.addEventListener('mousemove',  _onMove);
      window.addEventListener('mouseup',    _onUp);
      canvas.addEventListener('touchstart', _onTouchStart, {passive:false});
      window.addEventListener('touchmove',  _onTouchMove,  {passive:false});
      window.addEventListener('touchend',   _onTouchEnd,   {passive:true});
    }

    // Re-uses EditModeSystem's internal logic via a wrapper
    function _applyExternalBoxSelect(x1, y1, x2, y2, additive) {
      const md = EditModeSystem.getMeshData();
      const mesh = EditModeSystem.getMesh();
      const cam  = EditModeSystem.getCamera();
      const canvas = EditModeSystem.getCanvas();
      if(!md || !mesh || !cam || !canvas) return;

      const minX=Math.min(x1,x2), maxX=Math.max(x1,x2);
      const minY=Math.min(y1,y2), maxY=Math.max(y1,y2);
      const sel  = EditModeSystem.getSelected();
      const type = EditModeSystem.getElemType();
      if(!additive) { sel.clear(); }

      function _ws(wx,wy,wz) {
        const v = new THREE.Vector4(wx,wy,wz,1).applyMatrix4(mesh.matrixWorld);
        const vp2 = new THREE.Vector3(v.x/v.w, v.y/v.w, v.z/v.w).project(cam);
        const r = canvas.getBoundingClientRect();
        return { x:(vp2.x+1)*0.5*r.width+r.left, y:(-vp2.y+1)*0.5*r.height+r.top, vz:vp2.z };
      }

      if(type==='vert') {
        md.verts.forEach((v,i) => {
          const s = _ws(v.x,v.y,v.z);
          if(s.vz>1) return;
          if(s.x>=minX&&s.x<=maxX&&s.y>=minY&&s.y<=maxY) sel.add(i);
        });
      } else if(type==='edge') {
        md.edges.forEach((e,i) => {
          const va=md.verts[e.a], vb=md.verts[e.b];
          const mid = _ws((va.x+vb.x)/2,(va.y+vb.y)/2,(va.z+vb.z)/2);
          if(mid.vz>1) return;
          if(mid.x>=minX&&mid.x<=maxX&&mid.y>=minY&&mid.y<=maxY) sel.add(i);
        });
      } else {
        md.faces.forEach((f,i) => {
          const s = _ws(f.center.x,f.center.y,f.center.z);
          if(s.vz>1) return;
          if(s.x>=minX&&s.x<=maxX&&s.y>=minY&&s.y<=maxY) sel.add(i);
        });
      }
      // Trigger UI refresh: save new selection, clear via public API, re-add
      const saved = new Set(sel);
      EditModeSystem.selectNone();
      saved.forEach(i=>EditModeSystem.getSelected().add(i));
    }

    // ── Lasso Select mode ─────────────────────────────────────────────────
    function _startLassoSelect() {
      if(!EditModeSystem.isActive()) return;
      _lassoModeActive = true;
      trigger.classList.add('tool-active');
      document.getElementById('sel-lasso')?.classList.add('tool-running');
      CameraManager.setGizmoCaptured(true);

      const canvas   = EditModeSystem.getCanvas();
      const lassoEl  = document.getElementById('lasso-canvas');
      if(!lassoEl) { _endLasso(); return; }

      // Size lasso canvas to match viewport
      const vp = canvas.getBoundingClientRect();
      lassoEl.width  = vp.width;
      lassoEl.height = vp.height;
      lassoEl.classList.add('active');
      const ctx = lassoEl.getContext('2d');

      let path = []; // [{x,y}] in viewport-relative coords
      let drawing = false;
      let activeTouchId = null;

      function _draw() {
        ctx.clearRect(0,0,lassoEl.width,lassoEl.height);
        if(path.length < 2) return;
        ctx.beginPath();
        ctx.moveTo(path[0].x, path[0].y);
        path.forEach(p=>ctx.lineTo(p.x, p.y));
        ctx.closePath();
        ctx.fillStyle   = 'rgba(255,124,42,0.08)';
        ctx.strokeStyle = 'rgba(255,124,42,0.7)';
        ctx.lineWidth   = 1.2;
        ctx.setLineDash([4,3]);
        ctx.fill();
        ctx.stroke();
      }

      function _ptInPoly(px, py, poly) {
        let inside = false;
        for(let i=0,j=poly.length-1;i<poly.length;j=i++) {
          const xi=poly[i].x, yi=poly[i].y, xj=poly[j].x, yj=poly[j].y;
          const intersect=((yi>py)!==(yj>py))&&(px<(xj-xi)*(py-yi)/(yj-yi)+xi);
          if(intersect) inside=!inside;
        }
        return inside;
      }

      // ── Mouse handlers ──
      function _onDown(e) {
        if(e.button!==0) { _endLasso(); return; }
        drawing = true;
        path = [];
        const r = lassoEl.getBoundingClientRect();
        path.push({x:e.clientX-r.left, y:e.clientY-r.top});
        e.preventDefault(); e.stopPropagation();
      }
      function _onMove(e) {
        if(!drawing) return;
        const r = lassoEl.getBoundingClientRect();
        path.push({x:e.clientX-r.left, y:e.clientY-r.top});
        _draw();
        e.preventDefault();
      }
      function _onUp(e) {
        if(!drawing) return;
        drawing = false;
        const additive = EditModeSystem._multiSelectActive || false;
        _applyLasso(path, additive);
        _endLasso();
      }

      // ── Touch handlers ──
      function _onTouchStart(e) {
        if(activeTouchId !== null) return;
        const t = e.touches[0];
        activeTouchId = t.identifier;
        drawing = true;
        path = [];
        const r = lassoEl.getBoundingClientRect();
        path.push({x:t.clientX-r.left, y:t.clientY-r.top});
        e.preventDefault(); e.stopPropagation();
      }
      function _onTouchMove(e) {
        if(!drawing || activeTouchId === null) return;
        let t = null;
        for(let i=0;i<e.touches.length;i++){ if(e.touches[i].identifier===activeTouchId){t=e.touches[i];break;} }
        if(!t) return;
        const r = lassoEl.getBoundingClientRect();
        path.push({x:t.clientX-r.left, y:t.clientY-r.top});
        _draw();
        e.preventDefault();
      }
      function _onTouchEnd(e) {
        if(!drawing || activeTouchId === null) return;
        let found = false;
        for(let i=0;i<e.changedTouches.length;i++){ if(e.changedTouches[i].identifier===activeTouchId){found=true;break;} }
        if(!found) return;
        drawing = false;
        activeTouchId = null;
        const additive = EditModeSystem._multiSelectActive || false;
        _applyLasso(path, additive);
        _endLasso();
      }

      function _endLasso() {
        _lassoModeActive = false;
        trigger.classList.remove('tool-active');
        document.getElementById('sel-lasso')?.classList.remove('tool-running');
        CameraManager.setGizmoCaptured(false);
        lassoEl.classList.remove('active');
        ctx.clearRect(0,0,lassoEl.width,lassoEl.height);
        lassoEl.removeEventListener('mousedown',  _onDown);
        window.removeEventListener('mousemove',   _onMove);
        window.removeEventListener('mouseup',     _onUp);
        lassoEl.removeEventListener('touchstart', _onTouchStart);
        window.removeEventListener('touchmove',   _onTouchMove);
        window.removeEventListener('touchend',    _onTouchEnd);
      }

      lassoEl.addEventListener('mousedown',  _onDown);
      window.addEventListener('mousemove',   _onMove);
      window.addEventListener('mouseup',     _onUp);
      lassoEl.addEventListener('touchstart', _onTouchStart, {passive:false});
      window.addEventListener('touchmove',   _onTouchMove,  {passive:false});
      window.addEventListener('touchend',    _onTouchEnd,   {passive:true});
    }

    function _applyLasso(poly, additive) {
      const md = EditModeSystem.getMeshData();
      const mesh = EditModeSystem.getMesh();
      const cam  = EditModeSystem.getCamera();
      const canvas = EditModeSystem.getCanvas();
      if(!md||!mesh||!cam||!canvas||poly.length<3) return;

      const sel  = EditModeSystem.getSelected();
      const type = EditModeSystem.getElemType();
      if(!additive) sel.clear();

      const lassoEl = document.getElementById('lasso-canvas');
      const lr = lassoEl ? lassoEl.getBoundingClientRect() : canvas.getBoundingClientRect();

      function _ws(wx,wy,wz) {
        const v = new THREE.Vector4(wx,wy,wz,1).applyMatrix4(mesh.matrixWorld);
        const vp2 = new THREE.Vector3(v.x/v.w,v.y/v.w,v.z/v.w).project(cam);
        return {
          x:(vp2.x+1)*0.5*lr.width,
          y:(-vp2.y+1)*0.5*lr.height,
          vz:vp2.z
        };
      }

      if(type==='vert') {
        md.verts.forEach((v,i)=>{ const s=_ws(v.x,v.y,v.z); if(s.vz<=1&&_ptInPoly(s.x,s.y,poly)) sel.add(i); });
      } else if(type==='edge') {
        md.edges.forEach((e,i)=>{ const va=md.verts[e.a],vb=md.verts[e.b]; const s=_ws((va.x+vb.x)/2,(va.y+vb.y)/2,(va.z+vb.z)/2); if(s.vz<=1&&_ptInPoly(s.x,s.y,poly)) sel.add(i); });
      } else {
        md.faces.forEach((f,i)=>{ const s=_ws(f.center.x,f.center.y,f.center.z); if(s.vz<=1&&_ptInPoly(s.x,s.y,poly)) sel.add(i); });
      }

      // Trigger UI refresh via a harmless selectNone + re-add
      const saved = new Set(sel);
      EditModeSystem.selectNone();
      saved.forEach(i=>EditModeSystem.getSelected().add(i));
    }

    // ── Wire dropdown items ────────────────────────────────────────────────
    panel.querySelectorAll('.sel-menu-item').forEach(item=>{
      item.addEventListener('click', (e)=>{
        e.stopPropagation();
        const action = item.dataset.action;
        _close();

        if(!EditModeSystem.isActive()) return;

        switch(action) {
          case 'box':
            setTimeout(_startBoxSelect, 60);
            break;
          case 'lasso':
            setTimeout(_startLassoSelect, 60);
            break;
          case 'inverse':
            EditModeSystem.selectInverse();
            break;
          case 'all':
            EditModeSystem.selectAll();
            break;
          case 'none':
            EditModeSystem.selectNone();
            break;
        }
      });
    });
  }

  // ── Modeling tools dropdown ───────────────────────────────────────────────
  function _initToolsDropdown(){
    const trigger = document.getElementById('tools-dropdown-trigger');
    const panel   = document.getElementById('tools-dropdown-panel');
    if(!trigger || !panel) return;

    function _open()  { trigger.classList.add('open'); panel.classList.add('open'); }
    function _close() { trigger.classList.remove('open'); panel.classList.remove('open'); }
    function _toggle(){ trigger.classList.contains('open') ? _close() : _open(); }

    // Toggle on trigger click/tap
    trigger.addEventListener('click', (e)=>{ e.stopPropagation(); _toggle(); });

    // Close when clicking outside
    document.addEventListener('click', (e)=>{
      if(!document.getElementById('tools-dropdown-wrap').contains(e.target)) _close();
    });
    document.addEventListener('touchstart', (e)=>{
      if(!document.getElementById('tools-dropdown-wrap').contains(e.target)) _close();
    }, { passive:true });

    // Close after selecting a tool (give the button click a tick to fire first)
    panel.querySelectorAll('.tools-menu-item').forEach(item=>{
      item.addEventListener('click', ()=>{ if(!item.disabled) setTimeout(_close, 80); });
    });

    // ── Loop Cut active indicator on trigger ──────────────────────────────
    // We expose a small helper so the LoopCut system can ping the trigger.
    window._toolsDropdown = {
      setLoopCutActive(on) {
        const btn = document.getElementById('btn-loopcut');
        if(btn) btn.classList.toggle('tool-active', on);
        const trigger = document.getElementById('tools-dropdown-trigger');
        if(trigger) trigger.classList.toggle('tool-running', on);
      }
    };
  }

  function _initSnapDropdown(){
    const trigger = document.getElementById('snap-dropdown-trigger');
    const panel   = document.getElementById('snap-dropdown-panel');
    if(!trigger || !panel) return;

    // Snap state: enabled flag + per-type toggles
    // _snapEnabled mirrors SnapSystem._enabled
    // _snapTypes tracks which types are individually checked
    const _snapTypes = { grid:true, vert:false, edge:false };
    let _snapEnabled = false;

    function _open()   { trigger.classList.add('open');  panel.classList.add('open'); }
    function _close()  { trigger.classList.remove('open'); panel.classList.remove('open'); }
    function _toggle() { trigger.classList.contains('open') ? _close() : _open(); }

    trigger.addEventListener('click', (e)=>{ e.stopPropagation(); _toggle(); });
    document.addEventListener('click', (e)=>{
      if(!document.getElementById('snap-dropdown-wrap')?.contains(e.target)) _close();
    });
    document.addEventListener('touchstart', (e)=>{
      if(!document.getElementById('snap-dropdown-wrap')?.contains(e.target)) _close();
    }, {passive:true});

    function _syncDropdownUI() {
      // Master toggle
      const masterBtn = document.getElementById('snap-toggle-master');
      if(masterBtn) {
        masterBtn.classList.toggle('toggled', _snapEnabled);
        masterBtn.setAttribute('aria-checked', _snapEnabled);
      }
      // Trigger appearance
      trigger.classList.toggle('snap-active', _snapEnabled);

      // Sub-item disabled state when master is off
      ['grid','vert','edge'].forEach(t => {
        const btn = document.getElementById('snap-toggle-'+t);
        if(!btn) return;
        btn.classList.toggle('toggled', _snapTypes[t]);
        btn.setAttribute('aria-checked', _snapTypes[t]);
        btn.classList.toggle('snap-disabled', !_snapEnabled);
      });
    }

    function _applySnapToSystem() {
      // Determine active type: first enabled one, fallback to grid
      let activeType = 'grid';
      if(_snapEnabled) {
        if(_snapTypes.grid) activeType = 'grid';
        else if(_snapTypes.vert) activeType = 'vert';
        else if(_snapTypes.edge) activeType = 'edge';
      }
      // Sync SnapSystem state
      if(_snapEnabled !== SnapSystem.isEnabled()) SnapSystem.toggle();
      SnapSystem.setType(activeType);
      _syncDropdownUI();
    }

    // Master toggle button
    const masterBtn = document.getElementById('snap-toggle-master');
    if(masterBtn) masterBtn.addEventListener('click', (e)=>{
      e.stopPropagation();
      _snapEnabled = !_snapEnabled;
      _applySnapToSystem();
    });

    // Per-type toggles
    ['grid','vert','edge'].forEach(t => {
      const btn = document.getElementById('snap-toggle-'+t);
      if(!btn) return;
      btn.addEventListener('click', (e)=>{
        e.stopPropagation();
        if(!_snapEnabled) return; // master off — ignore
        _snapTypes[t] = !_snapTypes[t];
        // When enabling a type, set it as the active snap type
        if(_snapTypes[t]) {
          // Apply this type to SnapSystem immediately
          SnapSystem.setType(t);
        } else {
          // If we just turned off the current type, pick another
          const currentType = SnapSystem.getType();
          if(currentType === t) {
            const fallback = ['grid','vert','edge'].find(s => _snapTypes[s]);
            if(fallback) SnapSystem.setType(fallback);
          }
        }
        _syncDropdownUI();
      });
    });

    // Initial sync
    _syncDropdownUI();
  }

  function _initViewDropdown(){
    const trigger = document.getElementById('view-dropdown-trigger');
    const panel   = document.getElementById('view-dropdown-panel');
    const label   = document.getElementById('view-current-label');
    if(!trigger || !panel) return;

    const LABELS = { persp:'Persp', top:'Top', bottom:'Bottom', front:'Front', back:'Back', right:'Right', left:'Left' };

    function _open()   { trigger.classList.add('open');  panel.classList.add('open'); }
    function _close()  { trigger.classList.remove('open'); panel.classList.remove('open'); }
    function _toggle() { trigger.classList.contains('open') ? _close() : _open(); }

    trigger.addEventListener('click', (e)=>{ e.stopPropagation(); _toggle(); });
    document.addEventListener('click', (e)=>{
      if(!document.getElementById('view-dropdown-wrap')?.contains(e.target)) _close();
    });
    document.addEventListener('touchstart', (e)=>{
      if(!document.getElementById('view-dropdown-wrap')?.contains(e.target)) _close();
    }, {passive:true});

    panel.querySelectorAll('.view-menu-item').forEach(item=>{
      item.addEventListener('click', (e)=>{
        e.stopPropagation();
        const preset = item.dataset.preset;
        CameraManager.setViewPreset(preset);
        // Update label and active state
        if(label) label.textContent = LABELS[preset] || preset;
        panel.querySelectorAll('.view-menu-item').forEach(i=>i.classList.remove('active'));
        item.classList.add('active');
        setTimeout(_close, 60);
      });
    });
  }

  function _initCameraButtons(){
    ['persp','top','front','right'].forEach(p=>{ const el=document.getElementById(`btn-cam-${p}`); if(el)el.addEventListener('click',()=>CameraManager.setViewPreset(p)); });
    const snap=document.getElementById('btn-snap');
    if(snap) snap.addEventListener('click',()=>{ SnapSystem.toggle(); });
    // ── Snap dropdown ────────────────────────────────────────────────────────
    _initSnapDropdown();
    // ── View dropdown ─────────────────────────────────────────────────────────
    _initViewDropdown();
  }

  function _initFocusButton(){
    const el=document.getElementById('btn-focus');
    if(el) el.addEventListener('click',()=>{
      if(EditModeSystem.isActive()){ CameraManager.focusOnObject(EditModeSystem.getMesh()); }
      else { CameraManager.focusOnObject(SelectionSystem.getSelected()); }
    });
  }

  function _initAddButtons(){
    document.querySelectorAll('.add-btn[data-prim], .add-btn-v2[data-prim]').forEach(btn=>{
      btn.addEventListener('click',()=>{
        if(EditModeSystem.isActive()) return;
        const mesh=ObjectManager.createPrimitive(btn.dataset.prim);
        SceneManager.addObject(mesh);
        if (typeof LightManager !== 'undefined') LightManager.configureMeshShadows(mesh);
        SelectionSystem.selectObject(mesh);
        // UI refresh is handled by scene:objectAdded + selection:changed event handlers.
        // Switch to hierarchy tab after adding
        if(typeof LeftSidebarTabs !== 'undefined') LeftSidebarTabs.activate('left-tab-btn-hierarchy');
      });
    });
  }

  function _initContextMenu(){
    const menu=document.getElementById('context-menu'), canvas=document.getElementById('viewport-canvas');
    canvas.addEventListener('contextmenu',e=>{ e.preventDefault(); if(EditModeSystem.isActive()) return; menu.style.display='block'; menu.style.left=e.clientX+'px'; menu.style.top=e.clientY+'px'; });
    document.addEventListener('click',()=>{ menu.style.display='none'; });
    const ctxFocus=document.getElementById('ctx-focus');
    const ctxDup=document.getElementById('ctx-duplicate');
    const ctxDel=document.getElementById('ctx-delete');
    const ctxEdit=document.getElementById('ctx-edit-toggle');
    if(ctxFocus)ctxFocus.addEventListener('click',()=>CameraManager.focusOnObject(SelectionSystem.getSelected()));
    if(ctxDup)ctxDup.addEventListener('click',_duplicateSelected);
    if(ctxDel)ctxDel.addEventListener('click',()=>HierarchySystem.deleteSelected());
    if(ctxEdit)ctxEdit.addEventListener('click',_toggleEditMode);
  }

  function _deleteSelected(){
    if(EditModeSystem.isActive()) return;
    const obj=SelectionSystem.getSelected(); if(!obj) return;
    // Camera/light scene nodes: route through their owning systems for proper cleanup
    // (shadow map disposal for lights, preview exit for cameras).
    if(obj.userData.sceneObjectType === 'light') {
      if(typeof LightManager !== 'undefined') LightManager.removeLight(obj);
      SelectionSystem.clearSelection();
      UISystem.refreshProps(null); UISystem.updateStatus(null);
      return;
    }
    if(obj.userData.sceneObjectType === 'camera') {
      if(typeof SceneCameraSystem !== 'undefined') SceneCameraSystem.removeCamera(obj);
      else SceneManager.removeSceneObject(obj);
      SelectionSystem.clearSelection();
      UISystem.refreshProps(null); UISystem.updateStatus(null);
      return;
    }
    TransformControlsModule.detach(); SceneManager.removeObject(obj);
    SelectionSystem.clearSelection(); UISystem.refreshProps(null); UISystem.updateStatus(null);
  }

  function _duplicateSelected(){
    if(EditModeSystem.isActive()) return;
    const obj=SelectionSystem.getSelected(); if(!obj) return;

    // ── Duplicate a scene camera ──────────────────────────────────────────
    if(obj.userData.sceneObjectType === 'camera') {
      if(typeof SceneCameraSystem === 'undefined') return;
      const srcCam = obj.userData._perspCamera;
      const entry = SceneCameraSystem.addCamera({
        name: obj.name + '_copy',
        pos:  { x: obj.position.x + 1.2, y: obj.position.y, z: obj.position.z },
        fov:  srcCam ? srcCam.fov  : 60,
        near: srcCam ? srcCam.near : 0.1,
        far:  srcCam ? srcCam.far  : 200,
      });
      if(entry) {
        entry.root.rotation.copy(obj.rotation);
      }
      return;
    }

    // ── Duplicate a scene light ───────────────────────────────────────────
    if(obj.userData.sceneObjectType === 'light') {
      if(typeof LightManager === 'undefined') return;
      const lightType = obj.userData.lightType || 'point';
      LightManager.addLight(lightType, {
        color:       obj.userData.lightColor    || '#ffffff',
        intensity:   obj.userData.lightIntensity !== undefined ? obj.userData.lightIntensity : 1,
        castShadow:  !!obj.userData.shadowEnabled,
        position:    { x: obj.position.x + 1.2, y: obj.position.y, z: obj.position.z },
        rotation:    { x: obj.rotation.x, y: obj.rotation.y, z: obj.rotation.z },
        visible:     obj.visible,
      });
      return;
    }
    const clone=obj.clone(); clone.material=obj.material.clone();
    clone.position.x+=1.2; clone.name=obj.name+'_copy';
    // Ensure cloned mesh matches current global shadow state
    if (typeof LightManager !== 'undefined' && LightManager.configureMeshShadows) {
      LightManager.configureMeshShadows(clone);
    }
    // Deep copy all map sentinels so Phase 6.5 maps reload cleanly on the clone
    const mapSlots=['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap'];
    mapSlots.forEach(slot=>{ clone.material[`_${slot}Url`]=null; });
    SceneManager.addObject(clone);
    // Clone material data (including advanced maps and UV settings) to the new uuid
    const srcData = MaterialSystem.getMatData(obj);
    if(srcData) MaterialSystem.deserialise(clone, Object.assign({}, srcData));
    SelectionSystem.selectObject(clone);
    // UI refresh driven by scene:objectAdded + selection:changed — no manual call needed.
  }

  function _initKeyboard(){
    const modeKeys={'g':'translate','r':'rotate','s':'scale'};
    window.addEventListener('keydown',e=>{
      if(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA') return;
      const k=e.key.toLowerCase();

      // ── Undo / Redo (Ctrl+Z / Ctrl+Y / Ctrl+Shift+Z) ──
      if((e.ctrlKey||e.metaKey) && k==='z' && !e.shiftKey) {
        e.preventDefault();
        if(EditModeSystem.isActive()) {
          if(UndoHistory.canUndo()) {
            const state = UndoHistory.undo(
              EditModeSystem.getMeshData(),
              EditModeSystem.getElemType(),
              EditModeSystem.getSelected()
            );
            if(state) EditModeSystem.applyHistoryState(state);
          }
        } else {
          const obj = SelectionSystem.getSelected();
          if(obj && ObjectUndoHistory.canUndo()) ObjectUndoHistory.undo(obj);
        }
        return;
      }
      if((e.ctrlKey||e.metaKey) && (k==='y' || (k==='z' && e.shiftKey))) {
        e.preventDefault();
        if(EditModeSystem.isActive()) {
          if(UndoHistory.canRedo()) {
            const state = UndoHistory.redo(
              EditModeSystem.getMeshData(),
              EditModeSystem.getElemType(),
              EditModeSystem.getSelected()
            );
            if(state) EditModeSystem.applyHistoryState(state);
          }
        } else {
          const obj = SelectionSystem.getSelected();
          if(obj && ObjectUndoHistory.canRedo()) ObjectUndoHistory.redo(obj);
        }
        return;
      }

      // Tab — toggle edit mode
      if(e.key==='Tab'){ e.preventDefault(); _toggleEditMode(); return; }

      // Edit mode shortcuts
      if(EditModeSystem.isActive()){
        if(k==='1'){ EditModeSystem.setElemType('vert'); _updateExtrudeBtn(); return; }
        if(k==='2'){ EditModeSystem.setElemType('edge'); _updateExtrudeBtn(); return; }
        if(k==='3'){ EditModeSystem.setElemType('face'); _updateExtrudeBtn(); return; }
        if(k==='a'&&!e.shiftKey&&!e.altKey){ EditModeSystem.selectAll(); return; }
        if(k==='a'&&e.altKey){ EditModeSystem.selectNone(); return; }
        if(k==='z'&&e.altKey){ EditModeSystem.toggleXray(); return; }
        if(k==='f'||k==='F'){ CameraManager.focusOnObject(EditModeSystem.getMesh()); return; }
        // Extrude shortcut
        if(k==='e'){
          if(EditModeSystem.getElemType()==='face'&&EditModeSystem.getSelected().size>0){
            EditModeSystem.extrudeFaces();
          }
          return;
        }
        // Inset shortcut
        if(k==='i'){
          if(EditModeSystem.getElemType()==='face'&&EditModeSystem.getSelected().size>0){
            EditModeSystem.startInset();
          }
          return;
        }
        // Bevel shortcut
        if(k==='b'){
          const et=EditModeSystem.getElemType();
          if((et==='edge'||et==='face')&&EditModeSystem.getSelected().size>0){
            EditModeSystem.startBevel();
          }
          return;
        }
        // Transform shortcuts
        if(k==='g'){ EditModeSystem.setEditTransformMode('translate'); return; }
        if(k==='r'){ EditModeSystem.setEditTransformMode('rotate'); return; }
        if(k==='s'){ EditModeSystem.setEditTransformMode('scale'); return; }
        // Loop Cut shortcut
        if(k==='k'){
          if(LoopCutSystem.isActive()){
            LoopCutSystem.cancel();
            if(window._toolsDropdown) window._toolsDropdown.setLoopCutActive(false);
          } else {
            LoopCutSystem.start();
            if(window._toolsDropdown) window._toolsDropdown.setLoopCutActive(true);
          }
          return;
        }
        return; // consume other keys in edit mode
      }

      // Object mode shortcuts
      const mode=modeKeys[k];
      if(mode){ _setMode(mode); return; }
      if(e.key==='Delete'||e.key==='Backspace'){ HierarchySystem.deleteSelected(); return; }
      if(k==='f'){ CameraManager.focusOnObject(SelectionSystem.getSelected()); return; }
      if(k==='d'&&e.shiftKey){ _duplicateSelected(); return; }
    });
  }

  return { init };
})();


// ══════════════════════════════════════════════════════
//  SceneIO  —  Save & Load scene as JSON
//
//  Scene format  v1:
//  {
//    version: 1,
//    objects: [
//      {
//        name:          string,
//        primitiveType: string | null,   // 'box'|'sphere'|... or null for edited mesh
//        position:      {x,y,z},
//        rotation:      {x,y,z},         // radians
//        scale:         {x,y,z},
//        geometry: {
//          // For stock primitives that haven't been edited in vertex mode
//          // we just record the type and re-build the default geometry.
//          // For any mesh that was edited we dump the full buffer.
//          isEdited: bool,
//          // --- present only when isEdited === true ---
//          positions:    [x0,y0,z0, x1,y1,z1, ...],
//          index:        [i0,i1,i2, ...]   // null if non-indexed
//          normals:      [nx0,ny0,nz0, ...]  // vertex normals — ensures correct lighting after load
//          materialSide: 0 | 2              // 0=FrontSide, 2=DoubleSide (extruded meshes)
//        }
//      }
//    ]
//  }
// ══════════════════════════════════════════════════════
