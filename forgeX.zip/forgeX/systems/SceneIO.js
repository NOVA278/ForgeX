'use strict';
const SceneIO = (() => {
  const VERSION = 1;
  const ORIGINAL_GEO_KEY = '__originalPrimType__'; // userData flag set on first vertex edit

  // ── Helpers ──────────────────────────────────────────

  function _showToast(msg, kind='ok', ms=2200) {
    const el = document.getElementById('io-toast');
    if (!el) return;
    clearTimeout(SceneIO._toastTimer);
    el.textContent = msg;
    el.className = 'show ' + kind;
    SceneIO._toastTimer = setTimeout(() => { el.className = ''; }, ms);
  }

  // Box-projection UV fallback for geometries loaded without saved UV data.
  // Mirrors _generateBoxUVs in EditModeSystem — kept in sync.
  function _generateBoxUVsForGeo(geo) {
    if (!geo.attributes.position) return;
    geo.computeBoundingBox();
    const bb = geo.boundingBox;
    const sX = (bb.max.x - bb.min.x) || 1;
    const sY = (bb.max.y - bb.min.y) || 1;
    const sZ = (bb.max.z - bb.min.z) || 1;
    const posAttr  = geo.attributes.position;
    const normAttr = geo.attributes.normal;
    const count    = posAttr.count;
    const uvArr    = new Float32Array(count * 2);
    for (let i = 0; i < count; i++) {
      const x  = posAttr.getX(i);
      const y  = posAttr.getY(i);
      const z  = posAttr.getZ(i);
      let nx = 0, ny = 1, nz = 0;
      if (normAttr) {
        nx = Math.abs(normAttr.getX(i));
        ny = Math.abs(normAttr.getY(i));
        nz = Math.abs(normAttr.getZ(i));
      }
      let u, v;
      if (nx >= ny && nx >= nz) {
        u = (z - bb.min.z) / sZ;
        v = (y - bb.min.y) / sY;
      } else if (ny >= nx && ny >= nz) {
        u = (x - bb.min.x) / sX;
        v = (z - bb.min.z) / sZ;
      } else {
        u = (x - bb.min.x) / sX;
        v = (y - bb.min.y) / sY;
      }
      uvArr[i * 2]     = u;
      uvArr[i * 2 + 1] = v;
    }
    geo.setAttribute('uv', new THREE.BufferAttribute(uvArr, 2));
    // uv2 copy for aoMap support (Three.js r128)
    geo.setAttribute('uv2', new THREE.BufferAttribute(uvArr.slice(), 2));
  }

  // Detect whether a mesh's geometry has been modified from the default
  // primitive (vertices moved, loop-cut, extrude, bevel, etc.).
  // We tag the mesh in userData when editing starts.
  function _isEdited(mesh) {
    return !!mesh.userData.geometryEdited;
  }

  // ── Serialise ─────────────────────────────────────────

  function _serializeGeometry(mesh) {
    const geo = mesh.geometry;

    if (!_isEdited(mesh) && mesh.userData.primitiveType) {
      // Stock primitive — no need to store vertex data
      return { isEdited: false };
    }

    // Full buffer dump — positions, indices, normals, and material side
    const posAttr = geo.attributes.position;
    const positions = [];
    for (let i = 0; i < posAttr.count; i++) {
      positions.push(posAttr.getX(i), posAttr.getY(i), posAttr.getZ(i));
    }

    let index = null;
    if (geo.index) {
      index = Array.from(geo.index.array);
    }

    // Save normals so they are pixel-perfect after load (no recompute drift)
    let normals = null;
    const normAttr = geo.attributes.normal;
    if (normAttr) {
      normals = [];
      for (let i = 0; i < normAttr.count; i++) {
        normals.push(normAttr.getX(i), normAttr.getY(i), normAttr.getZ(i));
      }
    }

    // Save material side setting — extruded meshes use DoubleSide
    const materialSide = (mesh.material && mesh.material.side === THREE.DoubleSide) ? 2 : 0;

    // Save UVs so textured extruded meshes restore correctly
    let uvs = null;
    const uvAttr = geo.attributes.uv;
    if (uvAttr) {
      uvs = [];
      for (let i = 0; i < uvAttr.count; i++) {
        uvs.push(uvAttr.getX(i), uvAttr.getY(i));
      }
    }

    return { isEdited: true, positions, index, normals, uvs, materialSide };  }

  function exportScene() {
    // Make sure no pending edit-mode geometry is lost
    const wasInEdit = EditModeSystem.isActive();
    if (wasInEdit) EditModeSystem.exit();

    const objects = SceneManager.getMeshObjects();
    const lights  = SceneManager.getLightObjects();

    const data = {
      version: VERSION,
      objects: objects.map(mesh => ({
        uuid:          mesh.uuid,
        name:          mesh.name,
        primitiveType: mesh.userData.primitiveType || null,
        typeName:      mesh.userData.typeName      || 'Mesh',
        position: { x: mesh.position.x, y: mesh.position.y, z: mesh.position.z },
        rotation: { x: mesh.rotation.x, y: mesh.rotation.y, z: mesh.rotation.z },
        scale:    { x: mesh.scale.x,    y: mesh.scale.y,    z: mesh.scale.z    },
        geometry: _serializeGeometry(mesh),
        material: MaterialSystem.serialise(mesh)
      })),
      // ── Scene lights ──
      lights: lights.map(node => ({
        uuid:     node.uuid,
        name:     node.name,
        position: { x: node.position.x, y: node.position.y, z: node.position.z },
        rotation: { x: node.rotation.x, y: node.rotation.y, z: node.rotation.z },
        lightType:      node.userData.lightType      || 'directional',
        lightColor:     node.userData.lightColor     || '#ffffff',
        lightIntensity: node.userData.lightIntensity || 1.0,
        castShadow:     node.userData.castShadow     || false,
      })),
      // ── Light tab settings ──
      lightSettings: (typeof LightManager !== 'undefined') ? LightManager.serialise() : {},
      // ── Hierarchy state (collections + parent/child) ──
      hierarchyState: (typeof HierarchySystem !== 'undefined') ? HierarchySystem.serialise() : null,
    };

    if (wasInEdit) {
      const sel = SelectionSystem.getSelected();
      if (sel) setTimeout(() => EditModeSystem.enter(sel), 0);
    }

    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;

    const DEFAULT_NAME = 'forgex_scene';
    let rawName = window.prompt('Save scene as:', DEFAULT_NAME);
    if (rawName === null || rawName.trim() === '') rawName = DEFAULT_NAME;
    rawName = rawName.trim().replace(/\.forgex\.json$/i, '').replace(/\.json$/i, '');
    a.download = rawName + '.forgex.json';

    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    const total = objects.length + lights.length;
    _showToast(`✓ Scene saved  (${total} object${total !== 1 ? 's' : ''})`, 'ok');
  }

  // ── Deserialise ───────────────────────────────────────

  function _rebuildGeometry(objData) {
    const gd = objData.geometry;

    if (!gd.isEdited && objData.primitiveType) {
      // Re-create the stock primitive geometry (identical to ObjectManager)
      switch (objData.primitiveType) {
        case 'box':      return { geo: new THREE.BoxGeometry(1,1,1,2,2,2), materialSide: 0 };
        case 'sphere':   return { geo: new THREE.SphereGeometry(0.6,16,12), materialSide: 0 };
        case 'cylinder': return { geo: new THREE.CylinderGeometry(0.5,0.5,1,16,2), materialSide: 0 };
        case 'cone':     return { geo: new THREE.ConeGeometry(0.5,1,16,2), materialSide: 0 };
        case 'torus':    return { geo: new THREE.TorusGeometry(0.5,0.2,8,24), materialSide: 0 };
        case 'plane':    return { geo: new THREE.PlaneGeometry(1.5,1.5,4,4), materialSide: 2 };
        case 'icosphere':return { geo: new THREE.IcosahedronGeometry(0.6,2), materialSide: 0 };
        case 'torusknot':return { geo: new THREE.TorusKnotGeometry(0.4,0.15,128,16,2,3), materialSide: 0 };
        case 'circle':   return { geo: new THREE.CircleGeometry(0.7,32), materialSide: 2 };
        case 'empty':    return { geo: ObjectManager._buildEmptyForIO ? ObjectManager._buildEmptyForIO() : new THREE.BoxGeometry(0.1,0.1,0.1), materialSide: 0 };
        default:         return { geo: new THREE.BoxGeometry(1,1,1,2,2,2), materialSide: 0 };
      }
    }

    // Reconstruct from full buffer data
    const geo = new THREE.BufferGeometry();
    const posArray = new Float32Array(gd.positions);
    geo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));

    if (gd.index && gd.index.length > 0) {
      const maxIdx = Math.max(...gd.index);
      const IdxArray = maxIdx > 65535 ? Uint32Array : Uint16Array;
      geo.setIndex(new THREE.BufferAttribute(new IdxArray(gd.index), 1));
    }

    // Restore saved normals exactly — prevents lighting drift on extruded faces
    if (gd.normals && gd.normals.length > 0) {
      const normArray = new Float32Array(gd.normals);
      geo.setAttribute('normal', new THREE.BufferAttribute(normArray, 3));
    } else {
      // Fallback: recompute normals if not stored (older scene files)
      geo.computeVertexNormals();
    }

    geo.computeBoundingBox();
    geo.computeBoundingSphere();

    // Restore saved UVs — required for textures on extruded/edited meshes
    if (gd.uvs && gd.uvs.length > 0) {
      const uvArray = new Float32Array(gd.uvs);
      geo.setAttribute('uv', new THREE.BufferAttribute(uvArray, 2));
      // uv2 = copy of uv for aoMap support
      geo.setAttribute('uv2', new THREE.BufferAttribute(uvArray.slice(), 2));
    } else {
      // Fallback: generate box-projected UVs for older saves without UV data
      _generateBoxUVsForGeo(geo);
    }

    // materialSide: 2 = DoubleSide (extruded meshes), 0 = FrontSide
    const materialSide = (gd.materialSide === 2) ? 2 : 0;

    return { geo, materialSide };
  }

  function importScene(jsonText) {
    let data;
    try {
      data = JSON.parse(jsonText);
    } catch (e) {
      _showToast('✕ Invalid JSON file', 'err', 3000);
      return;
    }

    if (!data || !Array.isArray(data.objects)) {
      _showToast('✕ Not a ForgeX scene file', 'err', 3000);
      return;
    }

    // Exit edit mode if active
    if (EditModeSystem.isActive()) EditModeSystem.exit();

    // Deselect
    SelectionSystem.clearSelection();
    TransformControlsModule.detach();

    // Remove all current mesh objects
    const existing = SceneManager.getMeshObjects();
    existing.forEach(obj => SceneManager.removeObject(obj));

    // Remove existing scene lights via LightManager (disposes shadow maps, cleans _sceneLights)
    LightManager.getSceneLights().slice().forEach(e => LightManager.removeLight(e.node));

    // Remove existing scene cameras
    if (typeof SceneCameraSystem !== 'undefined') SceneCameraSystem.removeAll();

    // Clear undo histories
    UndoHistory.clear();
    ObjectUndoHistory.clear();

    let loaded = 0;
    const errors = [];

    // ── Restore mesh objects ──────────────────────────────────────────────
    data.objects.forEach((objData, i) => {
      try {
        const { geo, materialSide } = _rebuildGeometry(objData);
        const matConfig = { color: 0x4a78c0, metalness: 0.08, roughness: 0.65 };
        const mat = new THREE.MeshStandardMaterial(matConfig);
        mat.side = (materialSide === 2) ? THREE.DoubleSide : THREE.FrontSide;

        const mesh = new THREE.Mesh(geo, mat);
        LightManager.configureMeshShadows(mesh);
        mesh.name          = objData.name || `Object.${String(i+1).padStart(3,'0')}`;

        mesh.position.set(objData.position.x, objData.position.y, objData.position.z);
        mesh.rotation.set(objData.rotation.x, objData.rotation.y, objData.rotation.z);
        mesh.scale.set(   objData.scale.x,    objData.scale.y,    objData.scale.z);

        mesh.userData.primitiveType = objData.primitiveType || null;
        mesh.userData.typeName      = objData.typeName      || 'Mesh';
        if (objData.geometry.isEdited) mesh.userData.geometryEdited = true;

        // Restore saved UUID so HierarchySystem parent/child references remain valid
        if (objData.uuid) mesh.uuid = objData.uuid;

        if (objData.material) {
          MaterialSystem.deserialise(mesh, objData.material);
          if (mesh.material) {
            const uvData = MaterialSystem.getMatData(mesh);
            if (uvData) MaterialSystem._applyUVTransformsToMaterial(mesh.material, uvData);
          }
        }

        if (!objData.geometry.isEdited && mesh.geometry.attributes.uv && !mesh.geometry.attributes.uv2) {
          mesh.geometry.setAttribute('uv2', mesh.geometry.attributes.uv.clone());
        }

        SceneManager.addObject(mesh);
        FDEBUG.log('objectCreation', 'importScene: restored mesh', mesh.name);
        loaded++;
      } catch (e) {
        errors.push(objData.name || `#${i+1}`);
        console.warn('[SceneIO] Failed to rebuild object:', objData.name, e);
      }
    });

    // ── Restore scene lights ──────────────────────────────────────────────
    const savedLights = Array.isArray(data.lights) ? data.lights : [];
    savedLights.forEach(ld => {
      try {
        const result = LightManager.addLight(
          ld.lightType || 'directional',
          {
            color:      ld.lightColor     || '#ffffff',
            intensity:  ld.lightIntensity || 1.0,
            castShadow: ld.castShadow     || false,
            position:   ld.position       || { x: 4, y: 6, z: 3 },
          }
        );
        if (result && result.node) {
          result.node.name = ld.name || 'Light';
          if (ld.rotation) result.node.rotation.set(ld.rotation.x || 0, ld.rotation.y || 0, ld.rotation.z || 0);
          // Restore saved UUID so HierarchySystem parent/child references remain valid
          if (ld.uuid) result.node.uuid = ld.uuid;
        }
        loaded++;
      } catch (e) {
        errors.push(ld.name || 'Light');
        console.warn('[SceneIO] Failed to restore light:', ld.name, e);
      }
    });

    // Restore light tab settings
    if (data.lightSettings && typeof LightManager !== 'undefined') {
      LightManager.deserialise(data.lightSettings);
    }
    if (typeof LightSystem !== 'undefined') {
      LightSystem.refreshList();
    }

    // Restore scene cameras
    if (Array.isArray(data.cameras) && typeof SceneCameraSystem !== 'undefined') {
      SceneCameraSystem.deserialise(data.cameras);
    }

    // Restore hierarchy state (collections + parent/child + visibility/lock)
    if (data.hierarchyState && typeof HierarchySystem !== 'undefined') {
      HierarchySystem.deserialise(data.hierarchyState);
    }

    // Reset shadow warmup — all objects are new; give the renderer time to
    // build shadow maps from scratch before settling to steady state.
    if (typeof RenderLoop !== 'undefined') RenderLoop.resetShadowWarmup();

    // Refresh UI
    UISystem.refreshOutliner();
    UISystem.updateStatus(null);

    if (errors.length === 0) {
      _showToast(`✓ Scene loaded  (${loaded} object${loaded !== 1 ? 's' : ''})`, 'ok');
    } else {
      _showToast(`⚠ Loaded ${loaded}, failed: ${errors.join(', ')}`, 'err', 4000);
    }
  }

  // ── File picker ──────────────────────────────────────

  function triggerLoad() {
    const input = document.getElementById('io-file-input');
    if (!input) return;
    input.value = ''; // allow re-loading same file
    input.click();
  }

  function _initFileInput() {
    const input = document.getElementById('io-file-input');
    if (!input) return;
    input.addEventListener('change', () => {
      const file = input.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = e => importScene(e.target.result);
      reader.onerror = () => _showToast('✕ Could not read file', 'err', 3000);
      reader.readAsText(file);
    });
  }

  // ── New Scene ─────────────────────────────────────────
  function newScene() {
    const confirmed = window.confirm('Start a new scene? Unsaved changes will be lost.');
    if (!confirmed) return;

    // Exit edit mode if active
    if (EditModeSystem.isActive()) EditModeSystem.exit();
    SelectionSystem.clearSelection();
    TransformControlsModule.detach();

    // Remove all mesh objects
    const existing = SceneManager.getMeshObjects();
    existing.forEach(obj => SceneManager.removeObject(obj));

    // Remove all scene lights via LightManager (disposes shadow maps, cleans internal state)
    LightManager.getSceneLights().slice().forEach(e => LightManager.removeLight(e.node));

    // Remove all scene cameras
    if (typeof SceneCameraSystem !== 'undefined') SceneCameraSystem.removeAll();

    // Clear undo histories
    UndoHistory.clear();
    ObjectUndoHistory.clear();

    // Refresh hierarchy, UI
    if (typeof HierarchySystem !== 'undefined') HierarchySystem.deserialise(null);
    UISystem.refreshOutliner();
    UISystem.updateStatus(null);
    if (typeof LightSystem !== 'undefined') LightSystem.refreshList();

    _showToast('✓ New scene created', 'ok', 1800);
  }

  // ── Project Manager ───────────────────────────────────
  const PM_STORAGE_KEY = 'forgex_projects_v1';

  function _getProjects() {
    try {
      const raw = localStorage.getItem(PM_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  }

  function _saveProjectToManager(name, json) {
    try {
      const projects = _getProjects();
      const id = 'proj_' + Date.now();
      const now = new Date();
      const entry = {
        id,
        name,
        savedAt: now.toISOString(),
        savedAtLabel: now.toLocaleDateString() + ' ' + now.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}),
        size: Math.round(json.length / 1024),
        json
      };
      // Replace if same name exists
      const existing = projects.findIndex(p => p.name === name);
      if (existing >= 0) projects[existing] = entry;
      else projects.unshift(entry);
      // Keep max 20 projects
      if (projects.length > 20) projects.length = 20;
      localStorage.setItem(PM_STORAGE_KEY, JSON.stringify(projects));
      return true;
    } catch(e) {
      console.warn('[SceneIO] Could not save to project manager:', e);
      return false;
    }
  }

  function _deleteProject(id) {
    try {
      const projects = _getProjects().filter(p => p.id !== id);
      localStorage.setItem(PM_STORAGE_KEY, JSON.stringify(projects));
    } catch(e) {}
  }

  function openProjectManager() {
    const overlay = document.getElementById('project-manager-overlay');
    if (!overlay) return;
    _renderProjectManager();
    overlay.classList.add('open');
  }

  function _renderProjectManager() {
    const listEl  = document.getElementById('pm-project-list');
    const emptyEl = document.getElementById('pm-empty');
    if (!listEl || !emptyEl) return;

    const projects = _getProjects();
    if (projects.length === 0) {
      emptyEl.style.display = '';
      listEl.innerHTML = '';
      return;
    }

    emptyEl.style.display = 'none';
    listEl.innerHTML = projects.map(p => `
      <div class="pm-project-row" data-id="${p.id}">
        <div class="pm-project-icon">
          <svg width="14" height="14" viewBox="0 0 12 12" fill="none"><path d="M2 10.5V1.5h5L9.5 4v6.5H2z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </div>
        <div class="pm-project-info">
          <div class="pm-project-name">${p.name}</div>
          <div class="pm-project-meta"><span>${p.savedAtLabel}</span><span>${p.size} KB</span></div>
        </div>
        <div class="pm-project-actions">
          <button class="pm-action-btn pm-action-load" data-id="${p.id}" title="Load project">Load</button>
          <button class="pm-action-btn pm-action-del" data-id="${p.id}" title="Delete project">Del</button>
        </div>
      </div>
    `).join('');

    // Wire load buttons
    listEl.querySelectorAll('.pm-action-load').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = btn.dataset.id;
        const project = _getProjects().find(p => p.id === id);
        if (!project) return;
        const overlay = document.getElementById('project-manager-overlay');
        if (overlay) overlay.classList.remove('open');
        importScene(project.json);
      });
    });

    // Wire delete buttons
    listEl.querySelectorAll('.pm-action-del').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = btn.dataset.id;
        if (window.confirm('Delete this project? This cannot be undone.')) {
          _deleteProject(id);
          _renderProjectManager();
        }
      });
    });

    // Row click = load
    listEl.querySelectorAll('.pm-project-row').forEach(row => {
      row.addEventListener('click', e => {
        if (e.target.closest('.pm-project-actions')) return;
        const id = row.dataset.id;
        const project = _getProjects().find(p => p.id === id);
        if (!project) return;
        const overlay = document.getElementById('project-manager-overlay');
        if (overlay) overlay.classList.remove('open');
        importScene(project.json);
      });
    });
  }

  // Modified exportScene that also saves to project manager
  function saveProject() {
    // Make sure no pending edit-mode geometry is lost
    const wasInEdit = EditModeSystem.isActive();
    if (wasInEdit) EditModeSystem.exit();

    const objects = SceneManager.getMeshObjects();
    const lights  = SceneManager.getLightObjects();

    const sceneCameras = SceneManager.getCameraObjects();
    const data = {
      version: VERSION,
      objects: objects.map(mesh => ({
        uuid:          mesh.uuid,
        name:          mesh.name,
        primitiveType: mesh.userData.primitiveType || null,
        typeName:      mesh.userData.typeName      || 'Mesh',
        position: { x: mesh.position.x, y: mesh.position.y, z: mesh.position.z },
        rotation: { x: mesh.rotation.x, y: mesh.rotation.y, z: mesh.rotation.z },
        scale:    { x: mesh.scale.x,    y: mesh.scale.y,    z: mesh.scale.z    },
        geometry: _serializeGeometry(mesh),
        material: MaterialSystem.serialise(mesh)
      })),
      lights: lights.map(node => ({
        uuid:     node.uuid,
        name:     node.name,
        position: { x: node.position.x, y: node.position.y, z: node.position.z },
        rotation: { x: node.rotation.x, y: node.rotation.y, z: node.rotation.z },
        lightType:      node.userData.lightType      || 'directional',
        lightColor:     node.userData.lightColor     || '#ffffff',
        lightIntensity: node.userData.lightIntensity || 1.0,
        castShadow:     node.userData.castShadow     || false,
      })),
      cameras: (typeof SceneCameraSystem !== 'undefined') ? SceneCameraSystem.serialise() : [],
      lightSettings: (typeof LightManager !== 'undefined') ? LightManager.serialise() : {},
      hierarchyState: (typeof HierarchySystem !== 'undefined') ? HierarchySystem.serialise() : null,
    };

    if (wasInEdit) {
      const sel = SelectionSystem.getSelected();
      if (sel) setTimeout(() => EditModeSystem.enter(sel), 0);
    }

    const json = JSON.stringify(data, null, 2);

    const DEFAULT_NAME = 'forgex_scene';
    let rawName = window.prompt('Save project as:', DEFAULT_NAME);
    if (rawName === null || rawName.trim() === '') rawName = DEFAULT_NAME;
    rawName = rawName.trim().replace(/\.forgex\.json$/i, '').replace(/\.json$/i, '');

    // Save to Project Manager (localStorage)
    _saveProjectToManager(rawName, json);

    const total = objects.length + lights.length;
    _showToast(`✓ Project saved: "${rawName}"  (${total} object${total !== 1 ? 's' : ''})`, 'ok', 2800);
  }

  // ── Autosave Recovery ─────────────────────────────────
  const AUTOSAVE_KEY = 'forgex_autosave_v1';
  let _autosaveTimer = null;

  function _doAutosave() {
    try {
      const wasInEdit = EditModeSystem.isActive();
      const objects = SceneManager.getMeshObjects();
      const lights  = SceneManager.getLightObjects();
      if (objects.length === 0 && lights.length === 0) return;

      if (wasInEdit) EditModeSystem.exit();
      const data = {
        version: VERSION,
        savedAt: new Date().toISOString(),
        objects: objects.map(mesh => ({
          name: mesh.name,
          uuid: mesh.uuid,
          primitiveType: mesh.userData.primitiveType || null,
          typeName: mesh.userData.typeName || 'Mesh',
          position: { x: mesh.position.x, y: mesh.position.y, z: mesh.position.z },
          rotation: { x: mesh.rotation.x, y: mesh.rotation.y, z: mesh.rotation.z },
          scale:    { x: mesh.scale.x,    y: mesh.scale.y,    z: mesh.scale.z    },
          geometry: _serializeGeometry(mesh),
          material: MaterialSystem.serialise(mesh)
        })),
        lights: lights.map(node => ({
          name: node.name,
          uuid: node.uuid,
          position: { x: node.position.x, y: node.position.y, z: node.position.z },
          rotation: { x: node.rotation.x, y: node.rotation.y, z: node.rotation.z },
          lightType: node.userData.lightType || 'directional',
          lightColor: node.userData.lightColor || '#ffffff',
          lightIntensity: node.userData.lightIntensity || 1.0,
          castShadow: node.userData.castShadow || false,
        })),
        lightSettings: (typeof LightManager !== 'undefined') ? LightManager.serialise() : {},
        hierarchyState: (typeof HierarchySystem !== 'undefined') ? HierarchySystem.serialise() : null,
      };
      if (wasInEdit) {
        const sel = SelectionSystem.getSelected();
        if (sel) setTimeout(() => EditModeSystem.enter(sel), 0);
      }
      localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(data));
    } catch(e) {
      console.warn('[SceneIO] Autosave failed:', e);
    }
  }

  function autosaveRecovery() {
    try {
      const raw = localStorage.getItem(AUTOSAVE_KEY);
      if (!raw) {
        _showToast('No autosave found', 'err', 2000);
        return;
      }
      const data = JSON.parse(raw);
      const savedAt = data.savedAt ? new Date(data.savedAt).toLocaleString() : 'unknown time';
      const confirmed = window.confirm(`Restore autosave from ${savedAt}? Current scene will be replaced.`);
      if (confirmed) importScene(raw);
    } catch(e) {
      _showToast('✕ Autosave recovery failed', 'err', 2800);
    }
  }

  // ── Public API ────────────────────────────────────────

  function init() {
    _initFileInput();

    // File menu is the single entry point for all save/load/new actions.
    // (Legacy #btn-save-scene / #btn-load-scene buttons no longer exist in the UI.)

    // ── File Menu wiring ──────────────────────────────────
    const fmTrigger = document.getElementById('file-menu-trigger');
    const fmPanel   = document.getElementById('file-menu-panel');

    if (fmTrigger && fmPanel) {
      function _openMenu()  { fmTrigger.classList.add('open'); fmPanel.classList.add('open'); }
      function _closeMenu() { fmTrigger.classList.remove('open'); fmPanel.classList.remove('open'); }
      function _toggleMenu(){ fmTrigger.classList.contains('open') ? _closeMenu() : _openMenu(); }

      fmTrigger.addEventListener('click', e => { e.stopPropagation(); _toggleMenu(); });

      document.addEventListener('click', e => {
        if (!document.getElementById('file-menu-wrap')?.contains(e.target)) _closeMenu();
      });
      document.addEventListener('touchstart', e => {
        if (!document.getElementById('file-menu-wrap')?.contains(e.target)) _closeMenu();
      }, { passive: true });

      // Close menu after any item click (with a tick so the action fires first)
      fmPanel.querySelectorAll('.file-menu-item').forEach(item => {
        item.addEventListener('click', () => setTimeout(_closeMenu, 60));
      });

      // Wire menu items
      const _wire = (id, fn) => { const el = document.getElementById(id); if (el) el.addEventListener('click', fn); };
      _wire('fm-new-scene',         () => newScene());
      _wire('fm-save-project',      () => saveProject());
      _wire('fm-load-project',      () => triggerLoad());
      _wire('fm-project-manager',   () => openProjectManager());
      _wire('fm-export-project',    () => exportScene());
      _wire('fm-import-project',    () => triggerLoad());
      _wire('fm-autosave-recovery', () => autosaveRecovery());
    }

    // ── Project Manager modal close buttons ───────────────
    const pmOverlay = document.getElementById('project-manager-overlay');
    const pmCloseFtr = document.getElementById('pm-btn-close-footer');
    const pmCloseBtn = document.getElementById('pm-close-btn');
    if (pmOverlay) {
      const _closePM = () => pmOverlay.classList.remove('open');
      if (pmCloseBtn) pmCloseBtn.addEventListener('click', _closePM);
      if (pmCloseFtr) pmCloseFtr.addEventListener('click', _closePM);
      pmOverlay.addEventListener('click', e => { if (e.target === pmOverlay) _closePM(); });
      document.addEventListener('keydown', e => { if (e.key === 'Escape' && pmOverlay.classList.contains('open')) _closePM(); });
    }

    // ── Keyboard shortcuts ────────────────────────────────
    window.addEventListener('keydown', e => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); saveProject(); }
      if ((e.ctrlKey || e.metaKey) && e.key === 'o') { e.preventDefault(); triggerLoad(); }
      if ((e.ctrlKey || e.metaKey) && e.key === 'n') { e.preventDefault(); newScene(); }
    });

    // ── Autosave: every 60 seconds ────────────────────────
    _autosaveTimer = setInterval(_doAutosave, 60000);
  }

  // Tag a mesh as having edited geometry (called by EditModeSystem on first write-back)
  function markGeometryEdited(mesh) {
    if (mesh) mesh.userData.geometryEdited = true;
  }

  return { init, exportScene, importScene, triggerLoad, saveProject, newScene, openProjectManager, autosaveRecovery, markGeometryEdited, _toastTimer: null };
})();

// ══════════════════════════════════════════════════════
//  PanelCollapseSystem
// ══════════════════════════════════════════════════════
