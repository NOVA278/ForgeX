'use strict';
const SceneCameraSystem = (() => {

  // ── State ────────────────────────────────────────────────────────────────
  let _scene          = null;
  let _renderer       = null;
  let _cameraList     = [];   // [{root, perspCam, iconMesh, id}]
  let _idCounter      = 0;
  let _previewRoot    = null; // the CameraRoot currently in preview mode
  let _previewActive  = false;

  // ── Camera icon geometry (shared, reused) ─────────────────────────────────
  let _iconGeo = null;
  let _iconMat = null;
  let _frustrumLineMat = null;

  function _ensureSharedAssets() {
    if (!_iconGeo) {
      // Box body
      _iconGeo = new THREE.BoxGeometry(0.28, 0.18, 0.22);
    }
    if (!_iconMat) {
      _iconMat = new THREE.MeshBasicMaterial({
        color: 0x4d8ef5,
        depthTest: false,
        transparent: true,
        opacity: 0.85,
      });
    }
    if (!_frustrumLineMat) {
      _frustrumLineMat = new THREE.LineBasicMaterial({
        color: 0x4d8ef5,
        depthTest: false,
        transparent: true,
        opacity: 0.55,
      });
    }
  }

  function _buildCameraIcon(root) {
    _ensureSharedAssets();

    // Body box
    const body = new THREE.Mesh(_iconGeo, _iconMat);
    body.renderOrder = 12;
    _markNonSelectable(body);
    body.userData.gizmoIcon = true;
    body.userData.cameraRoot = root;

    // Lens cylinder
    const lensGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.10, 8);
    const lens = new THREE.Mesh(lensGeo, _iconMat);
    lens.rotation.x = Math.PI / 2;
    lens.position.z = 0.16;
    lens.renderOrder = 12;
    _markNonSelectable(lens);
    lens.userData.gizmoIcon = true;
    lens.userData.cameraRoot = root;

    // Frustum preview lines (simple 4-point frustum)
    const near = 0.2, far = 0.55, hFov = 0.28, vFov = 0.19;
    const frustPts = [
      // Near rect
      -hFov*near, -vFov*near, -near,   hFov*near, -vFov*near, -near,
       hFov*near, -vFov*near, -near,   hFov*near,  vFov*near, -near,
       hFov*near,  vFov*near, -near,  -hFov*near,  vFov*near, -near,
      -hFov*near,  vFov*near, -near,  -hFov*near, -vFov*near, -near,
      // Far rect
      -hFov*far, -vFov*far, -far,   hFov*far, -vFov*far, -far,
       hFov*far, -vFov*far, -far,   hFov*far,  vFov*far, -far,
       hFov*far,  vFov*far, -far,  -hFov*far,  vFov*far, -far,
      -hFov*far,  vFov*far, -far,  -hFov*far, -vFov*far, -far,
      // Connecting lines (4 corners)
      -hFov*near, -vFov*near, -near,  -hFov*far, -vFov*far, -far,
       hFov*near, -vFov*near, -near,   hFov*far, -vFov*far, -far,
       hFov*near,  vFov*near, -near,   hFov*far,  vFov*far, -far,
      -hFov*near,  vFov*near, -near,  -hFov*far,  vFov*far, -far,
    ];
    const frustGeo = new THREE.BufferGeometry();
    frustGeo.setAttribute('position', new THREE.Float32BufferAttribute(frustPts, 3));
    const frustLines = new THREE.LineSegments(frustGeo, _frustrumLineMat);
    frustLines.renderOrder = 11;
    _markNonSelectable(frustLines);

    // Group all icon parts; add to root
    const iconGroup = new THREE.Group();
    iconGroup.add(body, lens, frustLines);
    iconGroup.userData.nonSelectable = true;
    iconGroup.userData.helperObject  = true;
    iconGroup.userData.gizmoIcon     = true;
    iconGroup.userData.cameraIconGroup = true;
    root.add(iconGroup);
    return iconGroup;
  }

  function _markNonSelectable(obj) {
    obj.userData.nonSelectable = true;
    obj.userData.helperObject  = true;
    obj.castShadow    = false;
    obj.receiveShadow = false;
  }

  // ── Build a complete camera node ──────────────────────────────────────────
  function _buildCameraRoot(name, pos, fov, near, far) {
    _idCounter++;
    const id = _idCounter;

    // Root — this is the object that participates in selection, gizmos, hierarchy
    const root = new THREE.Object3D();
    root.name = name || `Camera.${String(id).padStart(3, '0')}`;
    root.position.set(pos ? pos.x || 0 : 0, pos ? pos.y || 1.5 : 1.5, pos ? pos.z || 5 : 5);
    root.userData.sceneObjectType = 'camera';
    root.userData.typeName        = 'Camera';
    root.userData.cameraId        = id;

    // The actual Three.js PerspectiveCamera, child of root at local (0,0,0)
    const { width, height } = RendererManager.getSize();
    const aspect = width / height || 1;
    const perspCam = new THREE.PerspectiveCamera(fov || 60, aspect, near || 0.1, far || 200);
    perspCam.name = `__cam__${root.name}`;
    perspCam.userData.nonSelectable = true;
    perspCam.userData.helperObject  = true;
    perspCam.userData.isScenePerspCam = true;
    root.add(perspCam);

    // Store back-reference
    root.userData._perspCamera = perspCam;

    // Visual icon
    const iconGroup = _buildCameraIcon(root);

    // Ensure icon doesn't shadow-cast
    root.traverse(c => { c.castShadow = false; c.receiveShadow = false; });

    const entry = { id, root, perspCam, iconGroup };
    _cameraList.push(entry);
    return entry;
  }

  // ── Public: add a camera ──────────────────────────────────────────────────
  function addCamera(opts) {
    opts = opts || {};
    const entry = _buildCameraRoot(
      opts.name   || null,
      opts.pos    || { x: 0, y: 1.5, z: 5 },
      opts.fov    || 60,
      opts.near   || 0.1,
      opts.far    || 200,
    );
    SceneManager.addObject(entry.root, 'camera');
    // Select the new camera
    SelectionSystem.selectObject(entry.root, false);
    EventBus.emit('cameramanager:changed');
    return entry;
  }

  // ── Public: remove a specific camera ─────────────────────────────────────
  function removeCamera(root) {
    const idx = _cameraList.findIndex(e => e.root === root);
    if (idx === -1) return;
    const entry = _cameraList[idx];
    if (_previewRoot === root) exitCamera();
    _cameraList.splice(idx, 1);
    // Dispose geometries on icon children
    entry.root.traverse(c => {
      if (c.geometry) c.geometry.dispose();
    });
    SceneManager.removeSceneObject(entry.root);
    EventBus.emit('cameramanager:changed');
  }

  // ── Public: remove all cameras (called by newScene) ───────────────────────
  function removeAll() {
    if (_previewActive) exitCamera();
    _cameraList.slice().forEach(e => {
      e.root.traverse(c => { if (c.geometry) c.geometry.dispose(); });
      SceneManager.removeSceneObject(e.root);
    });
    _cameraList = [];
  }

  // ── Enter / Exit camera preview ───────────────────────────────────────────
  function enterCamera(root) {
    if (!root || root.userData.sceneObjectType !== 'camera') return;
    const entry = _cameraList.find(e => e.root === root);
    if (!entry) return;

    // Sync camera aspect before entering (viewport may have been resized)
    _syncCameraAspect(entry.perspCam);

    _previewRoot   = root;
    _previewActive = true;

    // Swap active camera in CameraManager
    CameraManager._setActiveSceneCamera(entry.perspCam);

    // Show banner
    const banner = document.getElementById('cam-preview-banner');
    const label  = document.getElementById('cam-preview-label');
    if (banner) banner.classList.add('active');
    if (label)  label.textContent = root.name + ' — Camera View';

    // Show rule-of-thirds overlay
    const overlay = document.getElementById('cam-overlay-grid');
    if (overlay) overlay.classList.add('active');

    // Update Enter Cam button style
    const btn = document.getElementById('btn-enter-camera');
    if (btn) btn.classList.add('cam-active');

    // Update camera-active badge in props
    const badge = document.getElementById('cam-active-badge');
    if (badge) badge.style.display = '';

    // Disable orbit navigation while in camera preview
    CameraManager.setOrbitEnabled(false);

    UISystem.showModePill('CAMERA VIEW');
  }

  function exitCamera() {
    if (!_previewActive) return;
    _previewActive = false;
    _previewRoot   = null;

    // Restore viewport camera
    CameraManager._setActiveSceneCamera(null);
    CameraManager.setOrbitEnabled(true);

    // Hide banner
    const banner = document.getElementById('cam-preview-banner');
    if (banner) banner.classList.remove('active');

    // Hide rule-of-thirds overlay
    const overlay = document.getElementById('cam-overlay-grid');
    if (overlay) overlay.classList.remove('active');

    // Reset Enter Cam button style
    const btn = document.getElementById('btn-enter-camera');
    if (btn) btn.classList.remove('cam-active');

    // Hide camera-active badge
    const badge = document.getElementById('cam-active-badge');
    if (badge) badge.style.display = 'none';

    UISystem.showModePill('VIEWPORT');
    EventBus.emit('cameramanager:changed');
  }

  function isPreviewActive() { return _previewActive; }
  function getPreviewRoot()  { return _previewRoot; }

  // ── Update a camera's intrinsics from the UI ──────────────────────────────
  function updateCameraIntrinsics(root, props) {
    const entry = _cameraList.find(e => e.root === root);
    if (!entry) return;
    const cam = entry.perspCam;
    if (props.fov  !== undefined) { cam.fov  = props.fov;  cam.updateProjectionMatrix(); }
    if (props.near !== undefined) { cam.near = props.near; cam.updateProjectionMatrix(); }
    if (props.far  !== undefined) { cam.far  = props.far;  cam.updateProjectionMatrix(); }
  }

  function _syncCameraAspect(perspCam) {
    const { width, height } = RendererManager.getSize();
    if (width > 0 && height > 0) {
      perspCam.aspect = width / height;
      perspCam.updateProjectionMatrix();
    }
  }

  // ── Serialise / Deserialise ───────────────────────────────────────────────
  function serialise() {
    return _cameraList.map(entry => ({
      id:   entry.id,
      name: entry.root.name,
      position: { x: entry.root.position.x, y: entry.root.position.y, z: entry.root.position.z },
      rotation: { x: entry.root.rotation.x, y: entry.root.rotation.y, z: entry.root.rotation.z },
      fov:  entry.perspCam.fov,
      near: entry.perspCam.near,
      far:  entry.perspCam.far,
    }));
  }

  function deserialise(arr) {
    if (!Array.isArray(arr)) return;
    arr.forEach(cd => {
      const entry = _buildCameraRoot(
        cd.name || null,
        cd.position || { x: 0, y: 1.5, z: 5 },
        cd.fov  || 60,
        cd.near || 0.1,
        cd.far  || 200,
      );
      if (cd.rotation) {
        entry.root.rotation.set(cd.rotation.x || 0, cd.rotation.y || 0, cd.rotation.z || 0);
      }
      SceneManager.addObject(entry.root, 'camera');
    });
  }

  // ── Init ──────────────────────────────────────────────────────────────────
  function init() {
    // Wire Enter Camera toolbar button
    const enterBtn = document.getElementById('btn-enter-camera');
    if (enterBtn) enterBtn.addEventListener('click', () => {
      if (_previewActive) { exitCamera(); return; }
      const sel = SelectionSystem.getSelected();
      if (sel && sel.userData.sceneObjectType === 'camera') enterCamera(sel);
    });

    // Wire Exit Camera banner button
    const exitBtn = document.getElementById('btn-exit-camera');
    if (exitBtn) exitBtn.addEventListener('click', exitCamera);

    // Wire Enter Camera button inside props panel
    const enterPropsBtn = document.getElementById('btn-enter-camera-props');
    if (enterPropsBtn) enterPropsBtn.addEventListener('click', () => {
      const sel = SelectionSystem.getSelected();
      if (sel && sel.userData.sceneObjectType === 'camera') {
        if (_previewActive && _previewRoot === sel) exitCamera();
        else enterCamera(sel);
      }
    });

    // Wire FOV slider
    const fovSlider = document.getElementById('cam-fov-slider');
    const fovVal    = document.getElementById('cam-fov-val');
    if (fovSlider) {
      fovSlider.addEventListener('input', () => {
        const v = parseInt(fovSlider.value);
        if (fovVal) fovVal.textContent = v + '°';
        const sel = SelectionSystem.getSelected();
        if (sel && sel.userData.sceneObjectType === 'camera') {
          updateCameraIntrinsics(sel, { fov: v });
        }
      });
    }

    // Wire Near / Far inputs
    const nearInput = document.getElementById('cam-near-input');
    const farInput  = document.getElementById('cam-far-input');
    if (nearInput) {
      nearInput.addEventListener('input', () => {
        const v = parseFloat(nearInput.value);
        if (!isFinite(v) || v <= 0) return;
        const sel = SelectionSystem.getSelected();
        if (sel && sel.userData.sceneObjectType === 'camera') updateCameraIntrinsics(sel, { near: v });
      });
    }
    if (farInput) {
      farInput.addEventListener('input', () => {
        const v = parseFloat(farInput.value);
        if (!isFinite(v) || v <= 0) return;
        const sel = SelectionSystem.getSelected();
        if (sel && sel.userData.sceneObjectType === 'camera') updateCameraIntrinsics(sel, { far: v });
      });
    }

    // Keep scene cameras' perspective cameras in sync with renderer aspect
    EventBus.on('renderer:resize', ({ width, height }) => {
      _cameraList.forEach(e => {
        e.perspCam.aspect = width / height;
        e.perspCam.updateProjectionMatrix();
      });
    });

    // When camera root is deleted via hierarchy delete button, clean up
    EventBus.on('scene:objectRemoved', node => {
      if (node && node.userData.sceneObjectType === 'camera') {
        const idx = _cameraList.findIndex(e => e.root === node);
        if (idx !== -1) {
          if (_previewRoot === node) exitCamera();
          _cameraList.splice(idx, 1);
        }
      }
    });

    // Keyboard shortcut: Numpad 0 = enter/exit camera of selected camera
    window.addEventListener('keydown', e => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (e.key === '0' && (e.code === 'Numpad0' || e.numLock === false)) {
        e.preventDefault();
        if (_previewActive) { exitCamera(); return; }
        const sel = SelectionSystem.getSelected();
        if (sel && sel.userData.sceneObjectType === 'camera') enterCamera(sel);
      }
    });
  }

  return {
    init, addCamera, removeCamera, removeAll,
    enterCamera, exitCamera, isPreviewActive, getPreviewRoot,
    updateCameraIntrinsics,
    serialise, deserialise,
  };
})();

// ══════════════════════════════════════════════════════
//  AppInit
// ══════════════════════════════════════════════════════
