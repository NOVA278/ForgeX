'use strict';
/**
 * GLTFSystem — glTF 2.0 import / export for ForgeX
 *
 * Export path : SceneManager meshes → glTF JSON (embedded base64) → .gltf download
 * Import path : .gltf / .glb file → THREE.BufferGeometry + material → scene
 *
 * Uses only Three.js r128 primitives; no GLTFLoader/GLTFExporter plugin needed.
 * All binary data is embedded as data URIs so the output is self-contained.
 */
const GLTFSystem = (() => {

  // ── Toast helper (reuse SceneIO's element) ────────────────────────────────
  function _toast(msg, kind = 'ok', ms = 2800) {
    const el = document.getElementById('io-toast');
    if (!el) return;
    clearTimeout(GLTFSystem._tt);
    el.textContent = msg;
    el.className = 'show ' + kind;
    GLTFSystem._tt = setTimeout(() => { el.className = ''; }, ms);
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  function _arrayToBase64(arr) {
    // Fastest cross-browser approach: Uint8Array view → btoa
    const bytes = new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
    let bin = '';
    for (let i = 0; i < bytes.byteLength; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  }

  function _base64ToBuffer(b64) {
    const bin = atob(b64);
    const buf = new ArrayBuffer(bin.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i < bin.length; i++) view[i] = bin.charCodeAt(i);
    return buf;
  }

  function _threeColorToArray(color) {
    return [
      parseFloat(color.r.toFixed(5)),
      parseFloat(color.g.toFixed(5)),
      parseFloat(color.b.toFixed(5)),
    ];
  }

  // glTF component type constants
  const CT = {
    BYTE:           5120,
    UNSIGNED_BYTE:  5121,
    SHORT:          5122,
    UNSIGNED_SHORT: 5123,
    UNSIGNED_INT:   5125,
    FLOAT:          5126,
  };
  const ACC_TYPE = { SCALAR: 'SCALAR', VEC2: 'VEC2', VEC3: 'VEC3', VEC4: 'VEC4', MAT4: 'MAT4' };

  // ── EXPORT ────────────────────────────────────────────────────────────────

  function exportGLTF() {
    const wasInEdit = (typeof EditModeSystem !== 'undefined') && EditModeSystem.isActive();
    if (wasInEdit) EditModeSystem.exit();

    const meshObjects = SceneManager.getMeshObjects();
    if (!meshObjects.length) { _toast('Nothing to export', 'warn'); return; }

    // Build the glTF document
    const gltf = {
      asset: { version: '2.0', generator: 'ForgeX v1.24.3' },
      scene: 0,
      scenes: [{ name: 'ForgeX Scene', nodes: [] }],
      nodes: [],
      meshes: [],
      materials: [],
      accessors: [],
      bufferViews: [],
      buffers: [],
    };

    // Accumulate all binary data into one buffer
    const binChunks = [];   // ArrayBuffer[]
    let   byteOffset = 0;

    function _addAccessor(typedArray, componentType, type, normalize = false) {
      const bytes = new Uint8Array(typedArray.buffer, typedArray.byteOffset, typedArray.byteLength);
      binChunks.push(bytes.buffer.slice(typedArray.byteOffset, typedArray.byteOffset + typedArray.byteLength));

      const bvIdx = gltf.bufferViews.length;
      gltf.bufferViews.push({
        buffer: 0,
        byteOffset,
        byteLength: typedArray.byteLength,
      });
      byteOffset += typedArray.byteLength;
      // Align to 4 bytes
      const pad = (4 - (typedArray.byteLength % 4)) % 4;
      if (pad) {
        binChunks.push(new ArrayBuffer(pad));
        byteOffset += pad;
      }

      // Compute min/max for positions (required by spec)
      let extra = {};
      if (type === ACC_TYPE.VEC3 && componentType === CT.FLOAT) {
        const fa = typedArray instanceof Float32Array ? typedArray : new Float32Array(typedArray.buffer);
        const len = fa.length / 3;
        let mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
        for (let i = 0; i < len; i++) {
          for (let k = 0; k < 3; k++) {
            mn[k] = Math.min(mn[k], fa[i * 3 + k]);
            mx[k] = Math.max(mx[k], fa[i * 3 + k]);
          }
        }
        extra = { min: mn, max: mx };
      }

      const accIdx = gltf.accessors.length;
      const count = type === ACC_TYPE.SCALAR ? typedArray.length
        : type === ACC_TYPE.VEC2 ? typedArray.length / 2
        : type === ACC_TYPE.VEC3 ? typedArray.length / 3
        : typedArray.length / 4;
      gltf.accessors.push({ bufferView: bvIdx, byteOffset: 0, componentType, type, count, normalize, ...extra });
      return accIdx;
    }

    meshObjects.forEach((mesh, mi) => {
      const geo = mesh.geometry;
      if (!geo || !geo.attributes.position) return;

      const posAttr  = geo.attributes.position;
      const normAttr = geo.attributes.normal;
      const uvAttr   = geo.attributes.uv;

      // --- Position ---
      const positions = new Float32Array(posAttr.count * 3);
      for (let i = 0; i < posAttr.count; i++) {
        // glTF is right-handed Y-up; Three.js same convention — no flip needed
        positions[i * 3]     = posAttr.getX(i);
        positions[i * 3 + 1] = posAttr.getY(i);
        positions[i * 3 + 2] = posAttr.getZ(i);
      }
      const posAcc = _addAccessor(positions, CT.FLOAT, ACC_TYPE.VEC3);

      // --- Normal ---
      let normAcc = undefined;
      if (normAttr) {
        const normals = new Float32Array(normAttr.count * 3);
        for (let i = 0; i < normAttr.count; i++) {
          normals[i * 3]     = normAttr.getX(i);
          normals[i * 3 + 1] = normAttr.getY(i);
          normals[i * 3 + 2] = normAttr.getZ(i);
        }
        normAcc = _addAccessor(normals, CT.FLOAT, ACC_TYPE.VEC3);
      }

      // --- UV ---
      let uvAcc = undefined;
      if (uvAttr) {
        const uvs = new Float32Array(uvAttr.count * 2);
        for (let i = 0; i < uvAttr.count; i++) {
          uvs[i * 2]     = uvAttr.getX(i);
          uvs[i * 2 + 1] = 1 - uvAttr.getY(i); // glTF V is flipped
        }
        uvAcc = _addAccessor(uvs, CT.FLOAT, ACC_TYPE.VEC2);
      }

      // --- Index ---
      let idxAcc = undefined;
      if (geo.index) {
        const src = geo.index.array;
        const maxIdx = src.reduce((m, v) => Math.max(m, v), 0);
        const idxArr = maxIdx > 65535
          ? new Uint32Array(src)
          : new Uint16Array(src);
        idxAcc = _addAccessor(idxArr, maxIdx > 65535 ? CT.UNSIGNED_INT : CT.UNSIGNED_SHORT, ACC_TYPE.SCALAR);
      }

      // --- Material ---
      const mat = mesh.material;
      const color = mat ? _threeColorToArray(mat.color) : [0.8, 0.8, 0.8];
      const roughness = mat ? mat.roughness : 0.5;
      const metalness = mat ? mat.metalness : 0.0;

      const matIdx = gltf.materials.length;
      gltf.materials.push({
        name: mesh.name + '_mat',
        pbrMetallicRoughness: {
          baseColorFactor: [...color, 1.0],
          metallicFactor:  parseFloat(metalness.toFixed(4)),
          roughnessFactor: parseFloat(roughness.toFixed(4)),
        },
        doubleSided: (mat && mat.side === THREE.DoubleSide),
      });

      // --- Mesh primitive ---
      const primitiveAttribs = { POSITION: posAcc };
      if (normAcc !== undefined) primitiveAttribs.NORMAL = normAcc;
      if (uvAcc   !== undefined) primitiveAttribs.TEXCOORD_0 = uvAcc;

      const primitive = { attributes: primitiveAttribs, material: matIdx, mode: 4 }; // TRIANGLES
      if (idxAcc !== undefined) primitive.indices = idxAcc;

      const meshIdx = gltf.meshes.length;
      gltf.meshes.push({ name: mesh.name, primitives: [primitive] });

      // --- Node (transform) ---
      const q = new THREE.Quaternion();
      mesh.getWorldQuaternion(q);
      const p = new THREE.Vector3();
      mesh.getWorldPosition(p);
      const s = new THREE.Vector3();
      mesh.getWorldScale(s);

      const nodeIdx = gltf.nodes.length;
      gltf.nodes.push({
        name:        mesh.name,
        mesh:        meshIdx,
        translation: [p.x, p.y, p.z],
        rotation:    [q.x, q.y, q.z, q.w],
        scale:       [s.x, s.y, s.z],
      });
      gltf.scenes[0].nodes.push(nodeIdx);
    });

    // Assemble binary buffer
    const totalBytes = byteOffset;
    const binBuffer  = new Uint8Array(totalBytes);
    let   writeAt    = 0;
    binChunks.forEach(chunk => {
      binBuffer.set(new Uint8Array(chunk), writeAt);
      writeAt += chunk.byteLength;
    });

    const b64 = _arrayToBase64(binBuffer);
    gltf.buffers.push({
      byteLength: totalBytes,
      uri: 'data:application/octet-stream;base64,' + b64,
    });

    const json = JSON.stringify(gltf, null, 2);
    const blob = new Blob([json], { type: 'model/gltf+json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;

    const DEFAULT = 'forgex_scene';
    let rawName = window.prompt('Export glTF as:', DEFAULT);
    if (rawName === null || rawName.trim() === '') rawName = DEFAULT;
    rawName = rawName.trim().replace(/\.gltf$/i, '');
    a.download = rawName + '.gltf';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (wasInEdit) {
      const sel = (typeof SelectionSystem !== 'undefined') && SelectionSystem.getSelected();
      if (sel) setTimeout(() => EditModeSystem.enter(sel), 0);
    }

    _toast(`✓ Exported ${meshObjects.length} mesh${meshObjects.length !== 1 ? 'es' : ''} as glTF`, 'ok');
  }

  // ── IMPORT ────────────────────────────────────────────────────────────────

  function importGLTF() {
    const input = document.createElement('input');
    input.type   = 'file';
    input.accept = '.gltf,.glb';
    input.onchange = e => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      if (file.name.toLowerCase().endsWith('.glb')) {
        reader.onload = ev => _parseGLB(ev.target.result);
        reader.readAsArrayBuffer(file);
      } else {
        reader.onload = ev => _parseGLTF(JSON.parse(ev.target.result), null);
        reader.readAsText(file);
      }
    };
    document.body.appendChild(input);
    input.click();
    document.body.removeChild(input);
  }

  function _parseGLB(arrayBuffer) {
    // GLB header: magic(4) + version(4) + length(4) = 12 bytes
    const view = new DataView(arrayBuffer);
    const magic = view.getUint32(0, true);
    if (magic !== 0x46546C67) { _toast('Not a valid GLB file', 'error'); return; }
    // Chunk 0 = JSON, Chunk 1 = BIN
    const jsonLen  = view.getUint32(12, true);
    const jsonBytes = new Uint8Array(arrayBuffer, 20, jsonLen);
    const jsonText  = new TextDecoder().decode(jsonBytes);
    const gltf = JSON.parse(jsonText);

    let binBuffer = null;
    if (arrayBuffer.byteLength > 20 + jsonLen + 8) {
      const binOffset = 20 + jsonLen;
      const binLen    = view.getUint32(binOffset, true);
      binBuffer       = arrayBuffer.slice(binOffset + 8, binOffset + 8 + binLen);
    }
    _parseGLTF(gltf, binBuffer);
  }

  async function _resolveBuffer(gltf, extBin, bufIndex) {
    const buf = gltf.buffers[bufIndex];
    if (extBin && bufIndex === 0 && !buf.uri) return extBin;
    if (buf.uri && buf.uri.startsWith('data:')) {
      const b64 = buf.uri.split(',')[1];
      return _base64ToBuffer(b64);
    }
    _toast('External .bin buffers not supported; use embedded glTF', 'warn');
    return null;
  }

  function _getAccessorData(gltf, bufferData, accIdx) {
    const acc = gltf.accessors[accIdx];
    const bv  = gltf.bufferViews[acc.bufferView];
    const buf = bufferData[bv.buffer];
    if (!buf) return null;
    const byteOffset = (bv.byteOffset || 0) + (acc.byteOffset || 0);
    const compCount  = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 }[acc.type];
    const total      = acc.count * compCount;
    switch (acc.componentType) {
      case CT.FLOAT:          return new Float32Array(buf, byteOffset, total);
      case CT.UNSIGNED_SHORT: return new Uint16Array(buf,  byteOffset, total);
      case CT.UNSIGNED_INT:   return new Uint32Array(buf,  byteOffset, total);
      case CT.UNSIGNED_BYTE:  return new Uint8Array(buf,   byteOffset, total);
      case CT.SHORT:          return new Int16Array(buf,   byteOffset, total);
      default:                return new Float32Array(buf, byteOffset, total);
    }
  }

  async function _parseGLTF(gltf, extBin) {
    if (!gltf.meshes || !gltf.meshes.length) {
      _toast('No meshes found in glTF file', 'warn');
      return;
    }

    // Resolve all buffers
    const bufferData = [];
    if (gltf.buffers) {
      for (let i = 0; i < gltf.buffers.length; i++) {
        bufferData[i] = await _resolveBuffer(gltf, extBin, i);
      }
    }

    // Build a node→transform map
    const nodeTransforms = {};
    if (gltf.nodes) {
      gltf.nodes.forEach((node, ni) => {
        const t = node.translation || [0, 0, 0];
        const r = node.rotation    || [0, 0, 0, 1];
        const s = node.scale       || [1, 1, 1];
        nodeTransforms[ni] = { t, r, s, meshIndex: node.mesh, name: node.name || ('Node_' + ni) };
      });
    }

    let imported = 0;

    gltf.meshes.forEach((gltfMesh, meshIdx) => {
      (gltfMesh.primitives || []).forEach(prim => {
        const geo = new THREE.BufferGeometry();

        // Position
        if (prim.attributes.POSITION !== undefined) {
          const data = _getAccessorData(gltf, bufferData, prim.attributes.POSITION);
          if (data) geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(data), 3));
        }
        // Normal
        if (prim.attributes.NORMAL !== undefined) {
          const data = _getAccessorData(gltf, bufferData, prim.attributes.NORMAL);
          if (data) geo.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(data), 3));
        }
        // UV (flip V back)
        if (prim.attributes.TEXCOORD_0 !== undefined) {
          const raw = _getAccessorData(gltf, bufferData, prim.attributes.TEXCOORD_0);
          if (raw) {
            const uvs = new Float32Array(raw);
            for (let i = 1; i < uvs.length; i += 2) uvs[i] = 1 - uvs[i];
            geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
            geo.setAttribute('uv2', new THREE.BufferAttribute(uvs.slice(), 2));
          }
        }
        // Index
        if (prim.indices !== undefined) {
          const data = _getAccessorData(gltf, bufferData, prim.indices);
          if (data) {
            const maxIdx = Math.max(...data);
            const arr = maxIdx > 65535 ? new Uint32Array(data) : new Uint16Array(data);
            geo.setIndex(new THREE.BufferAttribute(arr, 1));
          }
        }
        if (!geo.attributes.normal) geo.computeVertexNormals();
        geo.computeBoundingBox();
        geo.computeBoundingSphere();

        // Material
        let color = 0xc8c8c8, roughness = 0.58, metalness = 0.02, doubleSided = false;
        if (prim.material !== undefined && gltf.materials) {
          const gm = gltf.materials[prim.material];
          if (gm) {
            doubleSided = gm.doubleSided || false;
            const pbr = gm.pbrMetallicRoughness || {};
            if (pbr.baseColorFactor) {
              const c = pbr.baseColorFactor;
              color = new THREE.Color(c[0], c[1], c[2]).getHex();
            }
            roughness = pbr.roughnessFactor !== undefined ? pbr.roughnessFactor : 0.58;
            metalness = pbr.metallicFactor  !== undefined ? pbr.metallicFactor  : 0.02;
          }
        }
        const mat = new THREE.MeshStandardMaterial({
          color, roughness, metalness,
          side: doubleSided ? THREE.DoubleSide : THREE.FrontSide,
        });

        const mesh = new THREE.Mesh(geo, mat);

        // Apply node transform if we can find it
        const nodeEntry = Object.values(nodeTransforms).find(n => n.meshIndex === meshIdx);
        if (nodeEntry) {
          mesh.name = nodeEntry.name || gltfMesh.name || ('ImportedMesh_' + meshIdx);
          mesh.position.set(...nodeEntry.t);
          mesh.quaternion.set(nodeEntry.r[0], nodeEntry.r[1], nodeEntry.r[2], nodeEntry.r[3]);
          mesh.scale.set(...nodeEntry.s);
        } else {
          mesh.name = gltfMesh.name || ('ImportedMesh_' + meshIdx);
        }

        mesh.userData.primitiveType = null;
        mesh.userData.typeName      = mesh.name;
        mesh.userData.geometryEdited = true; // treat as custom geometry
        mesh.castShadow    = true;
        mesh.receiveShadow = true;

        SceneManager.addObject(mesh);
        if (typeof LightManager !== 'undefined') LightManager.configureMeshShadows(mesh);
        EventBus.emit('scene:objectAdded', mesh);
        imported++;
      });
    });

    SelectionSystem.selectObject(null, false);
    _toast(`✓ Imported ${imported} mesh${imported !== 1 ? 'es' : ''} from glTF`, 'ok');
  }

  // ── Public API ─────────────────────────────────────────────────────────────
  return { exportGLTF, importGLTF, _tt: null };
})();
