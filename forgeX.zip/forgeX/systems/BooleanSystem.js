'use strict';
/**
 * BooleanSystem — CSG (Constructive Solid Geometry) for ForgeX
 *
 * Implements union, subtract, and intersect on THREE.Mesh objects.
 *
 * Algorithm: Sutherland–Hodgman polygon clipping in 3D space on triangulated meshes.
 * This is a pure-JS implementation that works with Three.js r128 BufferGeometry.
 *
 * Limitations (acceptable for Phase 4):
 * - Works best on convex or near-convex meshes
 * - Handles non-manifold / thin faces gracefully with degenerate-face removal
 * - Requires two selected objects (A and B); result replaces A
 */
const BooleanSystem = (() => {

  const EPS = 1e-7;

  // ── Toast ─────────────────────────────────────────────────────────────────
  function _toast(msg, kind = 'ok', ms = 2800) {
    const el = document.getElementById('io-toast');
    if (!el) return;
    clearTimeout(BooleanSystem._tt);
    el.textContent = msg;
    el.className = 'show ' + kind;
    BooleanSystem._tt = setTimeout(() => { el.className = ''; }, ms);
  }

  // ── Geometry extraction ───────────────────────────────────────────────────

  /**
   * Extract triangles from a Mesh as world-space arrays of 3 THREE.Vector3.
   * Returns { triangles: [[v0,v1,v2], …], normal: [n0,n1,n2], … }
   */
  function _extractTriangles(mesh) {
    const geo  = mesh.geometry;
    const pos  = geo.attributes.position;
    const mat  = mesh.matrixWorld;
    const tris = [];

    const _v = (i) => {
      const v = new THREE.Vector3(pos.getX(i), pos.getY(i), pos.getZ(i));
      return v.applyMatrix4(mat);
    };

    if (geo.index) {
      const idx = geo.index.array;
      for (let i = 0; i < idx.length; i += 3) {
        tris.push([_v(idx[i]), _v(idx[i+1]), _v(idx[i+2])]);
      }
    } else {
      for (let i = 0; i < pos.count; i += 3) {
        tris.push([_v(i), _v(i+1), _v(i+2)]);
      }
    }
    return tris;
  }

  // ── Plane helpers ─────────────────────────────────────────────────────────

  function _planeFromTri(tri) {
    const ab = tri[1].clone().sub(tri[0]);
    const ac = tri[2].clone().sub(tri[0]);
    const n  = ab.cross(ac).normalize();
    const d  = n.dot(tri[0]);
    return { n, d };
  }

  function _classifyVertex(v, plane) {
    const dist = plane.n.dot(v) - plane.d;
    if (dist >  EPS) return  1;
    if (dist < -EPS) return -1;
    return 0;
  }

  /**
   * Split a triangle by a plane. Returns { front: [], back: [] } arrays of triangles.
   */
  function _splitTriByPlane(tri, plane) {
    const cls = tri.map(v => _classifyVertex(v, plane));
    const allFront = cls.every(c => c >= 0);
    const allBack  = cls.every(c => c <= 0);

    if (allFront) return { front: [tri], back: [] };
    if (allBack)  return { front: [], back: [tri] };

    // Mixed: clip
    const front = [], back = [];
    const verts = tri;

    const polyF = [], polyB = [];
    for (let i = 0; i < 3; i++) {
      const a = verts[i], b = verts[(i+1) % 3];
      const ca = cls[i], cb = cls[(i+1) % 3];

      if (ca >= 0) polyF.push(a);
      if (ca <= 0) polyB.push(a);

      if ((ca > 0 && cb < 0) || (ca < 0 && cb > 0)) {
        // Compute intersection
        const ab  = b.clone().sub(a);
        const t   = (plane.d - plane.n.dot(a)) / plane.n.dot(ab);
        const mid = a.clone().addScaledVector(ab, t);
        polyF.push(mid);
        polyB.push(mid.clone());
      }
    }

    // Fan triangulate polygons
    const _fan = (poly, arr) => {
      for (let i = 1; i < poly.length - 1; i++) {
        arr.push([poly[0], poly[i], poly[i+1]]);
      }
    };
    if (polyF.length >= 3) _fan(polyF, front);
    if (polyB.length >= 3) _fan(polyB, back);

    return { front, back };
  }

  // ── CSG operations ────────────────────────────────────────────────────────

  /**
   * Classify all triangles of `tris` against solid `other` (which is already
   * a triangle array with planes). Returns { inside, outside }.
   */
  function _classifyTriangles(tris, otherTris) {
    // Build plane list from otherTris
    const planes = otherTris.map(t => _planeFromTri(t));

    const inside  = [];
    const outside = [];

    tris.forEach(tri => {
      // A triangle is "inside" the solid if its centroid is inside the mesh.
      // We use a simple even-odd ray test along +X from centroid.
      const cx = (tri[0].x + tri[1].x + tri[2].x) / 3;
      const cy = (tri[0].y + tri[1].y + tri[2].y) / 3;
      const cz = (tri[0].z + tri[1].z + tri[2].z) / 3;
      const centroid = new THREE.Vector3(cx, cy, cz);

      let hits = 0;
      const ray  = new THREE.Vector3(1, 0.00031, 0.00017); // slight offset to avoid coplanar hits
      otherTris.forEach(ot => {
        const e1 = ot[1].clone().sub(ot[0]);
        const e2 = ot[2].clone().sub(ot[0]);
        const h  = ray.clone().cross(e2);
        const a  = e1.dot(h);
        if (Math.abs(a) < EPS) return;
        const f = 1 / a;
        const s = centroid.clone().sub(ot[0]);
        const u = f * s.dot(h);
        if (u < 0 || u > 1) return;
        const q = s.cross(e1);
        const v = f * ray.dot(q);
        if (v < 0 || u + v > 1) return;
        const t = f * e2.dot(q);
        if (t > EPS) hits++;
      });

      if (hits % 2 === 1) inside.push(tri); else outside.push(tri);
    });

    return { inside, outside };
  }

  /**
   * Flip a triangle's winding order (for subtraction).
   */
  function _flipTri(tri) { return [tri[0], tri[2], tri[1]]; }

  /**
   * Remove degenerate triangles (area ≈ 0).
   */
  function _removeDegen(tris) {
    return tris.filter(tri => {
      const ab = tri[1].clone().sub(tri[0]);
      const ac = tri[2].clone().sub(tri[0]);
      return ab.cross(ac).lengthSq() > EPS * EPS;
    });
  }

  /**
   * Build a BufferGeometry from an array of triangles [[v0,v1,v2], …].
   * Returns it in the local space of mesh A (inverse world matrix applied).
   */
  function _buildGeometry(tris, meshA) {
    const invMat = meshA.matrixWorld.clone().invert();
    tris = _removeDegen(tris);
    const positions = new Float32Array(tris.length * 9);
    let   off = 0;
    tris.forEach(tri => {
      tri.forEach(v => {
        const lv = v.clone().applyMatrix4(invMat);
        positions[off++] = lv.x;
        positions[off++] = lv.y;
        positions[off++] = lv.z;
      });
    });
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.computeVertexNormals();
    geo.computeBoundingBox();
    geo.computeBoundingSphere();
    return geo;
  }

  // ── Public operations ──────────────────────────────────────────────────────

  function _applyBoolean(opName) {
    const selected = SelectionSystem.getSelected();
    const all      = SceneManager.getMeshObjects();

    // Need exactly 2 selected or 1 selected + 1 secondary
    const selSet = new Set(
      Array.isArray(selected) ? selected : (selected ? [selected] : [])
    );

    // In ForgeX single-selection model, we operate on the selected + the last-selected pair
    // If only 1 is "selected", grab from the global list by marker
    const meshA = selected;
    const meshB = all.find(m => m !== meshA && m.userData._boolTarget);

    if (!meshA || !meshB) {
      _toast('Select two meshes: activate one, mark the other with "Set B"', 'warn', 3000);
      return;
    }

    const trisA = _extractTriangles(meshA);
    const trisB = _extractTriangles(meshB);

    let resultTris = [];

    switch (opName) {
      case 'union': {
        // A outside B  +  B outside A
        const { outside: aOut } = _classifyTriangles(trisA, trisB);
        const { outside: bOut } = _classifyTriangles(trisB, trisA);
        resultTris = [...aOut, ...bOut];
        break;
      }
      case 'subtract': {
        // A outside B  +  (B inside A) flipped
        const { outside: aOut } = _classifyTriangles(trisA, trisB);
        const { inside: bIn   } = _classifyTriangles(trisB, trisA);
        resultTris = [...aOut, ...bIn.map(_flipTri)];
        break;
      }
      case 'intersect': {
        // A inside B  +  B inside A
        const { inside: aIn } = _classifyTriangles(trisA, trisB);
        const { inside: bIn } = _classifyTriangles(trisB, trisA);
        resultTris = [...aIn, ...bIn];
        break;
      }
    }

    if (!resultTris.length) {
      _toast(`${opName}: result is empty (meshes may not overlap)`, 'warn');
      return;
    }

    const newGeo = _buildGeometry(resultTris, meshA);

    // Replace A's geometry
    meshA.geometry.dispose();
    meshA.geometry = newGeo;
    meshA.userData.geometryEdited = true;
    meshA.userData.primitiveType  = null;

    // Remove B from scene
    delete meshB.userData._boolTarget;
    SceneManager.removeObject(meshB);
    EventBus.emit('scene:objectRemoved', meshB);

    EventBus.emit('scene:objectAdded', meshA);
    SelectionSystem.selectObject(meshA, false);

    // Clear UV add coords
    if (typeof MaterialSystem !== 'undefined') MaterialSystem.restoreFromData(meshA);

    _toast(`✓ Boolean ${opName} applied`, 'ok');
  }

  function setTargetB(mesh) {
    // Clear previous target
    SceneManager.getMeshObjects().forEach(m => delete m.userData._boolTarget);
    if (mesh) {
      mesh.userData._boolTarget = true;
      _toast(`"${mesh.name}" set as Boolean B target`, 'ok', 2000);
    }
  }

  function getTargetB() {
    return SceneManager.getMeshObjects().find(m => m.userData._boolTarget) || null;
  }

  function applyUnion()    { _applyBoolean('union');    }
  function applySubtract() { _applyBoolean('subtract'); }
  function applyIntersect(){ _applyBoolean('intersect');}

  return { applyUnion, applySubtract, applyIntersect, setTargetB, getTargetB, _tt: null };
})();
