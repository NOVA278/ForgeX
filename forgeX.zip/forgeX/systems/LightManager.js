'use strict';
const LightManager = (() => {

  // ── Internal state ────────────────────────────────────────────────────────
  const _viewportLights = [];   // { light, name } — editor-only, never selectable
  const _sceneLights    = [];   // { id, node, light, lightType, areaHelper, props }

  let _scene    = null;
  let _renderer = null;
  let _shadowsEnabled = true;
  let _shadowQuality  = 'high';
  let _shadowSoftness = 0.30;  // 0=hard, 1=very soft (controls normalBias multiplier)
  let _idCounter      = 0;

  // Shadow map resolution per quality tier
  const SHADOW_SIZES = { low: 512, medium: 1024, high: 2048, ultra: 4096 };

  // ── Tag an object (and all descendants) as a non-shadow-casting helper ────
  function _markHelper(obj) {
    obj.traverse(child => {
      child.castShadow    = false;
      child.receiveShadow = false;
      if (!child.userData) child.userData = {};
      child.userData.nonSelectable = true;
      child.userData.helperObject  = true;
    });
  }

  // ── Dispose a shadow map cleanly ──────────────────────────────────────────
  function _disposeShadowMap(light) {
    if (light && light.shadow && light.shadow.map) {
      light.shadow.map.dispose();
      light.shadow.map = null;
    }
  }

  // ══════════════════════════════════════════════════════
  //  PER-LIGHT-TYPE SHADOW CONFIGURATORS
  //  Each type has its own independent, tuned values.
  //  Do NOT share bias/near/far across types.
  // ══════════════════════════════════════════════════════

  function _configureShadow_Directional(light) {
    if (!light.shadow) return;
    const size = SHADOW_SIZES[_shadowQuality] || 2048;
    // Large orthographic frustum: covers the full scene from a world-scale sun distance.
    // The frustum is centred on the target (world origin) and large enough that
    // moving the gizmo node does not change shadow coverage — true parallel shadows.
    light.shadow.mapSize.set(size, size);
    light.shadow.camera.near   =  1;
    light.shadow.camera.far    = 120;   // must be > 2 × SUN_DISTANCE to capture scene
    light.shadow.camera.left   = -20;
    light.shadow.camera.right  =  20;
    light.shadow.camera.top    =  20;
    light.shadow.camera.bottom = -20;
    // Tiny positive bias — prevents acne without detaching shadows from surface
    light.shadow.bias           =  0.0001;
    light.shadow.normalBias     =  0.03 + _shadowSoftness * 0.15;
    light.shadow.radius         =  1 + _shadowSoftness * 4;  // PCFSoft blur radius
    light.shadow.camera.updateProjectionMatrix();
    _disposeShadowMap(light);
  }

  function _configureShadow_Point(light) {
    if (!light.shadow) return;
    const size = SHADOW_SIZES[_shadowQuality] || 2048;
    // Point lights use a cubemap — needs conservative near/far
    light.shadow.mapSize.set(size, size);
    light.shadow.camera.near = 0.2;
    light.shadow.camera.far  = 30;
    // Point shadows need larger normalBias to avoid cubemap seam acne
    light.shadow.bias        = 0.0;
    light.shadow.normalBias  = 0.10 + _shadowSoftness * 0.15;
    light.shadow.radius      = 1 + _shadowSoftness * 3;
    light.shadow.camera.updateProjectionMatrix();
    _disposeShadowMap(light);
  }

  function _configureShadow_Spot(light) {
    if (!light.shadow) return;
    const size = SHADOW_SIZES[_shadowQuality] || 2048;
    light.shadow.mapSize.set(size, size);
    light.shadow.camera.near = 0.3;
    light.shadow.camera.far  = 40;
    // Spot angle matches the light cone — keep fov slightly tighter than cone
    light.shadow.camera.fov  = THREE.MathUtils.radToDeg(light.angle) * 2.0;
    light.shadow.bias        =  0.0001;
    light.shadow.normalBias  =  0.04 + _shadowSoftness * 0.12;
    light.shadow.radius      =  1 + _shadowSoftness * 4;
    light.shadow.camera.updateProjectionMatrix();
    _disposeShadowMap(light);
  }

  // Route to the correct configurator
  function _configureShadow(light, lightType) {
    if (!light || !light.shadow) return;
    switch (lightType) {
      case 'directional': _configureShadow_Directional(light); break;
      case 'point':       _configureShadow_Point(light);       break;
      case 'spot':        _configureShadow_Spot(light);        break;
      default: break;
    }
  }

  // ══════════════════════════════════════════════════════
  //  VIEWPORT LIGHTING  (Blender-inspired editor look)
  //  Never casts shadows. Never selectable. Never in hierarchy.
  // ══════════════════════════════════════════════════════
  function _setupViewportLights() {
    // 1. Hemisphere — warm sky / cool ground gives gentle ambient fill
    const hemi = new THREE.HemisphereLight(0xdde8f0, 0x1a1a22, 0.80);
    hemi.name = '__vp_hemi__';
    _markHelper(hemi);
    _scene.add(hemi);
    _viewportLights.push({ light: hemi, name: 'viewport_hemi' });

    // 2. Key light — soft warm directional from upper-left (Blender default angle)
    const key = new THREE.DirectionalLight(0xfff5e8, 0.65);
    key.name = '__vp_key__';
    key.position.set(-2.5, 5, 3.5);
    key.castShadow    = false;   // viewport key NEVER casts shadows
    key.receiveShadow = false;
    _markHelper(key);
    _scene.add(key);
    _viewportLights.push({ light: key, name: 'viewport_key' });

    // 3. Subtle cool fill from lower-right to add depth / ground grading
    const fill = new THREE.DirectionalLight(0xb8cce0, 0.18);
    fill.name = '__vp_fill__';
    fill.position.set(3, -1.5, -2.5);
    fill.castShadow    = false;
    fill.receiveShadow = false;
    _markHelper(fill);
    _scene.add(fill);
    _viewportLights.push({ light: fill, name: 'viewport_fill' });
  }

  // ══════════════════════════════════════════════════════
  //  RENDERER SETUP
  // ══════════════════════════════════════════════════════
  function _configureRenderer() {
    if (!_renderer) return;
    _renderer.shadowMap.enabled           = _shadowsEnabled;
    _renderer.shadowMap.type              = THREE.PCFSoftShadowMap;
    _renderer.physicallyCorrectLights     = true;
    _renderer.toneMapping                 = THREE.ACESFilmicToneMapping;
    _renderer.outputEncoding              = THREE.sRGBEncoding;
    _renderer.toneMappingExposure         = 1.0;
  }

  // ══════════════════════════════════════════════════════
  //  SCENE OBJECT SHADOW SWEEP
  //  Only real mesh objects cast/receive shadows.
  //  All editor helpers, gizmos, overlays → shadows OFF.
  // ══════════════════════════════════════════════════════
  // ── Centralized mesh shadow configurator ─────────────────────────────────
  //  Call on ANY newly created mesh to match the current global shadow state.
  //  Used by primitives, duplicates, imports, and generated meshes.
  function configureMeshShadows(mesh) {
    if (!mesh || !mesh.isMesh) return;
    const isHelper =
      mesh.userData.nonSelectable ||
      mesh.userData.helperObject  ||
      mesh.userData.editOverlay   ||
      mesh.userData.gizmoIcon     ||
      mesh.userData.isOutline     ||
      mesh.userData.loopCutPreview||
      mesh.userData.gizmo         ||
      mesh.userData.gizmoHit      ||
      mesh.userData.managedLight  ||
      mesh.userData.sceneObjectType ||
      (typeof mesh.name === 'string' && (
        mesh.name.startsWith('__') ||
        mesh.name === 'TransformControlsGizmo'
      ));
    if (isHelper) {
      mesh.castShadow    = false;
      mesh.receiveShadow = false;
    } else {
      mesh.castShadow    = _shadowsEnabled;
      mesh.receiveShadow = _shadowsEnabled;
    }
  }

  function _refreshMeshShadows() {
    if (!_scene) return;
    _scene.traverse(obj => {
      // Determine if this is a real user mesh
      const isHelper =
        obj.userData.nonSelectable ||
        obj.userData.helperObject  ||
        obj.userData.editOverlay   ||
        obj.userData.gizmoIcon     ||
        obj.userData.isOutline     ||
        obj.userData.loopCutPreview||
        obj.userData.gizmo         ||
        obj.userData.gizmoHit      ||
        obj.userData.managedLight  ||
        (typeof obj.name === 'string' && (
          obj.name.startsWith('__') ||
          obj.name === 'TransformControlsGizmo'
        ));

      if (isHelper) {
        obj.castShadow    = false;
        obj.receiveShadow = false;
      } else if (obj.isMesh && !obj.userData.sceneObjectType) {
        // Real scene mesh — respect global shadow toggle
        obj.castShadow    = _shadowsEnabled;
        obj.receiveShadow = _shadowsEnabled;
      }
    });
    // Ensure the renderer re-renders shadow maps on the next frame
    if (_renderer) _renderer.shadowMap.needsUpdate = true;
  }

  // ══════════════════════════════════════════════════════
  //  LIGHT CONSTRUCTION  — per-type, independent
  // ══════════════════════════════════════════════════════

  function _buildDirectionalLight(color, intensity) {
    const light = new THREE.DirectionalLight(new THREE.Color(color), intensity);
    light.castShadow = true;
    _configureShadow_Directional(light);
    return light;
  }

  function _buildPointLight(color, intensity) {
    // distance=0 → infinite range; decay=2 → physically correct
    const light = new THREE.PointLight(new THREE.Color(color), intensity, 0, 2);
    light.castShadow = true;
    _configureShadow_Point(light);
    return light;
  }

  function _buildSpotLight(color, intensity) {
    // angle: 35°, penumbra: soft 20% edge
    const light = new THREE.SpotLight(
      new THREE.Color(color), intensity,
      0,              // distance — 0 = infinite
      Math.PI / 5.1,  // ~35° half-angle
      0.20,           // penumbra softness
      2               // physically correct decay
    );
    light.castShadow = true;
    _configureShadow_Spot(light);
    return light;
  }

  function _buildHemisphereLight(color, intensity) {
    // Ground color is a darker, desaturated version of the sky
    const sky    = new THREE.Color(color);
    const ground = sky.clone().multiplyScalar(0.18);
    const light  = new THREE.HemisphereLight(sky, ground, intensity);
    light.castShadow    = false;  // HemisphereLight cannot cast shadows
    light.receiveShadow = false;
    return light;
  }

  function _buildAreaLight(color, intensity) {
    // RectAreaLight: no built-in shadows in Three.js r128 — that's correct behaviour
    // We use it purely for diffuse/specular area illumination.
    // width=2, height=2 — user can't resize in this editor rev.
    if (typeof THREE.RectAreaLight === 'undefined') {
      // Fallback: point light with no shadow
      const fb = new THREE.PointLight(new THREE.Color(color), intensity, 0, 2);
      fb.castShadow = false;
      fb.userData.areaFallback = true;
      return fb;
    }
    const light = new THREE.RectAreaLight(new THREE.Color(color), intensity, 2, 2);
    light.castShadow    = false;  // RectAreaLight has no shadow support in r128
    light.receiveShadow = false;
    return light;
  }

  function _buildThreeLight(lightType, color, intensity) {
    switch (lightType) {
      case 'point':       return _buildPointLight(color, intensity);
      case 'spot':        return _buildSpotLight(color, intensity);
      case 'hemisphere':  return _buildHemisphereLight(color, intensity);
      case 'area':        return _buildAreaLight(color, intensity);
      case 'directional':
      default:            return _buildDirectionalLight(color, intensity);
    }
  }

  // ══════════════════════════════════════════════════════
  //  ADD LIGHT
  // ══════════════════════════════════════════════════════
  function addLight(lightType, props) {
    if (!_scene) { console.warn('[LightManager] init() not called'); return null; }

    lightType = lightType || 'directional';

    // Per-type sensible defaults
    const TYPE_DEFAULTS = {
      directional: { color:'#fff5e8', intensity:2.0,  position:{x:4,y:8,z:3},  castShadow:true  },
      point:       { color:'#ffffff', intensity:8.0,  position:{x:0,y:3,z:0},  castShadow:true  },
      spot:        { color:'#ffffff', intensity:10.0, position:{x:0,y:5,z:0},  castShadow:true  },
      hemisphere:  { color:'#aac8e8', intensity:0.8,  position:{x:0,y:5,z:0},  castShadow:false },
      area:        { color:'#ffffff', intensity:5.0,  position:{x:0,y:3,z:0},  castShadow:false },
    };
    const defaults = TYPE_DEFAULTS[lightType] || TYPE_DEFAULTS.directional;
    const p = Object.assign({}, defaults, props || {});

    _idCounter++;
    const typeLabels = { directional:'Sun', point:'Point', spot:'Spot', hemisphere:'Hemi', area:'Area' };
    const name = `${typeLabels[lightType] || 'Light'}.${String(_idCounter).padStart(3,'0')}`;

    // ── Node (Object3D gizmo container) ──────────────────────────────────
    const node = SceneManager.makeLightNode(name, p.position, {
      lightType, color: p.color, intensity: p.intensity, castShadow: p.castShadow,
    });
    node.visible = p.visible !== false;
    // Apply initial rotation if provided (used for directional lights to set sun angle)
    if (p.rotation) {
      node.rotation.set(
        isFinite(p.rotation.x) ? p.rotation.x : 0,
        isFinite(p.rotation.y) ? p.rotation.y : 0,
        isFinite(p.rotation.z) ? p.rotation.z : 0
      );
    }
    // Mark node itself as helper so its gizmo parts never shadow-cast
    _markHelper(node);

    // ── Three.js light ────────────────────────────────────────────────────
    const light = _buildThreeLight(lightType, p.color, p.intensity);
    light.name = `__light__${name}`;
    light.userData.nonSelectable = true;
    light.userData.managedLight  = true;
    light.userData.helperObject  = true;

    // Store per-light intended shadow state independent of global toggle
    light.userData.shadowEnabled = !!p.castShadow;
    // Final castShadow: per-light intent AND global toggle
    light.castShadow = !!p.castShadow && _shadowsEnabled;
    FDEBUG.log('shadows', 'addLight', lightType, 'castShadow:', light.castShadow);

    // ── Directional light: world-space, rotation-driven, NEVER a child of node ──
    // A DirectionalLight parented to a moving Object3D inherits world position and
    // produces point-light-style proximity behaviour. Instead we keep the light
    // directly in the scene and derive its direction purely from node.rotation each
    // frame — matching real-world sun behaviour (direction only, no distance effect).
    if (lightType === 'directional') {
      // Sun-radius distance: large enough that the orthographic shadow frustum covers
      // the whole scene regardless of where the gizmo node is dragged.
      const SUN_DISTANCE = 50;

      // Derive initial position from the node's rotation quaternion.
      // The "default" sun direction is +Y (straight down); we rotate -Z forward
      // (Three.js convention for directional lights pointing toward origin).
      const _sunDir = new THREE.Vector3(0, 1, 0)
        .applyQuaternion(node.quaternion)
        .normalize();

      light.position.copy(_sunDir.clone().multiplyScalar(SUN_DISTANCE));

      // Target stays at world origin — the sun always illuminates the scene centre.
      const target = new THREE.Object3D();
      target.name = `__dirtarget__${name}`;
      target.position.set(0, 0, 0);
      _markHelper(target);
      _scene.add(target);
      light.target = target;

      // Store sun distance so the per-frame sync can use it
      light.userData.sunDistance = SUN_DISTANCE;
      // Tag so the render loop can identify this as a world-space directional light
      light.userData.worldSpaceDirectional = true;
      // Back-reference to the controlling gizmo node (for rotation sync)
      light.userData.controlNode = node;
      // Store reference on node too for quick lookup
      node.userData.worldSpaceLight = light;

      // Add the light DIRECTLY to the scene — NOT to node
      _scene.add(light);

      // Reconfigure shadow frustum: large orthographic volume for parallel shadows
      _configureShadow_Directional(light);

    } else if (lightType === 'spot') {
      // ── SpotLight: target points downward from position ─────────────────
      const target = new THREE.Object3D();
      target.name = `__spottarget__${name}`;
      target.position.set(p.position.x || 0, 0, p.position.z || 0);
      _markHelper(target);
      _scene.add(target);
      light.target = target;
      node.add(light);
    } else {
      // ── All other light types: parented to node as before ───────────────
      node.add(light);
    }

    // Sync userData on the node
    node.userData.lightColor     = p.color;
    node.userData.lightIntensity = p.intensity;
    node.userData.lightType      = lightType;
    node.userData.castShadow     = p.castShadow;
    node.userData.shadowEnabled  = !!p.castShadow;

    const entry = { id: _idCounter, node, light, lightType, props: Object.assign({}, p) };
    _sceneLights.push(entry);
    SceneManager.addObject(node, 'light');

    // Single shadow sweep: configure all meshes, then force shadow map regen
    _refreshMeshShadows();
    if (light.castShadow && _renderer) {
      _renderer.shadowMap.needsUpdate = true;
      if (light.shadow) light.shadow.needsUpdate = true;
    }
    if (typeof RenderLoop !== 'undefined' && RenderLoop.resetShadowWarmup) RenderLoop.resetShadowWarmup();
    EventBus.emit('lightmanager:changed');
    return { node, light };
  }

  // ══════════════════════════════════════════════════════
  //  REMOVE LIGHT
  // ══════════════════════════════════════════════════════
  function removeLight(node) {
    const idx = _sceneLights.findIndex(e => e.node === node);
    if (idx === -1) return;
    const entry = _sceneLights[idx];

    // Clean up Three.js light
    _disposeShadowMap(entry.light);

    // Remove orphaned directional/spot targets from the scene
    if (entry.light && entry.light.target && entry.light.target.name &&
        entry.light.target.name.startsWith('__')) {
      _scene.remove(entry.light.target);
    }

    // World-space directional lights are direct scene children — remove them too
    if (entry.lightType === 'directional' && entry.light.userData.worldSpaceDirectional) {
      _scene.remove(entry.light);
    }

    _sceneLights.splice(idx, 1);
    SceneManager.removeSceneObject(node);
    EventBus.emit('lightmanager:changed');
  }

  // ══════════════════════════════════════════════════════
  //  UPDATE LIGHT
  // ══════════════════════════════════════════════════════
  function updateLight(node, props) {
    const entry = _sceneLights.find(e => e.node === node);
    if (!entry) return;
    const { light, lightType } = entry;

    if (props.color !== undefined) {
      if (light.color) light.color.set(props.color);
      node.userData.lightColor = props.color;
    }

    if (props.intensity !== undefined) {
      light.intensity = props.intensity;
      node.userData.lightIntensity = props.intensity;
    }

    if (props.position !== undefined) {
      // Move the gizmo node in world space (for visual reference / UX)
      node.position.set(
        isFinite(props.position.x) ? props.position.x : 0,
        isFinite(props.position.y) ? props.position.y : 0,
        isFinite(props.position.z) ? props.position.z : 0
      );
      // For world-space directional lights: moving the node moves only the GIZMO.
      // The actual light position is driven by rotation, not position — so we do
      // NOT update light.position here. syncDirectionalLights() handles it per-frame.
      if (lightType !== 'directional' || !light.userData.worldSpaceDirectional) {
        // Update spot target position to maintain downward aim
        if (lightType === 'spot' && light.target) {
          light.target.position.set(
            isFinite(props.position.x) ? props.position.x : 0, 0,
            isFinite(props.position.z) ? props.position.z : 0
          );
        }
      }
    }

    if (props.visible !== undefined) {
      node.visible = props.visible;
    }

    if (props.castShadow !== undefined) {
      node.userData.castShadow    = props.castShadow;
      node.userData.shadowEnabled = !!props.castShadow;
      light.userData.shadowEnabled = !!props.castShadow;
      // Only shadow-capable types
      const canShadow = (lightType === 'directional' || lightType === 'point' || lightType === 'spot');
      light.castShadow = canShadow && !!props.castShadow && _shadowsEnabled;
      if (light.castShadow) {
        _configureShadow(light, lightType);
        if (_renderer) _renderer.shadowMap.needsUpdate = true;
        if (light.shadow) light.shadow.needsUpdate = true;
      } else {
        _disposeShadowMap(light);
      }
    }

    // If spot angle changed, reconfigure shadow camera fov
    if (props.angle !== undefined && lightType === 'spot') {
      light.angle = props.angle;
      if (light.castShadow) _configureShadow_Spot(light);
    }

    Object.assign(entry.props, props);
    EventBus.emit('lightmanager:changed');
  }

  // ══════════════════════════════════════════════════════
  //  GLOBAL SHADOW TOGGLE
  // ══════════════════════════════════════════════════════
  function setShadowsEnabled(enabled) {
    _shadowsEnabled = !!enabled;
    FDEBUG.log('shadows', 'setShadowsEnabled', _shadowsEnabled);
    if (_renderer) {
      _renderer.shadowMap.enabled = _shadowsEnabled;
      // Force Three.js to re-render all shadow maps on the next frame
      _renderer.shadowMap.needsUpdate = true;
    }
    _sceneLights.forEach(entry => {
      const canShadow = (entry.lightType === 'directional' || entry.lightType === 'point' || entry.lightType === 'spot');
      if (canShadow) {
        // Per-light intent is stored in userData.shadowEnabled
        const perLightWants = !!(entry.node.userData.shadowEnabled);
        entry.light.castShadow = _shadowsEnabled && perLightWants;
        if (entry.light.castShadow) {
          _configureShadow(entry.light, entry.lightType);
          if (entry.light.shadow) entry.light.shadow.needsUpdate = true;
        } else {
          _disposeShadowMap(entry.light);
        }
      }
    });
    EventBus.emit('lightmanager:changed');
  }

  // ══════════════════════════════════════════════════════
  //  SHADOW QUALITY
  // ══════════════════════════════════════════════════════
  function setShadowQuality(quality) {
    _shadowQuality = quality;
    _sceneLights.forEach(entry => {
      if (entry.light.castShadow && entry.light.shadow) {
        _configureShadow(entry.light, entry.lightType);
      }
    });
  }

  // ══════════════════════════════════════════════════════
  //  SHADOW SOFTNESS  (PCFSoft blur radius + normalBias)
  // ══════════════════════════════════════════════════════
  function setShadowSoftness(softness) {
    _shadowSoftness = Math.max(0, Math.min(1, softness));
    _sceneLights.forEach(entry => {
      if (entry.light.castShadow && entry.light.shadow) {
        _configureShadow(entry.light, entry.lightType);
      }
    });
  }

  function getShadowSoftness() { return _shadowSoftness; }

  // ══════════════════════════════════════════════════════
  //  SYNC WORLD-SPACE DIRECTIONAL LIGHTS
  //  Called every render frame. For each directional light
  //  that lives directly in the scene (not as a node child),
  //  re-derive its world-space position from the controlling
  //  gizmo node's rotation quaternion.
  //  Lighting direction = node rotation, NOT node position.
  // ══════════════════════════════════════════════════════
  const _sunDirVec = new THREE.Vector3();
  function syncDirectionalLights() {
    for (let i = 0, n = _sceneLights.length; i < n; i++) {
      const entry = _sceneLights[i];
      if (entry.lightType !== 'directional') continue;
      const light = entry.light;
      if (!light.userData.worldSpaceDirectional) continue;

      const node = light.userData.controlNode;
      if (!node) continue;

      // Get the node's current world quaternion (handles any parent transforms)
      node.updateWorldMatrix(true, false);
      const worldQuat = new THREE.Quaternion();
      node.matrixWorld.decompose(new THREE.Vector3(), worldQuat, new THREE.Vector3());

      // Rotate the default "up" direction by the node's world rotation.
      // This maps node rotation directly to sun direction — pure directional behaviour.
      _sunDirVec.set(0, 1, 0).applyQuaternion(worldQuat).normalize();

      const dist = light.userData.sunDistance || 50;
      // Light position = direction * large distance → always far away, direction only matters
      light.position.set(
        _sunDirVec.x * dist,
        _sunDirVec.y * dist,
        _sunDirVec.z * dist
      );
      // Target stays at world origin — shadows always parallel, never radial
      if (light.target) light.target.position.set(0, 0, 0);
    }
  }

  // ── Getters ───────────────────────────────────────────────────────────────
  function getSceneLights()    { return _sceneLights.slice(); }
  function getShadowsEnabled() { return _shadowsEnabled; }
  function getShadowQuality()  { return _shadowQuality; }

  // ── Serialise / Deserialise ───────────────────────────────────────────────
  function serialise() {
    return { shadowsEnabled: _shadowsEnabled, shadowQuality: _shadowQuality, shadowSoftness: _shadowSoftness };
  }
  function deserialise(data) {
    if (!data) return;
    if (typeof data.shadowsEnabled === 'boolean') setShadowsEnabled(data.shadowsEnabled);
    if (data.shadowQuality) setShadowQuality(data.shadowQuality);
    if (typeof data.shadowSoftness === 'number') setShadowSoftness(data.shadowSoftness);
  }

  // ── Init ──────────────────────────────────────────────────────────────────
  function init(scene, renderer) {
    _scene    = scene;
    _renderer = renderer;
    // Configure renderer first — shadow system must be active before any lights are added
    _configureRenderer();
    _setupViewportLights();
    _refreshMeshShadows();
    // Ensure shadow map needsUpdate so first frame renders shadows correctly
    if (_renderer) _renderer.shadowMap.needsUpdate = true;

    // Auto-configure shadows on any object added to the scene — catches all
    // add paths (primitives, imports, paste) without each caller needing to call
    // configureMeshShadows manually.
    EventBus.on('scene:objectAdded', node => {
      if (node && node.isMesh) {
        configureMeshShadows(node);
        if (_renderer) _renderer.shadowMap.needsUpdate = true;
      }
    });
  }

  return {
    init,
    addLight,
    removeLight,
    updateLight,
    setShadowsEnabled,
    setShadowQuality,
    setShadowSoftness,
    getShadowsEnabled,
    getShadowQuality,
    getShadowSoftness,
    getSceneLights,
    serialise,
    deserialise,
    configureMeshShadows,
    syncDirectionalLights,
    _getViewportLight(name) {
      const e = _viewportLights.find(v => v.name === name);
      return e ? e.light : null;
    },
  };
})();


// ══════════════════════════════════════════════════════
//  LightSystem — UI layer for LightManager
//  Handles the Lights tab panel: collapsibles, add buttons,
//  environment controls, per-light list, shadow/quality toggles,
//  post effects (exposure). All Three.js work goes via LightManager.
// ══════════════════════════════════════════════════════
