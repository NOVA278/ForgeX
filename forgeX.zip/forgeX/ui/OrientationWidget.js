'use strict';
const OrientationWidget = (() => {
  let _ctx=null, _camera=null;
  const _size=68, _center=34, _radius=24;
  const _axes=[
    {vec:new THREE.Vector3(1,0,0),label:'X',color:'#cc2222',neg:'#661111'},
    {vec:new THREE.Vector3(0,1,0),label:'Y',color:'#1a9933',neg:'#0d4d1a'},
    {vec:new THREE.Vector3(0,0,1),label:'Z',color:'#1a44cc',neg:'#0d2266'},
  ];

  function init(canvas,camera){ _ctx=canvas.getContext('2d'); _camera=camera; }

  function render(){
    if(!_ctx||!_camera) return;
    const ctx=_ctx;
    ctx.clearRect(0,0,_size,_size);
    ctx.beginPath(); ctx.arc(_center,_center,_center-1,0,Math.PI*2);
    ctx.fillStyle='rgba(28,28,30,0.75)'; ctx.fill();
    ctx.strokeStyle='#3a3a42'; ctx.lineWidth=1; ctx.stroke();
    const mat=new THREE.Matrix4().extractRotation(_camera.matrixWorldInverse);
    const projected=_axes.map(({vec,label,color,neg})=>{
      const v=vec.clone().applyMatrix4(mat);
      return {x:_center+v.x*_radius,y:_center-v.y*_radius,z:v.z,label,color,neg};
    });
    [...projected].sort((a,b)=>a.z-b.z).forEach(({x,y,z,label,color,neg})=>{
      const isFront=z>0, col=isFront?color:neg;
      ctx.beginPath(); ctx.moveTo(_center,_center); ctx.lineTo(x,y);
      ctx.strokeStyle=col; ctx.lineWidth=isFront?2.5:1.5; ctx.stroke();
      ctx.beginPath(); ctx.arc(x,y,isFront?4.5:3,0,Math.PI*2); ctx.fillStyle=col; ctx.fill();
      if(isFront){ ctx.fillStyle='#dddde2'; ctx.font='bold 8.5px IBM Plex Mono, monospace'; ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText(label,x,y); }
    });
  }

  return { init, render };
})();


// ══════════════════════════════════════════════════════
//  HoverOutline — subtle hover glow on object mouseover
// ══════════════════════════════════════════════════════
