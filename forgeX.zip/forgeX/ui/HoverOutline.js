'use strict';
const HoverOutline = (() => {
  let _scene = null, _canvas = null, _camera = null;
  let _hoverMesh = null, _wireMesh = null;
  const _ray = new THREE.Raycaster();

  function init(scene, canvas, camera) {
    _scene = scene; _canvas = canvas; _camera = camera;

    canvas.addEventListener('mousemove', _onMouseMove, { passive: true });
    canvas.addEventListener('mouseleave', _clear);
  }

  function _onMouseMove(e) {
    if (!_scene || !_canvas || !_camera) return;
    const r = _canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(
      ((e.clientX - r.left) / r.width) * 2 - 1,
      -((e.clientY - r.top) / r.height) * 2 + 1
    );
    _ray.setFromCamera(ndc, _camera);
    const meshes = SceneManager.getMeshObjects().filter(o =>
      !o.userData.nonSelectable && !o.userData.editOverlay
    );
    const hits = _ray.intersectObjects(meshes, false);
    const hit = hits.length > 0 ? hits[0].object : null;

    // Don't hover-highlight already selected objects
    const sel = SelectionSystem.getMultiSelected();
    if (hit && !sel.includes(hit)) {
      _setHover(hit);
    } else {
      _clear();
    }
  }

  function _setHover(mesh) {
    if (_hoverMesh === mesh) return;
    _clear();
    _hoverMesh = mesh;
    _wireMesh = new THREE.Mesh(
      mesh.geometry,
      new THREE.MeshBasicMaterial({
        color: 0xaaccff, wireframe: true,
        depthTest: true, depthWrite: false,
        transparent: true, opacity: 0.22,
        polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2,
      })
    );
    _wireMesh.renderOrder = 996;
    _wireMesh.userData.nonSelectable = true;
    _wireMesh.userData.isOutline = true;
    _wireMesh.castShadow = false; _wireMesh.receiveShadow = false;
    _wireMesh.matrixAutoUpdate = false;
    _wireMesh.matrix.copy(mesh.matrixWorld);
    _scene.add(_wireMesh);
  }

  function _clear() {
    if (_wireMesh && _scene) { _scene.remove(_wireMesh); _wireMesh.material.dispose(); _wireMesh = null; }
    _hoverMesh = null;
  }

  function tick() {
    // Keep hover wire matrix in sync if object moved
    if (_wireMesh && _hoverMesh) {
      _wireMesh.matrix.copy(_hoverMesh.matrixWorld);
      // Auto-clear if object is now selected
      if (SelectionSystem.getMultiSelected().includes(_hoverMesh)) _clear();
    }
  }

  let _enabled = true;
  function setEnabled(v) { _enabled = !!v; if (!v) _clear(); }
  function _guardedTick() { if (_enabled) tick(); }
  return { init, tick: _guardedTick, setEnabled };
})();
// ══════════════════════════════════════════════════════
//  RenderLoop
// ══════════════════════════════════════════════════════
