'use strict';
const RightSidebarTabs = (() => {
  const TABS = [
    { btn: 'tab-btn-properties', panel: 'tab-panel-properties' },
    { btn: 'tab-btn-materials',  panel: 'tab-panel-materials'  },
    { btn: 'tab-btn-lights',     panel: 'tab-panel-lights'     },
  ];

  function _activate(activeId) {
    TABS.forEach(({ btn, panel }) => {
      const b = document.getElementById(btn);
      const p = document.getElementById(panel);
      const isActive = btn === activeId;
      if (b) { b.classList.toggle('active', isActive); b.setAttribute('aria-selected', isActive); }
      if (p) p.classList.toggle('active', isActive);
    });
  }

  function init() {
    TABS.forEach(({ btn }) => {
      const b = document.getElementById(btn);
      if (b) b.addEventListener('click', () => _activate(btn));
    });
  }

  return { init, activate: _activate };
})();


