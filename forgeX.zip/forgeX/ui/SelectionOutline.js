'use strict';
const SelectionOutline = (() => {
  // Each entry: { thick, thin } — two wire meshes per object for depth+glow effect
  const _outlines = new Map();
  let _scene = null;

  function init(scene) { _scene = scene; }

  function _makeWireMat(color, opacity, offsetFactor, offsetUnits) {
    const m = new THREE.MeshBasicMaterial({
      color, wireframe: true,
      depthTest: true, depthWrite: false,
      transparent: true, opacity,
      polygonOffset: true,
      polygonOffsetFactor: offsetFactor,
      polygonOffsetUnits: offsetUnits,
    });
    return m;
  }

  function _getOrCreate(mesh) {
    if (_outlines.has(mesh.uuid)) return _outlines.get(mesh.uuid);
    // Outer glow layer (wider offset, more transparent)
    const glow = new THREE.Mesh(mesh.geometry, _makeWireMat(0x4499ff, 0.18, -6, -6));
    glow.renderOrder = 997;
    glow.userData.nonSelectable = true; glow.userData.isOutline = true;
    glow.castShadow = false; glow.receiveShadow = false;
    // Inner crisp layer (tight offset, opaque)
    const crisp = new THREE.Mesh(mesh.geometry, _makeWireMat(0x4499ff, 0.82, -3, -3));
    crisp.renderOrder = 998;
    crisp.userData.nonSelectable = true; crisp.userData.isOutline = true;
    crisp.castShadow = false; crisp.receiveShadow = false;
    if (_scene) { _scene.add(glow); _scene.add(crisp); }
    _outlines.set(mesh.uuid, { glow, crisp });
    return { glow, crisp };
  }

  function _remove(uuid) {
    const entry = _outlines.get(uuid);
    if (entry && _scene) {
      _scene.remove(entry.glow); entry.glow.material.dispose();
      _scene.remove(entry.crisp); entry.crisp.material.dispose();
      _outlines.delete(uuid);
    }
  }

  function tick(selectedMeshes, inEditMode) {
    if (!_scene) return;
    const active = SelectionSystem.getSelected();
    const wanted = selectedMeshes.filter(o =>
      o && o.isMesh && !o.userData.sceneObjectType &&
      !o.userData.isOutline && !o.userData.nonSelectable && !o.userData.editOverlay
    );
    const wantedUuids = new Set(wanted.map(m => m.uuid));
    const toRemove = [];
    _outlines.forEach((_, uuid) => { if (!wantedUuids.has(uuid)) toRemove.push(uuid); });
    toRemove.forEach(_remove);
    wanted.forEach(mesh => {
      const { glow, crisp } = _getOrCreate(mesh);
      glow.matrixAutoUpdate = false; glow.matrix.copy(mesh.matrixWorld);
      crisp.matrixAutoUpdate = false; crisp.matrix.copy(mesh.matrixWorld);
      const isActive = mesh === active;
      glow.visible = _glowEnabled;
      if (inEditMode) {
        // Edit mode: warm orange wireframe
        glow.material.color.setHex(0xff7020);  glow.material.opacity = 0.14;
        crisp.material.color.setHex(0xff8030); crisp.material.opacity = 0.45;
      } else if (isActive) {
        // Primary selection: electric blue with glow
        glow.material.color.setHex(0x5baaff);  glow.material.opacity = 0.22;
        crisp.material.color.setHex(0x4d8ef5); crisp.material.opacity = 0.90;
      } else {
        // Secondary selected: amber
        glow.material.color.setHex(0xffb840);  glow.material.opacity = 0.15;
        crisp.material.color.setHex(0xf5aa30); crisp.material.opacity = 0.62;
      }
    });
  }

  let _glowEnabled = true;
  function setGlowEnabled(v) { _glowEnabled = !!v; }

  function clear() { [..._outlines.keys()].forEach(_remove); }

  return { init, tick, clear, setGlowEnabled };
})();

// ══════════════════════════════════════════════════════
//  InputControls
// ══════════════════════════════════════════════════════
