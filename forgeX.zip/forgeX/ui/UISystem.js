'use strict';
const UISystem = (() => {
  let _propUpdatePending = false;

  // ── Outliner ───────────────────────────────────────────────────────────────
  // Shows: mesh objects, then scene lights.

  function refreshOutliner() {
    const container = document.getElementById('outliner'); if (!container) return;
    const meshes    = SceneManager.getMeshObjects();
    const lights    = SceneManager.getLightObjects();
    const allItems  = [...meshes, ...lights];
    const selected  = SelectionSystem.getSelected();

    if (allItems.length === 0) {
      container.innerHTML = '<div class="outliner-empty">No objects in scene.<br>Add a mesh below.</div>';
      return;
    }

    container.innerHTML = '';

    // Mesh icons
    const meshIcons = { Cube: '🧊', Sphere: '⭕', Cylinder: '🔵', Cone: '🔺', Torus: '🍩', Plane: '📐' };

    allItems.forEach(obj => {
      const item = document.createElement('div');
      item.className = 'outliner-item' + (obj === selected ? ' selected' : '');

      let icon, typeLabel;
      const sot = obj.userData.sceneObjectType;
      if (sot === 'light') {
        icon = '💡'; typeLabel = 'Light';
      } else {
        icon = meshIcons[obj.userData.typeName] || '🔷';
        typeLabel = obj.userData.typeName || 'Mesh';
      }

      item.innerHTML = `<span class="outliner-icon">${icon}</span><span class="outliner-label">${obj.name}</span><span class="outliner-type">${typeLabel}</span>`;
      item.addEventListener('click', () => SelectionSystem.selectObject(obj));
      container.appendChild(item);
    });
  }

  // ── Properties panel ──────────────────────────────────────────────────────

  function refreshProps(obj) {
    const empty   = document.getElementById('props-empty');
    const content = document.getElementById('props-content');
    const lightPanel = document.getElementById('props-light-panel');
    if (!empty || !content) return;

    // Hide specialized panels by default
    if (lightPanel) lightPanel.style.display = 'none';
    const _camPanel = document.getElementById('props-camera-panel');
    if (_camPanel) _camPanel.classList.remove('visible');

    if (EditModeSystem.isActive()) {
      empty.style.display = 'none'; content.style.display = 'none';
      MaterialSystem.refreshUI(null); return;
    }
    if (!obj) {
      empty.style.display = ''; content.style.display = 'none';
      MaterialSystem.refreshUI(null); return;
    }

    empty.style.display = 'none'; content.style.display = '';

    const sot = obj.userData.sceneObjectType;
    const r2d = v => parseFloat((v * 180 / Math.PI).toFixed(1));
    const f   = v => parseFloat(v.toFixed(3));

    // Name
    const nameInput = document.getElementById('obj-name-input');
    if (nameInput) nameInput.value = obj.name;

    // Transform (shared across all scene object types)
    document.getElementById('prop-px').value = f(obj.position.x);
    document.getElementById('prop-py').value = f(obj.position.y);
    document.getElementById('prop-pz').value = f(obj.position.z);
    document.getElementById('prop-rx').value = r2d(obj.rotation.x);
    document.getElementById('prop-ry').value = r2d(obj.rotation.y);
    document.getElementById('prop-rz').value = r2d(obj.rotation.z);
    document.getElementById('prop-sx').value = f(obj.scale.x);
    document.getElementById('prop-sy').value = f(obj.scale.y);
    document.getElementById('prop-sz').value = f(obj.scale.z);

    // Camera props panel
    const camPanel = document.getElementById('props-camera-panel');
    if (camPanel) camPanel.classList.toggle('visible', sot === 'camera');

    if (sot === 'camera') {
      document.getElementById('info-type').textContent  = 'Camera';
      document.getElementById('info-verts').textContent = '—';
      document.getElementById('info-faces').textContent = '—';
      MaterialSystem.refreshUI(null);
      // Populate camera-specific fields
      const fovSlider = document.getElementById('cam-fov-slider');
      const fovVal    = document.getElementById('cam-fov-val');
      const nearInput = document.getElementById('cam-near-input');
      const farInput  = document.getElementById('cam-far-input');
      const activeBadge = document.getElementById('cam-active-badge');
      const cam = obj.userData._perspCamera;
      if (cam) {
        if (fovSlider) fovSlider.value = Math.round(cam.fov);
        if (fovVal)    fovVal.textContent = Math.round(cam.fov) + '°';
        if (nearInput) nearInput.value = cam.near;
        if (farInput)  farInput.value  = cam.far;
      }
      if (activeBadge) activeBadge.style.display =
        (typeof SceneCameraSystem !== 'undefined' && SceneCameraSystem.isPreviewActive()) ? '' : 'none';

    } else if (sot === 'light') {
      document.getElementById('info-type').textContent = 'Light';
      document.getElementById('info-verts').textContent = '—';
      document.getElementById('info-faces').textContent = '—';
      MaterialSystem.refreshUI(null);

    } else {
      // Regular mesh
      document.getElementById('info-type').textContent  = obj.userData.typeName || 'Mesh';
      const info = ObjectManager.getGeomInfo(obj);
      document.getElementById('info-verts').textContent = info.verts;
      document.getElementById('info-faces').textContent = info.faces;
      MaterialSystem.refreshUI(obj);
    }
  }

  function schedulePropUpdate(obj) {
    if (_propUpdatePending) return;
    _propUpdatePending = true;
    requestAnimationFrame(() => { _propUpdatePending = false; refreshProps(obj); });
  }

  function updateStatus(selected) {
    const objCount = SceneManager.getMeshObjects().length;
    const inEdit   = EditModeSystem.isActive();
    const multiSel = SelectionSystem.getMultiSelected();
    document.getElementById('status-objects').textContent  = objCount;
    let selLabel;
    if (inEdit) {
      selLabel = EditModeSystem.getMesh().name;
    } else if (multiSel.length > 1) {
      selLabel = `${selected ? selected.name : '?'} (+${multiSel.length - 1})`;
    } else if (selected) {
      selLabel = selected.name;
    } else {
      selLabel = 'None';
    }
    document.getElementById('status-selected').textContent = selLabel;
    document.getElementById('status-mode-label').textContent = inEdit ? 'Edit' : 'Object';
    const dot = document.getElementById('status-dot');
    if (dot) dot.classList.toggle('edit', inEdit);
  }

  function updateFPS(fps) { const el = document.getElementById('fps-chip'); if (el) el.textContent = `${fps} fps`; }

  let _pillTimer = null;
  function showModePill(label, isEdit = false) {
    const pill = document.getElementById('mode-pill'); if (!pill) return;
    pill.textContent = label; pill.className = 'mode-pill visible' + (isEdit ? ' edit-mode' : '');
    clearTimeout(_pillTimer); _pillTimer = setTimeout(() => pill.classList.remove('visible'), 1600);
  }

  function bindPropInputs() {
    // Apply transform to whatever is currently selected (works for meshes, cameras, lights)
    const applyProp = fn => {
      const obj = SelectionSystem.getSelected(); if (!obj) return;
      fn(obj);
      // For mesh objects, also sync gizmo and emit transform event
      if (!obj.userData.sceneObjectType) {
        TransformControlsModule.syncToObject(obj);
        EventBus.emit('transform:changed', obj);
      } else {
        // For scene objects, sync gizmo and emit transform event
        TransformControlsModule.syncToObject(obj);
        EventBus.emit('transform:changed', obj);
      }
    };
    const bindNum = (id, fn) => { const el = document.getElementById(id); if (el) el.addEventListener('input', () => applyProp(fn)); };
    const d2r = v => v * Math.PI / 180;
    bindNum('prop-px', obj => obj.position.x = parseFloat(document.getElementById('prop-px').value) || 0);
    bindNum('prop-py', obj => obj.position.y = parseFloat(document.getElementById('prop-py').value) || 0);
    bindNum('prop-pz', obj => obj.position.z = parseFloat(document.getElementById('prop-pz').value) || 0);
    bindNum('prop-rx', obj => obj.rotation.x = d2r(parseFloat(document.getElementById('prop-rx').value) || 0));
    bindNum('prop-ry', obj => obj.rotation.y = d2r(parseFloat(document.getElementById('prop-ry').value) || 0));
    bindNum('prop-rz', obj => obj.rotation.z = d2r(parseFloat(document.getElementById('prop-rz').value) || 0));
    bindNum('prop-sx', obj => obj.scale.x = parseFloat(document.getElementById('prop-sx').value) || 1);
    bindNum('prop-sy', obj => obj.scale.y = parseFloat(document.getElementById('prop-sy').value) || 1);
    bindNum('prop-sz', obj => obj.scale.z = parseFloat(document.getElementById('prop-sz').value) || 1);
    const nameInput = document.getElementById('obj-name-input');
    if (nameInput) nameInput.addEventListener('input', () => {
      const obj = SelectionSystem.getSelected(); if (obj) { obj.name = nameInput.value; refreshOutliner(); }
    });
  }

  return { refreshOutliner, refreshProps, schedulePropUpdate, updateStatus, updateFPS, showModePill, bindPropInputs };
})();

// ══════════════════════════════════════════════════════
//  OrientationWidget
// ══════════════════════════════════════════════════════
