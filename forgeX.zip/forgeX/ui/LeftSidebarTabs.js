'use strict';
const LeftSidebarTabs = (() => {
  const TABS = [
    { btn: 'left-tab-btn-hierarchy', panel: 'left-tab-panel-hierarchy' },
    { btn: 'left-tab-btn-addmesh',   panel: 'left-tab-panel-addmesh'   },
  ];

  function _activate(activeBtnId) {
    TABS.forEach(({ btn, panel }) => {
      const b = document.getElementById(btn);
      const p = document.getElementById(panel);
      const isActive = btn === activeBtnId;
      if (b) { b.classList.toggle('active', isActive); b.setAttribute('aria-selected', isActive); }
      if (p) { p.classList.toggle('active', isActive); }
    });
    // Update disabled note in Add Mesh tab
    const note = document.getElementById('addmesh-edit-note');
    if (note) note.classList.toggle('visible', activeBtnId === 'left-tab-btn-addmesh' && EditModeSystem.isActive());
  }

  function init() {
    TABS.forEach(({ btn }) => {
      const b = document.getElementById(btn);
      if (b) b.addEventListener('click', () => _activate(btn));
    });

    // When edit mode changes, update add-mesh note and button states
    EventBus.on('editmode:changed', (active) => {
      const note = document.getElementById('addmesh-edit-note');
      if (note) note.classList.toggle('visible', active);
      document.querySelectorAll('.add-btn-v2[data-prim]').forEach(b => b.disabled = active);
    });
  }

  return { init, activate: _activate };
})();

// ══════════════════════════════════════════════════════
//  HierarchySystem — full-featured scene hierarchy tree
// ══════════════════════════════════════════════════════
