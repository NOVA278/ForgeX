'use strict';
const ViewportSettings = (() => {
  const _state = { grid: true, axes: true, vignette: true, hover: true, glow: true };

  function init() {
    const btn   = document.getElementById('vp-settings-btn');
    const panel = document.getElementById('vp-settings-panel');
    if (!btn || !panel) return;

    // Toggle panel
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const open = panel.classList.toggle('open');
      btn.classList.toggle('active', open);
    });
    document.addEventListener('click', e => {
      if (!btn.contains(e.target) && !panel.contains(e.target)) {
        panel.classList.remove('open'); btn.classList.remove('active');
      }
    });
    document.addEventListener('touchstart', e => {
      if (!btn.contains(e.target) && !panel.contains(e.target)) {
        panel.classList.remove('open'); btn.classList.remove('active');
      }
    }, { passive: true });

    // Wire each toggle
    function _wire(id, key, fn) {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('click', () => {
        _state[key] = !_state[key];
        el.classList.toggle('checked', _state[key]);
        fn(_state[key]);
      });
    }

    _wire('vps-grid', 'grid', on => {
      const scene = SceneManager.getScene(); if (!scene) return;
      ['__grid__', '__subgrid__'].forEach(n => {
        const g = scene.getObjectByName(n); if (g) g.visible = on;
      });
    });

    _wire('vps-axes', 'axes', on => {
      const scene = SceneManager.getScene(); if (!scene) return;
      scene.children.filter(c => c.userData.isAxisLine).forEach(l => { l.visible = on; });
    });

    _wire('vps-vignette', 'vignette', on => {
      const el = document.getElementById('viewport-vignette');
      if (el) el.style.opacity = on ? '1' : '0';
    });

    _wire('vps-hover', 'hover', on => {
      // Toggle hover outline: controlled via flag on HoverOutline
      if (typeof HoverOutline !== 'undefined') HoverOutline.setEnabled(on);
    });

    _wire('vps-glow', 'glow', on => {
      // Toggle glow layer on selection outline
      if (typeof SelectionOutline !== 'undefined') SelectionOutline.setGlowEnabled(on);
    });
  }

  return { init };
})();

// ══════════════════════════════════════════════════════
//  RightSidebarTabs — tab switching for the right panel
// ══════════════════════════════════════════════════════
