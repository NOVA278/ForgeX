'use strict';
const HierarchySystem = (() => {

  // ── State ────────────────────────────────────────────
  const _hidden    = new Set();   // hidden UUIDs
  const _locked    = new Set();   // locked UUIDs
  const _collapsed = new Set();   // collapsed UUIDs (parents + collections)

  // Collections: separate from parent/child — organisational folders only
  // { uuid:string, name:string, memberUuids:string[] }
  let _collections = [];
  let _colCounter  = 0;

  // Parent/child relationships stored separately from Three.js scene graph
  // (Three.js parenting would change local-space coords; we track it ourselves
  //  and apply world-space inheritance on transform changes)
  // _parentOf[childUuid] = parentUuid
  // _childrenOf[parentUuid] = [childUuid, ...]
  const _parentOf   = {};   // childUuid → parentUuid
  const _childrenOf = {};   // parentUuid → childUuid[]

  // Drag state
  let _dragSrc = null;  // { uuid, isCollection:bool }

  // ── SVG icons ─────────────────────────────────────────
  const ICONS = {
    mesh:       `<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M6 1L10.5 3.5V8.5L6 11L1.5 8.5V3.5L6 1Z" stroke="currentColor" stroke-width="1.1" stroke-linejoin="round"/><path d="M6 1V11M1.5 3.5L6 6L10.5 3.5" stroke="currentColor" stroke-width="1" stroke-linejoin="round" opacity="0.5"/></svg>`,
    light:      `<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="5" r="2.3" stroke="currentColor" stroke-width="1.1"/><path d="M6 1v1M6 9v1M1 5h1M10 5h1M2.5 2.5l.7.7M8.8 8.8l.7.7M2.5 7.5l.7-.7M8.8 1.2l.7.7" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>`,
    camera:     `<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M1 3.5h7l3 2.5-3 2.5H1V3.5z" stroke="currentColor" stroke-width="1.1" stroke-linejoin="round"/><circle cx="9" cy="6" r="1" fill="currentColor" opacity="0.7"/></svg>`,
    collection: `<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><rect x="1" y="3.5" width="10" height="7" rx="1" stroke="currentColor" stroke-width="1.1"/><path d="M1 5.5h10" stroke="currentColor" stroke-width="0.9" opacity="0.4"/><path d="M3 1.5h4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>`,
    parent:     `<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><rect x="1" y="1" width="4" height="3" rx="0.6" stroke="currentColor" stroke-width="1.1"/><rect x="7" y="8" width="4" height="3" rx="0.6" stroke="currentColor" stroke-width="1.1"/><path d="M3 4v2.5h4.5V8" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    chevron:    `<svg width="8" height="8" viewBox="0 0 8 8" fill="none"><path d="M2 3L4 5L6 3" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    eye:        `<svg width="9" height="9" viewBox="0 0 12 12" fill="none"><path d="M1.5 6C2.5 3.5 4.1 2 6 2s3.5 1.5 4.5 4c-1 2.5-2.6 4-4.5 4S2.5 8.5 1.5 6z" stroke="currentColor" stroke-width="1.1"/><circle cx="6" cy="6" r="1.5" fill="currentColor" opacity="0.8"/></svg>`,
    eyeOff:     `<svg width="9" height="9" viewBox="0 0 12 12" fill="none"><path d="M2 2L10 10" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><path d="M5.5 3.5A4.5 4.5 0 0 1 10.5 6c-.4.8-1 1.5-1.7 2" stroke="currentColor" stroke-width="1" stroke-linecap="round"/><path d="M1.5 6C2.5 3.5 4 2.2 5.8 2" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>`,
    lock:       `<svg width="9" height="9" viewBox="0 0 12 12" fill="none"><rect x="2" y="5.5" width="8" height="5.5" rx="1" stroke="currentColor" stroke-width="1.1"/><path d="M4 5.5V3.5a2 2 0 1 1 4 0V5.5" stroke="currentColor" stroke-width="1.1"/></svg>`,
    unlock:     `<svg width="9" height="9" viewBox="0 0 12 12" fill="none"><rect x="2" y="5.5" width="8" height="5.5" rx="1" stroke="currentColor" stroke-width="1.1"/><path d="M4 5.5V3.5a2 2 0 0 1 4 0v0" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" opacity="0.35"/></svg>`,
    unlink:     `<svg width="9" height="9" viewBox="0 0 12 12" fill="none"><path d="M4.5 7.5L7.5 4.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/><path d="M2 9.5l1.5-1.5M8.5 3.5L10 2" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" opacity="0.5"/></svg>`,
  };

  // ── Object type helpers ───────────────────────────────
  function _getObjType(obj) {
    const sot = obj.userData.sceneObjectType;
    if (sot === 'light')  return 'light';
    if (sot === 'camera') return 'camera';
    return 'mesh';
  }
  function _getTypeLabel(obj) {
    const sot = obj.userData.sceneObjectType;
    if (sot === 'light')  return (obj.userData.lightType || 'light').slice(0,3).toUpperCase();
    if (sot === 'camera') return 'CAM';
    return (obj.userData.typeName || 'Mesh').slice(0,4);
  }
  function _getAllObjects() {
    return [
      ...SceneManager.getMeshObjects(),
      ...SceneManager.getLightObjects(),
      ...SceneManager.getCameraObjects(),
    ];
  }
  function _getByUuid(uuid) { return _getAllObjects().find(o => o.uuid === uuid) || null; }

  // ── Collection helpers ────────────────────────────────
  function _collectionOfObj(uuid) { return _collections.find(c => c.memberUuids.includes(uuid)) || null; }

  // ── Parent/child helpers ──────────────────────────────
  function _getParent(uuid)   { return _parentOf[uuid] || null; }
  function _getChildren(uuid) { return _childrenOf[uuid] || []; }
  function _isAncestor(potentialAncestorUuid, uuid) {
    let cur = _parentOf[uuid];
    while (cur) { if (cur === potentialAncestorUuid) return true; cur = _parentOf[cur]; }
    return false;
  }

  // Set parent/child relationship (no Three.js scene graph change — world-space inheritance applied via sync)
  function _setParent(childUuid, parentUuid) {
    // Remove from previous parent
    const oldParent = _parentOf[childUuid];
    if (oldParent) {
      _childrenOf[oldParent] = (_childrenOf[oldParent] || []).filter(u => u !== childUuid);
      if (_childrenOf[oldParent].length === 0) delete _childrenOf[oldParent];
    }
    if (parentUuid) {
      _parentOf[childUuid] = parentUuid;
      if (!_childrenOf[parentUuid]) _childrenOf[parentUuid] = [];
      if (!_childrenOf[parentUuid].includes(childUuid)) _childrenOf[parentUuid].push(childUuid);
    } else {
      delete _parentOf[childUuid];
    }
  }

  function _clearParent(childUuid) { _setParent(childUuid, null); }

  // ── Build a single object row ─────────────────────────
  function _buildItem(obj, depth, isRoot) {
    const active     = SelectionSystem.getSelected();
    const isSelected = SelectionSystem.isInMultiSel(obj);
    const isActive   = obj === active;
    const isHidden   = _hidden.has(obj.uuid);
    const isLocked   = _locked.has(obj.uuid);
    const hasChildren = (_childrenOf[obj.uuid] || []).length > 0;
    const isCollapsed = _collapsed.has(obj.uuid);
    const type        = _getObjType(obj);
    const parentUuid  = _parentOf[obj.uuid];

    const item = document.createElement('div');
    item.className = 'hier-item' +
      (isActive   ? ' active-obj'  : '') +
      (isSelected && !isActive ? ' multi-sel' : '') +
      (isSelected ? ' selected' : '');
    item.dataset.uuid = obj.uuid;
    item.draggable = !isLocked;

    // Indent
    const indent = document.createElement('span');
    indent.className = 'hier-indent';
    indent.style.width = (depth * 14) + 'px';
    item.appendChild(indent);

    // Expand/collapse toggle (only shown when has children)
    const toggle = document.createElement('span');
    toggle.className = 'hier-toggle' + (hasChildren ? (isCollapsed ? '' : ' expanded') : ' leaf');
    toggle.innerHTML = ICONS.chevron;
    if (hasChildren) {
      toggle.addEventListener('click', e => {
        e.stopPropagation();
        if (_collapsed.has(obj.uuid)) _collapsed.delete(obj.uuid); else _collapsed.add(obj.uuid);
        refresh();
      });
    }
    item.appendChild(toggle);

    // Type icon
    const iconEl = document.createElement('span');
    iconEl.className = 'hier-icon icon-' + type;
    iconEl.innerHTML = ICONS[type] || ICONS.mesh;
    item.appendChild(iconEl);

    // Label (double-click to rename via existing rename system)
    const label = document.createElement('span');
    label.className = 'hier-label';
    label.textContent = obj.name;
    if (isHidden) label.style.opacity = '0.38';
    label.addEventListener('dblclick', e => {
      e.stopPropagation();
      _startRenameObj(obj, label);
    });
    item.appendChild(label);

    // Parent indicator badge
    if (parentUuid) {
      const parentBadge = document.createElement('span');
      parentBadge.className = 'hier-type-badge hier-parent-badge';
      parentBadge.title = 'Child of ' + (_getByUuid(parentUuid)?.name || '?');
      parentBadge.innerHTML = ICONS.parent;
      item.appendChild(parentBadge);
    } else {
      // Type badge
      const badge = document.createElement('span');
      badge.className = 'hier-type-badge';
      badge.textContent = _getTypeLabel(obj);
      item.appendChild(badge);
    }

    // Actions row
    const actions = document.createElement('div');
    actions.className = 'hier-actions';

    // Unparent button (only when has a parent)
    if (parentUuid) {
      const unparentBtn = document.createElement('button');
      unparentBtn.className = 'hier-action-btn';
      unparentBtn.title = 'Unparent';
      unparentBtn.innerHTML = ICONS.unlink;
      unparentBtn.addEventListener('click', e => {
        e.stopPropagation();
        _clearParent(obj.uuid);
        refresh();
      });
      actions.appendChild(unparentBtn);
    }

    // Eye toggle
    const eyeBtn = document.createElement('button');
    eyeBtn.className = 'hier-action-btn' + (isHidden ? ' active' : '');
    eyeBtn.title = isHidden ? 'Show' : 'Hide';
    eyeBtn.innerHTML = isHidden ? ICONS.eyeOff : ICONS.eye;
    eyeBtn.addEventListener('click', e => {
      e.stopPropagation();
      if (_hidden.has(obj.uuid)) { _hidden.delete(obj.uuid); obj.visible = true; }
      else { _hidden.add(obj.uuid); obj.visible = false; }
      refresh();
    });
    actions.appendChild(eyeBtn);

    // Lock toggle
    const lockBtn = document.createElement('button');
    lockBtn.className = 'hier-action-btn lock' + (isLocked ? ' active' : '');
    lockBtn.title = isLocked ? 'Unlock' : 'Lock';
    lockBtn.innerHTML = isLocked ? ICONS.lock : ICONS.unlock;
    lockBtn.addEventListener('click', e => {
      e.stopPropagation();
      if (_locked.has(obj.uuid)) { _locked.delete(obj.uuid); }
      else {
        _locked.add(obj.uuid);
        if (SelectionSystem.getSelected() === obj) { SelectionSystem.clearSelection(); UISystem.refreshProps(null); }
      }
      refresh();
    });
    actions.appendChild(lockBtn);

    item.appendChild(actions);

    // Click: select / shift-select
    item.addEventListener('click', e => {
      if (_locked.has(obj.uuid)) return;
      if (e.shiftKey) { SelectionSystem.selectObject(obj, true); }
      else { SelectionSystem.selectObject(obj, false); }
    });

    // Drag: source
    item.addEventListener('dragstart', e => {
      if (_locked.has(obj.uuid)) { e.preventDefault(); return; }
      _dragSrc = { uuid: obj.uuid, isCollection: false };
      e.dataTransfer.effectAllowed = 'move';
      setTimeout(() => item.classList.add('drag-source'), 0);
    });
    item.addEventListener('dragend', () => {
      item.classList.remove('drag-source');
      _dragSrc = null;
      document.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
    });

    // Drag: target — drop onto this object to parent src → this
    item.addEventListener('dragover', e => {
      e.preventDefault();
      if (!_dragSrc || _dragSrc.isCollection) return;
      if (_dragSrc.uuid === obj.uuid) return;
      e.dataTransfer.dropEffect = 'move';
      document.querySelectorAll('.hier-item.drag-over').forEach(el => el.classList.remove('drag-over'));
      item.classList.add('drag-over');
    });
    item.addEventListener('dragleave', () => item.classList.remove('drag-over'));
    item.addEventListener('drop', e => {
      e.preventDefault();
      item.classList.remove('drag-over');
      if (!_dragSrc || _dragSrc.isCollection || _dragSrc.uuid === obj.uuid) return;
      if (_isAncestor(_dragSrc.uuid, obj.uuid)) return; // would create cycle
      _setParent(_dragSrc.uuid, obj.uuid);
      // Ensure parent row is expanded
      _collapsed.delete(obj.uuid);
      refresh();
    });

    return item;
  }

  // Inline rename for object labels
  function _startRenameObj(obj, labelEl) {
    const oldName = obj.name;
    const input = document.createElement('input');
    input.type = 'text';
    input.value = oldName;
    input.className = 'hier-rename-input';
    labelEl.replaceWith(input);
    input.focus(); input.select();
    const commit = () => {
      const newName = input.value.trim() || oldName;
      obj.name = newName;
      refresh();
      UISystem.refreshProps(obj);
    };
    input.addEventListener('blur', commit);
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
      if (e.key === 'Escape') { input.value = oldName; input.blur(); }
      e.stopPropagation();
    });
  }

  // Inline rename for collection name
  function _startRenameCollection(col, labelEl) {
    const oldName = col.name;
    const input = document.createElement('input');
    input.type = 'text';
    input.value = oldName;
    input.className = 'hier-rename-input';
    labelEl.replaceWith(input);
    input.focus(); input.select();
    const commit = () => {
      col.name = input.value.trim() || oldName;
      refresh();
    };
    input.addEventListener('blur', commit);
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
      if (e.key === 'Escape') { input.value = oldName; input.blur(); }
      e.stopPropagation();
    });
  }

  // ── Build a collection folder row ────────────────────
  function _buildCollectionRow(col) {
    const isCollapsed = _collapsed.has(col.uuid);
    const memberObjs  = col.memberUuids.map(u => _getByUuid(u)).filter(Boolean);

    const item = document.createElement('div');
    item.className = 'hier-item collection-row';
    item.dataset.colId = col.uuid;

    const indent = document.createElement('span');
    indent.className = 'hier-indent'; indent.style.width = '0px';
    item.appendChild(indent);

    // Expand/collapse toggle
    const toggle = document.createElement('span');
    toggle.className = 'hier-toggle' + (memberObjs.length > 0 ? (isCollapsed ? '' : ' expanded') : ' leaf');
    toggle.innerHTML = ICONS.chevron;
    toggle.addEventListener('click', e => {
      e.stopPropagation();
      if (_collapsed.has(col.uuid)) _collapsed.delete(col.uuid); else _collapsed.add(col.uuid);
      refresh();
    });
    item.appendChild(toggle);

    // Icon
    const iconEl = document.createElement('span');
    iconEl.className = 'hier-icon icon-collection';
    iconEl.innerHTML = ICONS.collection;
    item.appendChild(iconEl);

    // Label (double-click to rename)
    const label = document.createElement('span');
    label.className = 'hier-label';
    label.textContent = col.name + (memberObjs.length ? ` (${memberObjs.length})` : '');
    label.addEventListener('dblclick', e => { e.stopPropagation(); _startRenameCollection(col, label); });
    item.appendChild(label);

    // Drag: collection header is a drop target to add objects to it
    item.addEventListener('dragover', e => {
      if (!_dragSrc || _dragSrc.isCollection) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      item.classList.add('drag-over');
    });
    item.addEventListener('dragleave', () => item.classList.remove('drag-over'));
    item.addEventListener('drop', e => {
      e.preventDefault();
      item.classList.remove('drag-over');
      if (!_dragSrc || _dragSrc.isCollection) return;
      // Add to this collection (remove from any other)
      _collections.forEach(c => { c.memberUuids = c.memberUuids.filter(u => u !== _dragSrc.uuid); });
      if (!col.memberUuids.includes(_dragSrc.uuid)) col.memberUuids.push(_dragSrc.uuid);
      _collapsed.delete(col.uuid);
      refresh();
    });

    return item;
  }

  // ── Recursive tree render ─────────────────────────────
  function _renderObjectAndChildren(container, obj, depth) {
    container.appendChild(_buildItem(obj, depth, depth === 0));
    // Render children if not collapsed
    if (!_collapsed.has(obj.uuid)) {
      const children = (_childrenOf[obj.uuid] || []).map(u => _getByUuid(u)).filter(Boolean);
      children.forEach(child => _renderObjectAndChildren(container, child, depth + 1));
    }
  }

  // ── Main refresh ──────────────────────────────────────
  function refresh() {
    FDEBUG.log('hierarchyUpdate', 'refresh — objects:', _getAllObjects().length, '| collections:', _collections.length);
    const tree  = document.getElementById('hierarchy-tree'); if (!tree) return;
    const empty = document.getElementById('hier-empty');
    const count = document.getElementById('hier-count');

    const allObjs  = _getAllObjects();
    const allUuids = new Set(allObjs.map(o => o.uuid));

    // Prune stale UUIDs from collections, but keep empty collections (user just created them)
    _collections.forEach(c => { c.memberUuids = c.memberUuids.filter(u => allUuids.has(u)); });

    // Prune stale parent/child entries
    Object.keys(_parentOf).forEach(childUuid => {
      if (!allUuids.has(childUuid) || !allUuids.has(_parentOf[childUuid])) _clearParent(childUuid);
    });

    if (count) count.textContent = allObjs.length;

    if (allObjs.length === 0 && _collections.length === 0) {
      tree.innerHTML = '';
      if (empty) { empty.style.display = ''; tree.appendChild(empty); }
      return;
    }
    if (empty) empty.style.display = 'none';

    // Set of UUIDs that are children (should not appear at root)
    const isChild = new Set(Object.keys(_parentOf));
    // Set of UUIDs in a collection (can still appear at root unless they're also children)
    const inCollection = new Set(_collections.flatMap(c => c.memberUuids));

    tree.innerHTML = '';

    // 1. Collections first
    _collections.forEach(col => {
      tree.appendChild(_buildCollectionRow(col));
      if (!_collapsed.has(col.uuid)) {
        const wrap = document.createElement('div');
        wrap.className = 'hier-children';
        col.memberUuids.forEach(uuid => {
          const obj = _getByUuid(uuid);
          if (obj && allUuids.has(uuid)) _renderObjectAndChildren(wrap, obj, 1);
        });
        tree.appendChild(wrap);
      }
    });

    // 2. Root-level objects (not a child of another object, not in a collection)
    const roots = allObjs.filter(o => !isChild.has(o.uuid) && !inCollection.has(o.uuid));
    const meshes  = roots.filter(o => !o.userData.sceneObjectType);
    const lights  = roots.filter(o => o.userData.sceneObjectType === 'light');
    const cameras = roots.filter(o => o.userData.sceneObjectType === 'camera');

    [...meshes, ...lights, ...cameras].forEach(obj => {
      _renderObjectAndChildren(tree, obj, 0);
    });

    // 3. Drop zone at bottom of tree for unparenting (drag to empty area)
    const dropZone = document.createElement('div');
    dropZone.className = 'hier-drop-root';
    dropZone.addEventListener('dragover', e => {
      if (!_dragSrc || _dragSrc.isCollection) return;
      e.preventDefault();
      dropZone.classList.add('drag-over');
    });
    dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
    dropZone.addEventListener('drop', e => {
      e.preventDefault();
      dropZone.classList.remove('drag-over');
      if (!_dragSrc || _dragSrc.isCollection) return;
      // Remove from parent
      _clearParent(_dragSrc.uuid);
      // Remove from collection too (but keep the collection itself even if empty)
      _collections.forEach(c => { c.memberUuids = c.memberUuids.filter(u => u !== _dragSrc.uuid); });
      refresh();
    });
    tree.appendChild(dropZone);
  }

  // ── New Collection ────────────────────────────────────
  function _newCollection() {
    _colCounter++;
    const name = 'Collection.' + String(_colCounter).padStart(3, '0');
    const selected = SelectionSystem.getMultiSelected().filter(o => !o.userData.sceneObjectType);
    const memberUuids = selected.length > 0 ? selected.map(o => o.uuid) : [];
    _collections.push({ uuid: 'col_' + Date.now() + '_' + _colCounter, name, memberUuids });
    refresh();
  }

  // ── Delete ────────────────────────────────────────────
  function _deleteSelected() {
    if (EditModeSystem.isActive()) return;
    const toDelete = SelectionSystem.getMultiSelected().filter(o => !_locked.has(o.uuid));
    if (toDelete.length === 0) {
      // Also try the active single obj (scene objects: cameras/lights)
      const obj = SelectionSystem.getSelected();
      if (obj && !_locked.has(obj.uuid) && obj.userData.sceneObjectType) {
        _removeSceneObj(obj);
        SelectionSystem.clearSelection(); UISystem.refreshProps(null); UISystem.updateStatus(null);
        refresh(); return;
      }
      return;
    }
    TransformControlsModule.detach();
    toDelete.forEach(obj => {
      _hidden.delete(obj.uuid); _locked.delete(obj.uuid);
      _clearParent(obj.uuid);
      // Unparent any children
      (_childrenOf[obj.uuid] || []).forEach(childUuid => _clearParent(childUuid));
      if (obj.userData.sceneObjectType) _removeSceneObj(obj);
      else SceneManager.removeObject(obj);
    });
    SelectionSystem.clearSelection(); UISystem.refreshProps(null); UISystem.updateStatus(null);
    refresh();
  }

  // Route scene-object (light/camera) removal through the owning system so
  // internal state (LightManager._sceneLights, shadow maps, camera preview)
  // is properly cleaned up. Fallback to SceneManager for unknown types.
  function _removeSceneObj(obj) {
    const sot = obj.userData.sceneObjectType;
    if (sot === 'light' && typeof LightManager !== 'undefined') {
      LightManager.removeLight(obj);
    } else if (sot === 'camera' && typeof SceneCameraSystem !== 'undefined') {
      SceneCameraSystem.removeCamera(obj);
    } else {
      // Unknown sceneObjectType — no owning system to handle cleanup, so
      // dispose geometry/material here before handing off to SceneManager.
      const texSlots = ['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap'];
      obj.traverse(c => {
        if (c.geometry) c.geometry.dispose();
        if (c.material) {
          texSlots.forEach(slot => { if (c.material[slot]) { c.material[slot].dispose(); c.material[slot] = null; } });
          c.material.dispose();
        }
      });
      SceneManager.removeSceneObject(obj);
    }
  }

  // ── Save/load serialisation ───────────────────────────
  function serialise() {
    return {
      collections: _collections.map(c => ({ uuid: c.uuid, name: c.name, memberUuids: [...c.memberUuids] })),
      parents:     Object.entries(_parentOf).map(([child, parent]) => ({ child, parent })),
      hidden:      [..._hidden],
      locked:      [..._locked],
      collapsed:   [..._collapsed],
      colCounter:  _colCounter,
    };
  }

  function deserialise(data) {
    if (!data) return;
    _collections.length = 0;
    if (Array.isArray(data.collections)) {
      data.collections.forEach(c => _collections.push({ uuid: c.uuid, name: c.name, memberUuids: [...(c.memberUuids||[])] }));
    }
    Object.keys(_parentOf).forEach(k => delete _parentOf[k]);
    Object.keys(_childrenOf).forEach(k => delete _childrenOf[k]);
    if (Array.isArray(data.parents)) {
      data.parents.forEach(({child, parent}) => _setParent(child, parent));
    }
    _hidden.clear(); _locked.clear(); _collapsed.clear();
    if (Array.isArray(data.hidden))    data.hidden.forEach(u => _hidden.add(u));
    if (Array.isArray(data.locked))    data.locked.forEach(u => _locked.add(u));
    if (Array.isArray(data.collapsed)) data.collapsed.forEach(u => _collapsed.add(u));
    if (typeof data.colCounter === 'number') _colCounter = data.colCounter;
    // Restore visibility
    _getAllObjects().forEach(obj => { obj.visible = !_hidden.has(obj.uuid); });
    refresh();
  }

  // ── Init ──────────────────────────────────────────────
  function init() {
    const newColBtn = document.getElementById('hier-btn-new-collection');
    if (newColBtn) newColBtn.addEventListener('click', _newCollection);
    const delBtn = document.getElementById('hier-btn-delete');
    if (delBtn) delBtn.addEventListener('click', _deleteSelected);

    const addCamBtn = document.getElementById('hier-btn-add-camera');
    if (addCamBtn) addCamBtn.addEventListener('click', () => {
      if (typeof SceneCameraSystem !== 'undefined') SceneCameraSystem.addCamera();
    });

    EventBus.on('scene:objectAdded',   () => refresh());
    EventBus.on('scene:objectRemoved', () => refresh());
    EventBus.on('editmode:changed',    () => refresh());
    // Single handler: refresh hierarchy on selection change
    EventBus.on('selection:changed', (obj) => {
      refresh();
      // Also take an initial matrix snapshot so transform:changed has a valid prev matrix
      // from the moment the object is selected (before any drag starts).
      if (!obj || obj.userData.sceneObjectType) return;
      obj.updateMatrixWorld(true);
      _prevMatrix[obj.uuid] = obj.matrixWorld.clone();
    });

    // Propagate parent transform to children recursively
    // We track each parent's previous world matrix so we can compute the delta
    const _prevMatrix = {};  // uuid → THREE.Matrix4

    EventBus.on('transform:changed', (obj) => {
      if (!obj || obj.userData.sceneObjectType) return;
      const children = _childrenOf[obj.uuid];
      if (!children || children.length === 0) return;

      // Get the delta: newWorld * inverse(prevWorld)
      obj.updateMatrixWorld(true);
      const newMat = obj.matrixWorld.clone();
      const prevMat = _prevMatrix[obj.uuid];

      if (prevMat) {
        const delta = newMat.clone().multiply(prevMat.clone().invert());
        // Apply delta to all descendants recursively
        function applyToDescendants(parentUuid) {
          const kids = _childrenOf[parentUuid] || [];
          kids.forEach(childUuid => {
            const child = _getByUuid(childUuid);
            if (!child) return;
            // Apply world-space delta to child's world position
            child.updateMatrixWorld(true);
            const childWorld = child.matrixWorld.clone();
            const newChildWorld = delta.clone().multiply(childWorld);
            // Decompose back to local (child's parent in scene graph is the scene root)
            newChildWorld.decompose(child.position, child.quaternion, child.scale);
            child.updateMatrixWorld(true);
            // Update this child's stored matrix and recurse
            _prevMatrix[childUuid] = child.matrixWorld.clone();
            applyToDescendants(childUuid);
          });
        }
        applyToDescendants(obj.uuid);
      }

      // Store current matrix for next frame
      _prevMatrix[obj.uuid] = newMat;
    });

    // Re-snapshot the world matrix at the start of every gizmo drag so the delta
    // calculation in transform:changed uses the exact pre-drag state, not the
    // potentially stale snapshot from when the object was first selected.
    EventBus.on('transform:dragStart', (obj) => {
      if (!obj || obj.userData.sceneObjectType) return;
      obj.updateMatrixWorld(true);
      _prevMatrix[obj.uuid] = obj.matrixWorld.clone();
    });

  }

  function isLocked(obj) { return obj && _locked.has(obj.uuid); }

  return { init, refresh, isLocked, deleteSelected: _deleteSelected, serialise, deserialise };
})();

// ══════════════════════════════════════════════════════
//  ViewportSettings — display overlay toggle controls
// ══════════════════════════════════════════════════════
