'use strict';
const PanelCollapseSystem = (() => {
  const SESSION_KEY_LEFT  = 'forgex_panel_left_collapsed';
  const SESSION_KEY_RIGHT = 'forgex_panel_right_collapsed';

  let _leftCollapsed  = false;
  let _rightCollapsed = false;
  let _leftPanel, _rightPanel, _toggleLeft, _toggleRight;
  let _resizeScheduled = false;

  function _scheduleResize() {
    if (_resizeScheduled) return;
    _resizeScheduled = true;
    // Fire resize after transition completes so Three.js / RendererManager gets correct size
    setTimeout(() => {
      _resizeScheduled = false;
      if (typeof RendererManager !== 'undefined') RendererManager.resize();
      if (typeof RenderLoop !== 'undefined') RenderLoop.markDirty(4);
    }, 240);
  }

  function _setLeft(collapsed, animate) {
    _leftCollapsed = collapsed;
    if (!animate) _leftPanel.style.transition = 'none';
    _leftPanel.classList.toggle('collapsed', collapsed);
    document.body.classList.toggle('left-collapsed', collapsed);
    if (!animate) {
      // Force reflow then restore transitions
      void _leftPanel.offsetWidth;
      _leftPanel.style.transition = '';
    }
    // Update aria + title
    _toggleLeft.setAttribute('aria-label', collapsed ? 'Expand Scene Panel' : 'Collapse Scene Panel');
    _toggleLeft.title = collapsed ? 'Expand Scene Panel' : 'Collapse Scene Panel';
    try { sessionStorage.setItem(SESSION_KEY_LEFT, collapsed ? '1' : '0'); } catch(e){}
    _scheduleResize();
  }

  function _setRight(collapsed, animate) {
    _rightCollapsed = collapsed;
    if (!animate) _rightPanel.style.transition = 'none';
    _rightPanel.classList.toggle('collapsed', collapsed);
    document.body.classList.toggle('right-collapsed', collapsed);
    if (!animate) {
      void _rightPanel.offsetWidth;
      _rightPanel.style.transition = '';
    }
    _toggleRight.setAttribute('aria-label', collapsed ? 'Expand Properties Panel' : 'Collapse Properties Panel');
    _toggleRight.title = collapsed ? 'Expand Properties Panel' : 'Collapse Properties Panel';
    try { sessionStorage.setItem(SESSION_KEY_RIGHT, collapsed ? '1' : '0'); } catch(e){}
    _scheduleResize();
  }

  function init() {
    _leftPanel   = document.getElementById('panel-left');
    _rightPanel  = document.getElementById('panel-right');
    _toggleLeft  = document.getElementById('toggle-left');
    _toggleRight = document.getElementById('toggle-right');

    if (!_leftPanel || !_rightPanel || !_toggleLeft || !_toggleRight) return;

    // Restore panel state from session (without animation on init)
    try {
      const storedL = sessionStorage.getItem(SESSION_KEY_LEFT);
      const storedR = sessionStorage.getItem(SESSION_KEY_RIGHT);
      if (storedL === '1') _setLeft(true, false);
      if (storedR === '1') _setRight(true, false);
    } catch(e){}

    _toggleLeft.addEventListener('click', (e) => {
      e.stopPropagation();
      _setLeft(!_leftCollapsed, true);
    });

    _toggleRight.addEventListener('click', (e) => {
      e.stopPropagation();
      _setRight(!_rightCollapsed, true);
    });

    // Keyboard shortcut: Ctrl+[ and Ctrl+]
    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === '[') { e.preventDefault(); _setLeft(!_leftCollapsed, true); }
      if ((e.ctrlKey || e.metaKey) && e.key === ']') { e.preventDefault(); _setRight(!_rightCollapsed, true); }
    });
  }

  return { init, collapseLeft: () => _setLeft(true, true), expandLeft: () => _setLeft(false, true),
           collapseRight: () => _setRight(true, true), expandRight: () => _setRight(false, true) };
})();

// ══════════════════════════════════════════════════════
//  MaterialSystem — Phase 6.5: Advanced Maps & UV Mapping
// ══════════════════════════════════════════════════════
